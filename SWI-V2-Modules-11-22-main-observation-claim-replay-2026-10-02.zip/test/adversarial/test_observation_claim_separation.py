"""Adversarial tests for process-wide observation/claim/report separation."""
from __future__ import annotations

from pathlib import Path

import pytest

from swi_v2.reports.test_report import (
    ClaimRecord,
    ObservationRecord,
    ReplayObservationRecord,
    TestReportBuilder as ReportBuilder,
)


def _obs(i="OBS-1", stage="BEFORE", event="execution boundary observed"):
    return ObservationRecord(
        observation_id=i,
        test_id="T-OBS-1",
        stage=stage,
        event=event,
        expected={"execution_allowed": False},
        actual={"execution_allowed": False},
        state_before="UNKNOWN",
        state_during="CHECKED",
        state_after="HALT",
        execution_counter_before=0,
        execution_counter_after=0,
        evidence_hash="e" * 64,
    )


def test_observation_can_exist_without_claim():
    b = ReportBuilder(root=Path.cwd())
    b.add_observation(_obs())
    assert len(b.observations) == 1
    assert b.claims == []


def test_claim_requires_observation_reference():
    b = ReportBuilder(root=Path.cwd())
    with pytest.raises(ValueError, match="supporting observation"):
        b.add_claim(ClaimRecord("C-1", "something happened"))


def test_claim_rejects_nonexistent_observation_reference():
    b = ReportBuilder(root=Path.cwd())
    with pytest.raises(ValueError, match="unknown observations"):
        b.add_claim(ClaimRecord("C-1", "something happened", ["OBS-MISSING"]))


def test_pass_is_not_proven():
    b = ReportBuilder(root=Path.cwd())
    b.add_observation(_obs())
    b.add_claim(ClaimRecord("C-1", "execution was blocked", ["OBS-1"]))
    assert b.claims[0].status == "NOT_PROVEN"


def test_proven_claim_requires_explicit_evidence_requirement():
    b = ReportBuilder(root=Path.cwd())
    b.add_observation(_obs())
    with pytest.raises(ValueError, match="evidence_required"):
        b.add_claim(ClaimRecord("C-1", "execution was blocked", ["OBS-1"], status="PROVEN"))


def test_observation_and_claim_are_distinct_namespaces():
    b = ReportBuilder(root=Path.cwd())
    b.add_observation(_obs())
    b.add_claim(ClaimRecord("C-1", "execution was blocked", ["OBS-1"]))
    d = b.to_dict()
    assert "observations" in d and "claims" in d
    assert d["observations"][0]["observation_id"] == "OBS-1"
    assert d["claims"][0]["supporting_observation_ids"] == ["OBS-1"]


def test_observation_change_changes_report_hash():
    b = ReportBuilder(root=Path.cwd())
    b.add_observation(_obs())
    h1 = b.sha256()
    b.observations[0].actual = {"execution_allowed": True}
    assert b.sha256() != h1


def test_claim_change_changes_report_hash():
    b = ReportBuilder(root=Path.cwd())
    b.add_observation(_obs())
    b.add_claim(ClaimRecord("C-1", "execution was blocked", ["OBS-1"]))
    h1 = b.sha256()
    b.claims[0].statement = "execution was not blocked"
    assert b.sha256() != h1


def test_claim_cannot_mutate_observation():
    b = ReportBuilder(root=Path.cwd())
    o = _obs()
    b.add_observation(o)
    b.add_claim(ClaimRecord("C-1", "execution was blocked", ["OBS-1"]))
    assert o.actual == {"execution_allowed": False}
    assert b.claims[0].supporting_observation_ids == ["OBS-1"]


def test_observation_cannot_mutate_claim():
    b = ReportBuilder(root=Path.cwd())
    b.add_observation(_obs())
    c = ClaimRecord("C-1", "execution was blocked", ["OBS-1"])
    b.add_claim(c)
    b.observations[0].detail = "updated observation"
    assert c.statement == "execution was blocked"


def test_replay_observation_does_not_create_claim():
    b = ReportBuilder(root=Path.cwd())
    b.add_replay_observation(
        ReplayObservationRecord(
            replay_observation_id="RO-1",
            test_id="T-R-1",
            replay_id="R-1",
            original_execution_id="E-1",
            replay_attempt_id="RA-1",
            duplicate_detected=True,
            replay_allowed=False,
            result="OBSERVED",
        )
    )
    assert len(b.replay_observations) == 1
    assert b.claims == []


def test_replay_observation_change_changes_report_hash():
    b = ReportBuilder(root=Path.cwd())
    b.add_replay_observation(ReplayObservationRecord("RO-1", "T-R-1", "R-1"))
    h1 = b.sha256()
    b.replay_observations[0].duplicate_detected = True
    assert b.sha256() != h1


def test_report_surface_has_no_authorization_api():
    b = ReportBuilder(root=Path.cwd())
    for name in ("authorize", "permit", "execute", "seal", "approve", "dispatch"):
        assert not hasattr(b, name)


def test_markdown_separates_observations_and_claims(tmp_path):
    from swi_v2.reports.test_report import write_reports
    b = ReportBuilder(root=Path.cwd())
    b.add_observation(_obs())
    b.add_claim(ClaimRecord("C-1", "execution was blocked", ["OBS-1"]))
    paths = write_reports(b, tmp_path)
    md = paths["md"].read_text()
    assert "## TEST OBSERVATIONS" in md
    assert "## CLAIMS" in md
