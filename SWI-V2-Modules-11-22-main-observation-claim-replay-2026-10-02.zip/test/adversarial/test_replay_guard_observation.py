"""ReplayGuard evidence observations remain separate from proof and authority."""
from __future__ import annotations

import pytest

from swi_v2.kernel.admission import compute_integrity_reference
from swi_v2.kernel.errors import ReplayError
from swi_v2.kernel.replay_guard import ReplayGuard
from swi_v2.reports.test_report import ClaimRecord, ReplayObservationRecord, TestReportBuilder as ReportBuilder


def _fixture(evidence_id="REPLAY-OBS-1"):
    x = {
        "payload": {"text": "replay observation fixture"},
        "foundation_version": "1.0-proposed",
        "evidence_schema_version": "1.0-proposed",
        "evidence_id": evidence_id,
        "verification_status": "foundation_verified_test_fixture",
        "source_reference": "TEST FIXTURE / replay observation",
    }
    x["integrity_reference"] = compute_integrity_reference(
        payload=x["payload"],
        foundation_version=x["foundation_version"],
        evidence_schema_version=x["evidence_schema_version"],
        evidence_id=x["evidence_id"],
        source_reference=x["source_reference"],
    )
    return x


def test_exact_replay_is_detected_by_same_guard():
    guard = ReplayGuard()
    guard.admit(_fixture())
    with pytest.raises(ReplayError):
        guard.admit(_fixture())


def test_replay_observation_records_duplicate_without_claim():
    guard = ReplayGuard()
    guard.admit(_fixture())
    duplicate = False
    try:
        guard.admit(_fixture())
    except ReplayError:
        duplicate = True
    b = ReportBuilder()
    b.add_replay_observation(ReplayObservationRecord(
        "RO-EXACT", "T-REPLAY-EXACT", "REPLAY-1",
        replay_key="REPLAY-OBS-1", replay_key_source="evidence_id",
        duplicate_detected=duplicate, replay_allowed=False,
        result="OBSERVED",
    ))
    assert b.replay_observations[0].duplicate_detected is True
    assert b.claims == []


def test_replay_rejection_does_not_equal_proven_safety():
    b = ReportBuilder()
    b.add_replay_observation(ReplayObservationRecord(
        "RO-SAFE", "T-REPLAY-SAFE", "REPLAY-2",
        duplicate_detected=True, replay_allowed=False,
    ))
    assert b.replay_observations[0].result == "OBSERVED"
    assert b.claims == []


def test_claim_cannot_be_created_from_replay_without_observation_reference():
    b = ReportBuilder()
    with pytest.raises(ValueError):
        b.add_claim(ClaimRecord("C-REPLAY", "replay safe", []))


def test_replay_guard_reset_is_observable_not_production_authority():
    guard = ReplayGuard()
    guard.admit(_fixture())
    guard.reset()
    admitted = guard.admit(_fixture())
    assert admitted.evidence_id == "REPLAY-OBS-1"


def test_distinct_evidence_ids_are_distinct_replay_keys():
    guard = ReplayGuard()
    guard.admit(_fixture("REPLAY-A"))
    admitted = guard.admit(_fixture("REPLAY-B"))
    assert admitted.evidence_id == "REPLAY-B"


def test_report_has_no_replay_authorization_method():
    b = ReportBuilder()
    for name in ("authorize", "permit", "execute", "approve", "dispatch"):
        assert not hasattr(b, name)
