"""Interaction-boundary checks: observation/report/replay are not execution authority."""
from __future__ import annotations

from pathlib import Path

from swi_v2.execution_integrity import (
    AdmittedRoute,
    Decision,
    ExecutionIntegrityGate,
    ExecutionRecord,
    IncomingNode,
    NewInformation,
)
from swi_v2.kernel.replay_guard import ReplayGuard
from swi_v2.reports.test_report import ObservationRecord, ReplayObservationRecord, TestReportBuilder as ReportBuilder
from swi_v2.kernel.admission import compute_integrity_reference


def _route():
    return AdmittedRoute("W-104", "R-abc", "N-7", "I-1", "P-22", "A-9")


def _node(a):
    return IncomingNode(a.node_id, a.workflow_id, a.route_hash, a.input_hash, a.policy_hash, a.admission_hash, 10.0)


def _last():
    return ExecutionRecord("E-103", "W-104", "N-7", "R-abc", "I-1", 10.0)


def test_observation_does_not_authorize_execution():
    gate = ExecutionIntegrityGate(_route(), _last())
    b = ReportBuilder(root=Path.cwd())
    b.add_observation(ObservationRecord("OBS-I-1", "T-I-1", "AFTER", "gate checked"))
    assert not hasattr(b, "authorize")
    assert not hasattr(b, "execute")
    gate.apply_new_information(NewInformation("boundary", affects_evidence_boundary=True, information_id="NI-I-1"), action_id="approve_file")
    r = gate.execute(_node(_route()))
    assert r.decision == Decision.UNKNOWN
    assert r.execution_occurred is False
    assert gate.execution_counter == 0


def test_replay_guard_rejection_is_observation_not_execution_authority():
    candidate = {
        "payload": {"text": "interaction-boundary"},
        "foundation_version": "1.0-proposed",
        "evidence_schema_version": "1.0-proposed",
        "evidence_id": "E-REPLAY-OBS",
        "verification_status": "foundation_verified_test_fixture",
        "source_reference": "TEST FIXTURE / interaction boundary",
    }
    candidate["integrity_reference"] = compute_integrity_reference(
        payload=candidate["payload"],
        foundation_version=candidate["foundation_version"],
        evidence_schema_version=candidate["evidence_schema_version"],
        evidence_id=candidate["evidence_id"],
        source_reference=candidate["source_reference"],
    )
    guard = ReplayGuard()
    first = guard.admit(candidate)
    b = ReportBuilder(root=Path.cwd())
    b.add_replay_observation(ReplayObservationRecord("RO-I-1", "T-I-2", "R-1", original_execution_id="E-1", duplicate_detected=False, replay_allowed=True))
    assert first.evidence_id == "E-REPLAY-OBS"
    assert b.claims == []
    assert not hasattr(b, "execute")
