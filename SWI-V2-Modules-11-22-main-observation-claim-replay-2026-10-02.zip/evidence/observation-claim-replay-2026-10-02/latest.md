# SWI TEST REPORT

Commit: `unknown`
Hash: `b56d9b5d63781763a7ca825b85e86560cda3e248c4611138e63f011b6288f8c2`
Passed: 0/0


## TEST OBSERVATIONS
- OBS-OC-001: [BEFORE] focused suite baseline established status=OBSERVED
- OBS-OC-002: [DURING] observation namespace accepted without claim status=OBSERVED
- OBS-OC-003: [AFTER] claim reference validation rejected missing/unknown observations status=OBSERVED
- OBS-OC-004: [REPLAY] ReplayGuard duplicate was detected by same in-process guard status=OBSERVED
- OBS-OC-005: [REPORT] observation and claim namespaces entered report hash status=OBSERVED
- OBS-OC-006: [STATUS] full suite completed with one git-metadata freshness failure status=OBSERVED

## CLAIMS
- CLAIM-OC-001: Focused Observation/Claim/Replay boundary tests pass twice. status=NOT_PROVEN observations=OBS-OC-001, OBS-OC-003
- CLAIM-OC-002: Observation, claim, and replay records are represented as distinct report namespaces. status=NOT_PROVEN observations=OBS-OC-002, OBS-OC-005
- CLAIM-OC-003: ReplayGuard duplicate detection demonstrates production replay safety. status=NOT_PROVEN observations=OBS-OC-004

## REPLAY OBSERVATIONS
- RO-OC-001: replay=REPLAY-EXACT-001 duplicate=True allowed=False

HASH != AUTHORITY != TRUTH