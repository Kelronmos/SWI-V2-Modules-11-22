# SWI V2 Verification Run — 2026-10-02

Repository: `Kelronmos/SWI-V2-Modules-11-22`  
Uploaded snapshot: `SWI-V2-Modules-11-22-main (4).zip`  
Archive SHA-256: `c816b3567147ca292c390d1fe2b8f19efbed332d4ef4d02cbcc13b605a1e0706`  
Archive comment commit identifier: `13f1bba536a5ea48388fc2baf2053a651b8c33e4` (not independently Git-verified; `.git` is absent)

## Results

- Focused ReplayGuard/execution-integrity/NewInformation suite: **67 passed**.
- Same focused suite rerun: **67 passed**.
- Selected authority/seal/observation boundary suite: **38 passed**.
- Full discovered suite: **704 passed, 1 failed**.
- Compileall: **PASS**.

## Full-suite limitation

`tests/law/test_evidence_freshness.py::test_evidence_source_tip_reachable_from_head` fails because it calls `git rev-parse HEAD`, while this uploaded archive contains no `.git` directory. This is a repository-metadata limitation, not an observed application assertion failure.

## Requested Observation/Claim separation

The snapshot contains the existing `TestReportBuilder`, but its namespaces remain `tests`, `halt_results`, `execution_results`, `bypass_results`, `limitations`, and `not_proven`. The requested `observations[]` and `claims[]` separation, plus the earlier dedicated observation-claim test file, was not found. Therefore that requested extension is **NOT PROVEN / NOT PRESENT in this snapshot**.

## ReplayGuard boundary

`ReplayGuard` is implemented as an in-process, in-memory guard keyed by `evidence_id`, with reset support. The source itself states that it has no persistence across restarts or cross-machine coordination and is not production replay defense.

## Status

**PRODUCTION AUTHORIZATION: NOT GRANTED BY THIS TEST RUN**

`TESTED != PROVEN != SEALED != PRODUCTION AUTHORIZED`

Report hash: `16479e6bac2765d050d0fc68cf2915515d1ef4e7a676f4ef2cf846050e5030a2`
