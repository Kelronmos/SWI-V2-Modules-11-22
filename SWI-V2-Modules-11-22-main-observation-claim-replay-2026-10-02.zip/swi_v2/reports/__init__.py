"""SWI test report / evidence layer."""
from .test_report import (
    ClaimRecord,
    ObservationRecord,
    ReplayObservationRecord,
    TestReportBuilder,
    TestResultRecord,
    write_reports,
)

__all__ = [
    "ClaimRecord",
    "ObservationRecord",
    "ReplayObservationRecord",
    "TestReportBuilder",
    "TestResultRecord",
    "write_reports",
]
