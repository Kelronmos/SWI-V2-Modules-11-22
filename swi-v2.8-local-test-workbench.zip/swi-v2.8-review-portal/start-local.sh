#!/usr/bin/env bash
# Works in Termux and most Linux shells.
cd "$(dirname "$0")"
python run_swi_local.py
