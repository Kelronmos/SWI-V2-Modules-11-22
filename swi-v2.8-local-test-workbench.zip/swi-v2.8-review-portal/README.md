# SWI V2.8 Public Review Workspace + Local Test Runner

A static browser review portal plus an opt-in loopback Python runner for real SWI V2 tests.

## Start the local browser workbench

Requirements: Python 3.10+ and Git. Internet access is needed to clone SWI and download declared Python dependencies.

### Android / Termux

```bash
pkg update
pkg install python git
cd /path/to/swi-v2.8-review-portal
python run_swi_local.py
```

Then open `http://127.0.0.1:8765/` in the device browser.

### Linux / macOS

```bash
python3 run_swi_local.py
```

### Windows

```powershell
py run_swi_local.py
```

Or use `start-local.sh` / `start-local.bat` where appropriate.

The runner binds only to `127.0.0.1`. It creates a separate checkout under `.swi-workbench/checkouts/`, a per-commit Python virtual environment under `.swi-workbench/venvs/`, and run artifacts under `.swi-workbench/runs/`. It does not change an existing SWI checkout.

## Available test profiles

- Compile package
- Module 11 admission and foundation contract tests
- Execution-integrity adversarial tests
- Universal halt adversarial tests
- Gate PASS/FAIL system-error matrix
- Trusted-source spine inspector test
- All adversarial tests
- Full V2 pytest suite
- `scripts/verify.sh`
- Two-checkout V1 → V2 reproduction (separate checkouts and virtual environments)
- All configured checks, continuing after individual failures

Commands are allow-listed in `run_swi_local.py`; the browser cannot submit arbitrary shell commands. The runner installs the target repository's `requirements.txt` into an isolated venv. It also attempts to install `openpyxl` and `reportlab` for XLSX/PDF export; if a platform cannot install an optional exporter, that format is marked not built rather than faked.

## Evidence output

Each run is bound to the full commit SHA, Python executable/version, platform, environment setup log, profile, exact commands, exit codes, duration and stdout/stderr. Outputs include JSON, Markdown, HTML, CSV, XLSX and PDF when available, plus an artifact manifest with SHA-256 hashes and a ZIP bundle.

A test result is scoped to its recorded source and environment. PASS does not mean PROVEN, SEALED, AUTHORIZED or PRODUCTION_AUTHORIZED.

## Upload inspection

The local runner can inspect JSON and ZIP files as data. It calculates SHA-256, parses JSON, lists ZIP members and flags suspicious paths/archive sizes. Model files are fingerprinted as opaque bytes. Uploaded files are never extracted, imported, executed, or treated as SWI evidence automatically.

## GitHub Pages vs local execution

GitHub Pages can host the static portal and show live public GitHub repository/Actions links. It cannot install packages or execute Python on a visitor's device. To run tests, start the local runner and open its localhost URL; that serves the same UI and local API from one origin.

## Known current-main CI failures diagnosed from GitHub logs

- Verification run `42165182507`: Python 3.10/3.11/3.12 all reach the execution-integrity adversarial test and fail collection because `AdmittedRoute` is absent from the truncated `swi_v2/execution_integrity.py`. The module/foundation test step passed 14 tests per matrix job; downstream stages were skipped.
- Two-checkout run `42165182512`: V1 evidence production, V2 isolation, admission, tamper rejection and seal step passed in the Python 3.12 job. V2 full pytest then failed collection: five adversarial modules cannot import `AdmittedRoute`; the trusted-source test also fails because `swi_v2/trusted_source/spine_inspector.py` is a literal placeholder. The other matrix jobs were cancelled.

A full EI implementation exists on `repair/post-audit-execution-integrity` and is documented as restored from historical blob `9e996555a5831208970b31b91fefb367e1f52cb7`. The trusted-source inspector has no historical implementation blob; its patch is a new reconstruction. Neither is automatically merged or treated as tested/sealed by this portal. Run the tests on the exact repair commit before proposing integration.

## Security and governance limits

- No GitHub write token is embedded or requested.
- No arbitrary uploaded code is executed.
- No automatic source repair or merge is performed.
- The local runner is a developer/reviewer tool, not an authorization engine or sandbox for hostile code.
- Do not run code from untrusted branches on a sensitive device. Use a disposable VM/container for hostile research.
- `PROVEN=NO`, `SEALED=NO`, `PRODUCTION_AUTHORIZED=NO` remain defaults unless separate evidence and human review establish otherwise.
