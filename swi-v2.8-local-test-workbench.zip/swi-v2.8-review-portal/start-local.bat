@echo off
cd /d "%~dp0"
py run_swi_local.py
if errorlevel 1 python run_swi_local.py
pause
