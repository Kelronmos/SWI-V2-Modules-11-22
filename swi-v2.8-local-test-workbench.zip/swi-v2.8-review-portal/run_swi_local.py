#!/usr/bin/env python3
"""SWI V2 local review runner. Runs allow-listed repository test profiles only.

Binds to loopback. It never executes uploaded artifacts or arbitrary browser commands.
"""
from __future__ import annotations
import csv, hashlib, html, io, json, os, platform, re, shutil, subprocess, sys, threading, time, uuid, zipfile
from datetime import datetime, timezone
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

ROOT = Path(__file__).resolve().parent
STATE = ROOT / ".swi-workbench"
CHECKOUTS = STATE / "checkouts"
ARTIFACTS = STATE / "runs"
OWNER = "Kelronmos"
CORE = "SWI-V2-Modules-11-22"
V1 = "SWI-V1-Module-1-10"
PORT = int(os.environ.get("SWI_PORT", "8765"))
MAX_UPLOAD = 50 * 1024 * 1024
STATE.mkdir(exist_ok=True); CHECKOUTS.mkdir(exist_ok=True); ARTIFACTS.mkdir(exist_ok=True)
LOCK = threading.Lock()
JOBS: dict[str, dict] = {}

PROFILES = {
    "compile": [("Compile V2 package", ["-m", "compileall", "-q", "swi_v2"])],
    "module11": [("Module 11 admission + foundation contract", ["-m", "pytest", "-q", "test/test_module11_admission.py", "test/test_foundation_contract.py"])],
    "execution-integrity": [("Execution-integrity adversarial suite", ["-m", "pytest", "-q", "test/adversarial/test_execution_integrity.py"])],
    "universal-halt": [("Universal halt adversarial suite", ["-m", "pytest", "-q", "test/adversarial/test_universal_halt.py"])],
    "gate-matrix": [("Gate PASS/FAIL system-error matrix", ["-m", "pytest", "-q", "test/adversarial/test_gate_pass_fail_matrix.py"])],
    "trusted-source": [("Trusted-source spine inspector", ["-m", "pytest", "-q", "test/test_trusted_source_spine_inspector.py"])],
    "full-suite": [("Full V2 pytest suite", ["-m", "pytest", "-q"])],
    "verify": [("Repository verify.sh", ["__VERIFY__"])],
    "two-checkout": [("V1 produce → V2 isolated admission / tamper / seal / suite", ["__TWO_CHECKOUT__"])],
    "red-team": [("All adversarial tests", ["-m", "pytest", "-q", "test/adversarial"])],
    "all": [
        ("Compile V2 package", ["-m", "compileall", "-q", "swi_v2"]),
        ("Module 11 admission + foundation contract", ["-m", "pytest", "-q", "test/test_module11_admission.py", "test/test_foundation_contract.py"]),
        ("Execution-integrity adversarial suite", ["-m", "pytest", "-q", "test/adversarial/test_execution_integrity.py"]),
        ("Universal halt adversarial suite", ["-m", "pytest", "-q", "test/adversarial/test_universal_halt.py"]),
        ("Gate PASS/FAIL system-error matrix", ["-m", "pytest", "-q", "test/adversarial/test_gate_pass_fail_matrix.py"]),
        ("Trusted-source spine inspector", ["-m", "pytest", "-q", "test/test_trusted_source_spine_inspector.py"]),
        ("Full V2 pytest suite", ["-m", "pytest", "-q"]),
        ("Repository verify.sh", ["__VERIFY__"]),
        ("V1 produce → V2 isolated admission / tamper / seal / suite", ["__TWO_CHECKOUT__"]),
    ],
}


def utcnow(): return datetime.now(timezone.utc).isoformat(timespec="seconds")
def sha256(path: Path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024), b""): h.update(chunk)
    return h.hexdigest()
def run_cmd(cmd, cwd=None, timeout=1800, env=None):
    started=time.time()
    p=subprocess.run(cmd,cwd=str(cwd) if cwd else None,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=timeout,env=env)
    return {"command":cmd,"cwd":str(cwd) if cwd else None,"exit_code":p.returncode,"status":"PASS" if p.returncode==0 else "FAIL","duration_seconds":round(time.time()-started,3),"output":p.stdout}
def git_checkout(repo: str, sha: str|None):
    target = CHECKOUTS / (repo + ("-" + sha[:12] if sha else "-main"))
    if target.exists() and (target/".git").exists():
        if sha:
            r=run_cmd(["git","fetch","origin",sha],target,timeout=600)
            if r["exit_code"]: raise RuntimeError("Could not fetch requested commit: "+r["output"][-1500:])
            run_cmd(["git","checkout","--detach",sha],target)
        else:
            r=run_cmd(["git","fetch","origin","main"],target,timeout=600)
            if r["exit_code"]: raise RuntimeError("git fetch failed: "+r["output"][-1500:])
            run_cmd(["git","checkout","--detach","FETCH_HEAD"],target)
    else:
        tmp=target.with_name(target.name+"-"+uuid.uuid4().hex[:6])
        r=run_cmd(["git","clone","--no-tags","https://github.com/"+OWNER+"/"+repo+".git",str(tmp)],timeout=1200)
        if r["exit_code"]: raise RuntimeError("git clone failed: "+r["output"][-2000:])
        if sha:
            f=run_cmd(["git","fetch","origin",sha],tmp,timeout=600)
            if f["exit_code"]: raise RuntimeError("requested commit fetch failed: "+f["output"][-1500:])
            c=run_cmd(["git","checkout","--detach",sha],tmp)
        else:
            c=run_cmd(["git","checkout","--detach","origin/main"],tmp)
        if c["exit_code"]: raise RuntimeError("checkout failed: "+c["output"][-1500:])
        if target.exists(): shutil.rmtree(target)
        tmp.rename(target)
    actual=run_cmd(["git","rev-parse","HEAD"],target)["output"].strip()
    branch=run_cmd(["git","branch","--show-current"],target)["output"].strip()
    return target,actual,branch

def venv_for(repo: Path, sha: str, exporters: bool = True):
    venv=STATE/"venvs"/(repo.name+"-"+sha[:12]); venv.parent.mkdir(exist_ok=True)
    py=venv/("Scripts/python.exe" if os.name=="nt" else "bin/python")
    if not py.exists():
        r=run_cmd([sys.executable,"-m","venv",str(venv)],timeout=600)
        if r["exit_code"]: raise RuntimeError("Could not create isolated Python environment: "+r["output"][-2000:]+". On Termux, install Python and its venv/ensurepip support first.")
    pip={"status":"UNCHANGED","exit_code":0,"output":"pip was not upgraded; package versions are recorded below."}
    req=repo/"requirements.txt"
    dep=run_cmd([str(py),"-m","pip","install","-r",str(req)],timeout=1800) if req.exists() else {"status":"NOT_REQUIRED","exit_code":0,"output":"No requirements.txt"}
    exports=[]
    for package in (("openpyxl","reportlab") if exporters else ()):
        chk=subprocess.run([str(py),"-c",f"import {package}"],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        if chk.returncode:
            ins=run_cmd([str(py),"-m","pip","install",package],timeout=1200)
            exports.append({"package":package,**{k:ins.get(k) for k in ("status","exit_code","output")}})
        else: exports.append({"package":package,"status":"ALREADY_AVAILABLE","exit_code":0})
    if dep.get("exit_code",1)!=0: raise RuntimeError("Dependency installation failed: "+dep.get("output","")[-2500:])
    freeze=run_cmd([str(py),"-m","pip","freeze"],repo,timeout=120)
    return py,{"pip_upgrade":pip,"requirements_install":dep,"export_packages":exports,"pip_freeze":freeze.get("output","")}

def generate_reports(record: dict, run_dir: Path, py: Path):
    record_path=run_dir/"run.json"; md_path=run_dir/"run.md"; html_path=run_dir/"run.html"; csv_path=run_dir/"tests.csv"
    md=["# SWI V2 Local Verification Report","",f"- Run ID: `{record['run_id']}`",f"- Created: {record['created_at']}",f"- Repository: `{record['repository']}`",f"- Commit: `{record['commit']}`",f"- Python: `{record['python_version']}`",f"- Profile: `{record['profile']}`",f"- Overall: **{record['overall_status']}**","","## Results","","| Check | Status | Exit | Duration (s) |","|---|---:|---:|---:|"]
    for x in record["checks"]: md.append(f"| {x['name']} | {x['status']} | {x.get('exit_code','')} | {x.get('duration_seconds','')} |")
    md += ["","## Environment",f"- Platform: {record['platform']}",f"- Python executable: `{record['python_executable']}`","","## Limitations","- This report is bound only to the commit and checks recorded above.","- A passing test does not establish PROVEN, SEALED or PRODUCTION_AUTHORIZED.","- UNKNOWN / NOT RUN is not converted to PASS.","- This local run is not a GitHub Actions run or an independent review.","","## Output excerpts",""]
    for x in record["checks"]: md += [f"### {x['name']} — {x['status']}","", "```text", (x.get("output","")[-6000:] or "(no output)"), "```",""]
    md_path.write_text("\n".join(md),encoding="utf-8")
    record_path.write_text(json.dumps(record,indent=2),encoding="utf-8")
    rows="".join(f"<tr><td>{html.escape(x['name'])}</td><td>{html.escape(x['status'])}</td><td>{x.get('exit_code','')}</td><td>{x.get('duration_seconds','')}</td></tr>" for x in record["checks"])
    html_path.write_text("<!doctype html><meta charset='utf-8'><title>SWI verification report</title><style>body{font:15px system-ui;max-width:1000px;margin:40px auto;padding:0 16px;background:#101820;color:#edf4f8}table{border-collapse:collapse;width:100%}td,th{padding:9px;border-bottom:1px solid #40505a;text-align:left}.pass{color:#63c99e}.fail{color:#ed7777}</style><h1>SWI V2 Local Verification Report</h1><p>Run "+html.escape(record['run_id'])+" · commit "+html.escape(record['commit'])+" · "+html.escape(record['overall_status'])+"</p><table><tr><th>Check</th><th>Status</th><th>Exit</th><th>Seconds</th></tr>"+rows+"</table><h2>Scope warning</h2><p>Results apply only to this commit, environment and recorded commands. PASS does not establish PROVEN, SEALED or production authorization.</p>",encoding="utf-8")
    with csv_path.open("w",newline="",encoding="utf-8") as f:
        w=csv.writer(f);w.writerow(["name","status","exit_code","duration_seconds","command"])
        for x in record["checks"]: w.writerow([x["name"],x["status"],x.get("exit_code"),x.get("duration_seconds")," ".join(x.get("command",[]))])
    exports={"json":"BUILT","markdown":"BUILT","html":"BUILT","csv":"BUILT","xlsx":"NOT_BUILT","pdf":"NOT_BUILT"}
    try:
        from openpyxl import Workbook
        wb=Workbook();ws=wb.active;ws.title="Verification";ws.append(["Check","Status","Exit code","Duration seconds","Command"])
        for x in record["checks"]: ws.append([x["name"],x["status"],x.get("exit_code"),x.get("duration_seconds")," ".join(x.get("command",[]))])
        ws.freeze_panes="A2";ws.auto_filter.ref=ws.dimensions;wb.save(run_dir/"tests.xlsx");exports["xlsx"]="BUILT"
    except Exception as e: exports["xlsx_error"]=str(e)
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,Preformatted
        from reportlab.lib import colors
        from reportlab.lib.styles import getSampleStyleSheet
        styles=getSampleStyleSheet();story=[Paragraph("SWI V2 Local Verification Report",styles["Title"]),Paragraph("Run: "+record["run_id"],styles["Normal"]),Paragraph("Commit: "+record["commit"],styles["Normal"]),Paragraph("Overall: "+record["overall_status"],styles["Heading2"]),Spacer(1,12)]
        data=[["Check","Status","Exit","Seconds"]]+[[x["name"],x["status"],str(x.get("exit_code","")),str(x.get("duration_seconds",""))] for x in record["checks"]]
        t=Table(data,repeatRows=1);t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#263746")),("TEXTCOLOR",(0,0),(-1,0),colors.white),("GRID",(0,0),(-1,-1),.4,colors.grey),("VALIGN",(0,0),(-1,-1),"TOP")]));story += [t,Spacer(1,12),Paragraph("Limitations",styles["Heading2"]),Paragraph("Results are limited to this commit, environment and command set. PASS does not establish PROVEN, SEALED or PRODUCTION_AUTHORIZED.",styles["BodyText"])]
        SimpleDocTemplate(str(run_dir/"report.pdf"),pagesize=A4).build(story);exports["pdf"]="BUILT"
    except Exception as e: exports["pdf_error"]=str(e)
    record["exports"]=exports;record_path.write_text(json.dumps(record,indent=2),encoding="utf-8")
    manifest={"schema":"swi.run-artifacts.v1","run_id":record["run_id"],"commit":record["commit"],"files":[]}
    for f in sorted(run_dir.iterdir()):
        if f.is_file() and f.name not in ("artifact-manifest.json","bundle.zip"):
            manifest["files"].append({"name":f.name,"bytes":f.stat().st_size,"sha256":sha256(f)})
    (run_dir/"artifact-manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")
    with zipfile.ZipFile(run_dir/"bundle.zip","w",zipfile.ZIP_DEFLATED) as z:
        for f in run_dir.iterdir():
            if f.is_file() and f.name!="bundle.zip": z.write(f,f.name)
    return exports

def run_two_checkout(v2_repo: Path, v2_sha: str, v2_py: Path):
    checks=[]
    v1_repo,v1_sha,_=git_checkout(V1,None)
    v1_py,v1_setup=venv_for(v1_repo,v1_sha,exporters=False)
    v1_env=os.environ.copy();v1_env["PYTHONPATH"]=str(v1_repo)
    def add(name,cmd,cwd,env=None,timeout=1800,expect_reject=False):
        try: r=run_cmd(cmd,cwd,timeout,env)
        except subprocess.TimeoutExpired as e: r={"command":cmd,"exit_code":124,"status":"TIMEOUT","duration_seconds":timeout,"output":str(e)}
        if expect_reject:
            rejected=r.get("exit_code",0)!=0
            r["status"]="PASS" if rejected else "FAIL"
            r["output"] += "\nExpected rejection observed." if rejected else "\nERROR: invalid evidence was accepted."
            r["exit_code"]=0 if rejected else 1
        r["name"]=name;checks.append(r);return r
    add("V1 export real foundation evidence",[str(v1_py),str(v1_repo/"scripts/export_travel_evidence.py"),"--out","evidence.json"],v1_repo,v1_env)
    evidence=v1_repo/"evidence.json"
    if not evidence.exists():
        checks.append({"name":"V1 evidence artifact exists","status":"FAIL","exit_code":1,"duration_seconds":0,"command":[],"output":"V1 export did not create evidence.json"})
        return checks,{"v1_commit":v1_sha,"v1_setup":v1_setup}
    shutil.copy2(evidence,v2_repo/"evidence.json")
    v2_env=os.environ.copy();v2_env["PYTHONPATH"]=str(v2_repo)
    add("V2 cannot import V1 swi_core",[str(v2_py),"-c","import importlib.util,sys; sys.exit(1 if importlib.util.find_spec('swi_core') else 0)"],v2_repo,v2_env)
    add("V2 admits V1 evidence",[str(v2_py),str(v2_repo/"scripts/admit_travel_evidence.py"),"--in","evidence.json"],v2_repo,v2_env)
    tamper="import json;d=json.load(open('evidence.json'));d['payload']=dict(d['payload']);d['payload']['allowed']=not d['payload'].get('allowed',True);json.dump(d,open('evidence_tampered.json','w'))"
    add("Tampered evidence is rejected",[str(v2_py),"-c",tamper+";import subprocess,sys;r=subprocess.run([sys.executable,'scripts/admit_travel_evidence.py','--in','evidence_tampered.json']);sys.exit(0 if r.returncode else 1)"],v2_repo,v2_env)
    bad="import json;d=json.load(open('evidence.json'));d['integrity_reference']='0'*64;json.dump(d,open('evidence_bad_hash.json','w'))"
    add("Bad integrity hash is rejected",[str(v2_py),"-c",bad+";import subprocess,sys;r=subprocess.run([sys.executable,'scripts/admit_travel_evidence.py','--in','evidence_bad_hash.json']);sys.exit(0 if r.returncode else 1)"],v2_repo,v2_env)
    add("Post-admission seal and tamper rejection",[str(v2_py),str(v2_repo/"scripts/seal_travel_evidence.py"),"--in","evidence.json"],v2_repo,v2_env)
    add("V2 full pytest suite in V2-only checkout",[str(v2_py),"-m","pytest","-q"],v2_repo,v2_env,timeout=3600)
    return checks,{"v1_commit":v1_sha,"v2_commit":v2_sha,"v1_setup":v1_setup}

def execute_profile(job_id, payload):
    try:
        profile=payload.get("profile","all")
        if profile not in PROFILES: raise ValueError("Unknown test profile")
        requested=payload.get("commit","").strip() or None
        if requested and not re.fullmatch(r"[0-9a-fA-F]{40}",requested): raise ValueError("Commit must be a full 40-character SHA or blank for current main")
        with LOCK: JOBS[job_id].update(status="RUNNING",message="Fetching exact source and preparing isolated environment…")
        repo,commit,branch=git_checkout(CORE,requested)
        py,setup=venv_for(repo,commit)
        checks=[];extra_meta={}
        test_env=os.environ.copy();test_env["PATH"]=str(py.parent)+os.pathsep+test_env.get("PATH","");test_env["PYTHONPATH"]=str(repo)
        for name,args in PROFILES[profile]:
            if args==["__TWO_CHECKOUT__"]:
                two,meta=run_two_checkout(repo,commit,py);checks.extend(two);extra_meta.update(meta)
                result=two[-1] if two else {"status":"ERROR"}
            else:
                if args==["__VERIFY__"]: cmd=["bash",str(repo/"scripts"/"verify.sh")]
                else: cmd=[str(py),*args]
                try: result=run_cmd(cmd,repo,timeout=3600,env=test_env)
                except subprocess.TimeoutExpired as e: result={"command":cmd,"exit_code":124,"status":"TIMEOUT","duration_seconds":3600,"output":str(e)}
                result["name"]=name;checks.append(result)
            with LOCK: JOBS[job_id].update(message=f"Completed {len(checks)} checks; latest: {name} → {result['status']}")
        overall="PASS" if checks and all(x["status"]=="PASS" for x in checks) else "FAIL"
        run_id="SWI-LOCAL-"+datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")+"-"+job_id[:8]
        run_dir=ARTIFACTS/run_id;run_dir.mkdir(parents=True,exist_ok=True)
        for i,x in enumerate(checks,1): (run_dir/f"check-{i:02d}.log").write_text(x.get("output", ""),encoding="utf-8")
        tree=run_cmd(["git","rev-parse","HEAD^{tree}"],repo)["output"].strip()
        dirty=run_cmd(["git","status","--porcelain"],repo)["output"].strip()
        record={"schema":"swi.local-verification.v1","run_id":run_id,"created_at":utcnow(),"repository":OWNER+"/"+CORE,"commit":commit,"git_tree":tree,"git_status_after_tests":"CLEAN" if not dirty else dirty,"branch":"DETACHED" if not branch else branch,"profile":profile,"overall_status":overall,"python_version":subprocess.run([str(py),"--version"],capture_output=True,text=True).stdout.strip() or subprocess.run([str(py),"--version"],capture_output=True,text=True).stderr.strip(),"python_executable":str(py),"platform":platform.platform(),"runner_version":"0.2.0","setup":setup,"additional_sources":extra_meta,"checks":checks,"status_semantics":{"PASS":"Command returned exit code 0","FAIL":"Command returned non-zero exit code","TIMEOUT":"Command exceeded runner timeout","UNKNOWN":"Not inferred as pass","PROVEN":"NO","SEALED":"NO","PRODUCTION_AUTHORIZED":"NO"}}
        exports=generate_reports(record,run_dir,py)
        with LOCK: JOBS[job_id].update(status="COMPLETED",message="Test profile finished",result={"run_id":run_id,"overall_status":overall,"commit":commit,"checks":[{k:x.get(k) for k in ("name","status","exit_code","duration_seconds")} for x in checks],"exports":exports,"bundle":"/api/download/"+run_id+"/bundle.zip","folder":str(run_dir)})
    except Exception as e:
        with LOCK: JOBS[job_id].update(status="ERROR",message=str(e),error=str(e))

class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs): super().__init__(*args,directory=str(ROOT),**kwargs)
    def log_message(self,fmt,*args): print("[SWI-LOCAL] "+fmt%args)
    def _json(self,obj,status=200):
        raw=json.dumps(obj).encode();self.send_response(status);self.send_header("Content-Type","application/json");self.send_header("Content-Length",str(len(raw)));self.send_header("Cache-Control","no-store");self.end_headers();self.wfile.write(raw)
    def _same_origin(self):
        host=self.headers.get("Host","")
        origin=self.headers.get("Origin","")
        return host.startswith(("127.0.0.1:","localhost:")) and (not origin or origin in ("http://127.0.0.1:"+str(PORT),"http://localhost:"+str(PORT)))
    def do_GET(self):
        p=urlparse(self.path)
        if p.path=="/api/status":
            self._json({"ok":True,"runner":"SWI Local Review Runner","version":"0.2.0","host":"127.0.0.1","repo":OWNER+"/"+CORE,"python":sys.version.split()[0],"platform":platform.platform(),"profiles":list(PROFILES)});return
        if p.path.startswith("/api/job/"):
            jid=p.path.rsplit("/",1)[-1];self._json(JOBS.get(jid,{"status":"NOT_FOUND"}));return
        if p.path.startswith("/api/download/"):
            bits=p.path.strip("/").split("/")
            if len(bits)==3:
                f=ARTIFACTS/bits[1]/bits[2]
                if f.is_file() and f.resolve().is_relative_to(ARTIFACTS.resolve()):
                    data=f.read_bytes();self.send_response(200);self.send_header("Content-Type","application/zip" if f.suffix==".zip" else "application/octet-stream");self.send_header("Content-Disposition",f'attachment; filename="{f.name}"');self.send_header("Content-Length",str(len(data)));self.end_headers();self.wfile.write(data);return
            self._json({"error":"artifact not found"},404);return
        return super().do_GET()
    def do_POST(self):
        if not self._same_origin(): self._json({"error":"same-origin local UI requests only"},403);return
        length=int(self.headers.get("Content-Length","0"))
        if length>MAX_UPLOAD: self._json({"error":"request too large"},413);return
        try: payload=json.loads(self.rfile.read(length) or b"{}")
        except Exception: self._json({"error":"invalid JSON"},400);return
        p=urlparse(self.path)
        if p.path=="/api/run":
            jid=uuid.uuid4().hex
            with LOCK: JOBS[jid]={"status":"QUEUED","message":"Queued","created_at":utcnow()}
            threading.Thread(target=execute_profile,args=(jid,payload),daemon=True).start();self._json({"job_id":jid,"status":"QUEUED"});return
        if p.path=="/api/inspect":
            try:
                name=str(payload.get("name","upload.bin"))[:180];data=bytes.fromhex(payload.get("hex",""))
                if len(data)>MAX_UPLOAD: raise ValueError("file exceeds 50 MiB")
                result={"name":name,"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),"kind":"generic binary / model candidate","executed":False}
                if name.lower().endswith(".json"):
                    obj=json.loads(data.decode("utf-8-sig"));result.update(kind="JSON",valid_json=True,top_level_type=type(obj).__name__,top_level_keys=list(obj)[:50] if isinstance(obj,dict) else None)
                elif name.lower().endswith(".zip"):
                    with zipfile.ZipFile(io.BytesIO(data)) as z:
                        infos=z.infolist();unsafe=[i.filename for i in infos if i.filename.startswith(("/","\\")) or ".." in Path(i.filename).parts]
                        total=sum(i.file_size for i in infos);ratios=[(i.file_size/max(i.compress_size,1)) for i in infos]
                        suspicious=len(infos)>10000 or total>200*1024*1024 or any(r>1000 for r in ratios)
                        result.update(kind="ZIP",entries=len(infos),uncompressed_bytes=total,members=[{"name":i.filename,"bytes":i.file_size} for i in infos[:200]],unsafe_paths=unsafe,archive_suspicious=suspicious,zip_integrity="NOT_CHECKED_SAFE_LIMIT" if suspicious else ("PATH_TRAVERSAL_FOUND" if unsafe else "CENTRAL_DIRECTORY_READ_OK"),executed=False)
                result["limitations"]=["Artifact was inspected as data only; it was not executed.","A valid ZIP or JSON file is not evidence of SWI correctness."]
                self._json(result);return
            except Exception as e: self._json({"error":str(e)},400);return
        self._json({"error":"unknown endpoint"},404)

if __name__=="__main__":
    print("SWI Local Review Runner 0.2.0")
    print("Open http://127.0.0.1:%d/ in your browser"%PORT)
    print("Loopback only. Close with Ctrl+C. No remote write token is used.")
    ThreadingHTTPServer(("127.0.0.1",PORT),Handler).serve_forever()
