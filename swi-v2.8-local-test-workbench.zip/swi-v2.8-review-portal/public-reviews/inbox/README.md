# Public SWI Review Intake

Place reviewer-authored JSON and Markdown reports here only after checking them for secrets, personal information, and unsupported claims.

Recommended filename:
`SWI-REVIEW-<UTC_TIMESTAMP>-<SHORT_ID>.json`

Every report should identify:
- repository and exact commit SHA
- reviewer and review scope
- commands and environment actually used
- PASS / FAIL / ERROR / UNKNOWN / NOT RUN result
- findings, limitations and evidence references
- SHA-256 of attached artifacts where relevant

A review submission is not automatically accepted as evidence, proof, a seal, authorization, or certification. Maintainers must inspect and reconcile it before making any project claim.
