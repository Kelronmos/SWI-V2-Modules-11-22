# Local package execution status — 2026-11-04

## Verified in this packaging environment

- Narrow-path replay test suite: **15/15 PASS**.
- Default revocation scenario: replay integrity **PASS**; derived decision **REFUSE**.
- Positive control without revocation: derived decision **PERMIT_SIMULATION**; no side effects.
- Authority ceiling fields remain false in replay outputs.
- The boot hook writes timestamped evidence (`run.json`, `test_output.txt`, `report.md`).

## Not verified / not done

- Actual repository checkout was not available; canonical `runtime_binding.py` / `public_evidence_runner.py` repairs are **NOT_APPLIED**.
- Full SWI repository suite and end-to-end canonical startup: **NOT_RUN**.
- Actual app startup does not yet call this hook; integration in the live entry point remains **PENDING**.
- TLA+ TLC parsing/model checking: **NOT_RUN**; `NarrowPath.tla` remains a candidate model.
- Windows and Termux end-to-end runs: **NOT_RUN**.
- GitHub commit/push: **NOT_DONE**. Previous write attempt was reported as HTTP 403; no alternate write route was attempted.

## Authority

`PROVEN=NO` · `SEALED=NO` · `PRODUCTION_AUTHORIZED=NO` · `INDEPENDENT_REVIEW_APPROVED=NO`.
