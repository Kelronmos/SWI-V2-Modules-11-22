# SWI Public Evidence Lab — local prototype patch

**Scope:** isolated research harness and diagnostics package. Not a production release, not a canonical SWI runtime repair, and not a grant of authority.

## What this patch adds

- A small executable decision path deriving a simulated outcome from condition, evidence, authority, revocation, and execution events.
- Tamper-evident event-chain replay, with an editable JSON input so reviewers can test tampering, missing/reordered events, missing evidence, and authority revocation.
- A package-owned boot test suite with 15 adversarial/contract tests and timestamped JSON/text/Markdown evidence output.
- An orchestrator hook that runs only this package-owned suite and a revocation-during-execution replay when the harness is installed.
- A candidate TLA+ transition system for the same narrow relationship, explicitly marked NOT MODEL-CHECKED unless TLC is actually run.

## Important boundaries

- The default replay revokes authority immediately before the simulated execution attempt; the derived outcome is `REFUSE`.
- The positive branch may derive `PERMIT_SIMULATION` only to test the relationship. It has **no real side effects**.
- `PASS` means the event chain/test has met its stated technical check. It does not mean SWI is proven, sealed, independently reviewed, or production-authorized.
- Hash chains detect accidental or unsynchronized tampering. They do not authenticate an author: a user who can rewrite the whole record can recompute its hashes. Preserve the original digest outside the edited file when stronger provenance is required.
- The harness is not integrated into the canonical SWI runner or app startup entry point because the actual repository checkout was unavailable in the packaging environment. The included `run_at_boot.py` is an executable boot-test hook, not proof that the existing app calls it.
- Full SWI repository tests, canonical runtime binding, TLC model checking, Windows/Termux runtime tests, and repository commit/push remain NOT_RUN/BLOCKED.

## Install / review

Extract this ZIP, inspect the changes, then copy the reviewed `public_evidence_lab/replay/` directory into the repository. Review collisions before copying the updated `public_evidence_lab/automation/orchestrator.py`, and do not overwrite live runner or authority-engine files from this package.

### Run the narrow-path boot suite

Linux/macOS/Termux:

```sh
python3 public_evidence_lab/replay/run_at_boot.py
```

Windows PowerShell:

```powershell
py -3 public_evidence_lab/replay/run_at_boot.py
```

Each run writes `run.json`, `test_output.txt`, and `report.md` under `public_evidence_lab/evidence/boot_runs/<run-id>/`.

### Create and replay a user-editable scenario

```sh
python3 public_evidence_lab/replay/replay_engine.py --create-demo /tmp/revocation.input.json
python3 public_evidence_lab/replay/replay_engine.py --input /tmp/revocation.input.json --output /tmp/revocation.result.json
```

Edit the input JSON to try changed or missing events. The replay report records integrity errors and derives the result from event facts; it does not trust an `expected_result` field. See `public_evidence_lab/replay/README.md` for scope and limitations.

### Existing diagnostic orchestrator

```sh
python3 public_evidence_lab/automation/orchestrator.py --repo . --expected-branch prototype/public-evidence-lab-2026-11-03 --expected-head 1215f48409cd206b45e375ad89bc2c7dca5b4b56
```

It remains observation/reporting-only, defaults repairs to BLOCK, and returns nonzero if repository diagnosis or the package-owned checks do not pass. A missing replay harness is `NOT_RUN`, not a pass.

## Authority ceiling

`PROVEN=NO` · `SEALED=NO` · `PRODUCTION_AUTHORIZED=NO` · `INDEPENDENT_REVIEW_APPROVED=NO`.
