# SWI narrow-path boot test 20261104T080154630790Z

- Status: **PASS**
- Exit code: `0`
- Suite: `boot_tests.NarrowPathReplayTests`
- Output SHA-256: `6f64af2c7f4f10ae5d1a68cf29b8ac3dfdd9946d32f4e09a51b19d474b2bd7c9`

## Authority ceiling
`PROVEN=NO`, `SEALED=NO`, `PRODUCTION_AUTHORIZED=NO`, `INDEPENDENT_REVIEW_APPROVED=NO`.

## Limitations
- local harness only
- not the canonical SWI runner
- not a full repository suite
- no production actions executed
