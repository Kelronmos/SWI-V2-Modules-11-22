# Local verification record — 4 November 2026

## Executed results

- Existing package contract/model-structure tests: **9/9 PASS** (`python -m unittest discover -s tests -v`).
- Narrow-path replay tests: **15/15 PASS** (`python public_evidence_lab/replay/boot_tests.py`).
- Python source syntax compilation using `compile()` across automation, replay, and test `.py` files: **PASS**.
- Startup hook generated timestamped evidence: **PASS**.
- Default revocation-during-execution scenario: chain integrity **PASS**, derived outcome **REFUSE**, side effects **false**.
- Positive control without revocation: derived outcome **PERMIT_SIMULATION**, side effects **false**.
- Orchestrator end-to-end smoke test against a disposable, synthetic Git fixture: diagnosis/build/package boot tests/replay/manifest verification all **PASS**, process exit `0`.
- Orchestrator CSV finding export failure reproduced and repaired by aligning all diagnostic fields with CSV columns.
- Orchestrator final diagnosis self-contamination reproduced and repaired by excluding only the specific generated run directories created by that invocation from its final dirty-worktree check. Other dirty paths remain blocking.
- Informational status-engine observation no longer makes diagnosis fail solely because an INFO finding exists; CRITICAL/HIGH or explicit FAIL findings still fail.

## Boundaries

This is package-level evidence plus a synthetic fixture test. It is **not** a test of the actual `Kelronmos/SWI-V2-Modules-11-22` checkout. The actual checkout was not present in this execution environment. No canonical runner/runtime-binding source was edited, no full SWI test suite was run, and no GitHub commit was made. The TLA+ candidate was not run through TLC.

## Authority ceiling

`PROVEN=NO` · `SEALED=NO` · `PRODUCTION_AUTHORIZED=NO` · `INDEPENDENT_REVIEW_APPROVED=NO`.
