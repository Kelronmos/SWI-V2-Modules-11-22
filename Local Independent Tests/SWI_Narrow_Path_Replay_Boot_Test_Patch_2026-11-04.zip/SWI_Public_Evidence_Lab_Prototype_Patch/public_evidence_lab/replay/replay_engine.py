"""Small, deterministic SWI relationship path with tamper-evident replay.

This is a research harness, not the repository's canonical authorization engine.
No external action is executed. The only simulated action is recorded as an outcome.
"""
from __future__ import annotations
import argparse, hashlib, json, sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

SCHEMA = "swi.narrow-path.replay.v1"
AUTHORITY_CEILING = {"PROVEN": False, "SEALED": False,
                     "PRODUCTION_AUTHORIZED": False, "INDEPENDENT_REVIEW_APPROVED": False}
GENESIS = "0" * 64

def canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()

def make_event(seq: int, kind: str, payload: dict, previous_hash: str) -> dict:
    core = {"seq": seq, "kind": kind, "payload": payload, "previous_hash": previous_hash}
    return {**core, "event_hash": sha_bytes(canonical(core))}

def build_scenario(revoke_during_execution: bool = True) -> dict:
    """Scenario inputs contain facts, not a pre-filled outcome."""
    events = [
        ("REQUEST_RECEIVED", {"action": "simulated_protected_action"}),
        ("CONDITIONS_EVALUATED", {"conditions": {"scope_match": True, "context_match": True}}),
        ("EVIDENCE_CHECKED", {"evidence_ids": ["E-LOCAL-001"], "sufficient": True}),
        ("AUTHORITY_CHECKED", {"human_authority_bound": True, "authorization_valid": True}),
    ]
    if revoke_during_execution:
        events.append(("AUTHORITY_REVOKED", {"reason": "test revocation immediately before execution"}))
    events.append(("EXECUTION_ATTEMPTED", {"side_effects_enabled": False}))
    chain, prev = [], GENESIS
    for i, (kind, payload) in enumerate(events, 1):
        ev = make_event(i, kind, payload, prev)
        chain.append(ev); prev = ev["event_hash"]
    return {"schema": SCHEMA, "created_at": utc_now(), "input": {
        "action": "simulated_protected_action", "side_effects_enabled": False,
        "required_condition_names": ["scope_match", "context_match"]}, "events": chain}

def validate_chain(record: dict) -> list[dict]:
    errors=[]; prev=GENESIS
    events=record.get("events")
    if not isinstance(events, list) or not events:
        return [{"code":"EVENTS_MISSING","detail":"events must be a non-empty list"}]
    for i, ev in enumerate(events, 1):
        if not isinstance(ev, dict):
            errors.append({"code":"EVENT_INVALID","seq":i}); continue
        if ev.get("seq") != i:
            errors.append({"code":"SEQUENCE_INVALID","seq":i,"observed":ev.get("seq")})
        if ev.get("previous_hash") != prev:
            errors.append({"code":"PREVIOUS_HASH_MISMATCH","seq":i})
        core={k:ev.get(k) for k in ("seq","kind","payload","previous_hash")}
        expected=sha_bytes(canonical(core))
        if ev.get("event_hash") != expected:
            errors.append({"code":"EVENT_HASH_MISMATCH","seq":i,"expected":expected,"observed":ev.get("event_hash")})
        prev=ev.get("event_hash", "")
    return errors

def derive_outcome(record: dict) -> dict:
    """Derive permission at execution from preceding events; never trusts expected_result."""
    events=record.get("events", [])
    state={"request_seen":False,"conditions":{},"evidence_ids":[],"evidence_sufficient":False,
           "human_authority_bound":False,"authorization_valid":False,"authority_revoked":False,
           "execution_attempted":False,"side_effects_enabled":False}
    timeline=[]
    for ev in events:
        if not isinstance(ev,dict): continue
        kind,payload=ev.get("kind"),ev.get("payload") or {}
        if kind=="REQUEST_RECEIVED": state["request_seen"]=True
        elif kind=="CONDITIONS_EVALUATED": state["conditions"]=payload.get("conditions",{})
        elif kind=="EVIDENCE_CHECKED":
            state["evidence_ids"]=payload.get("evidence_ids",[])
            state["evidence_sufficient"]=payload.get("sufficient") is True
        elif kind=="AUTHORITY_CHECKED":
            state["human_authority_bound"]=payload.get("human_authority_bound") is True
            state["authorization_valid"]=payload.get("authorization_valid") is True
        elif kind=="AUTHORITY_REVOKED":
            state["authority_revoked"]=True
            state["authorization_valid"]=False
        elif kind=="EXECUTION_ATTEMPTED":
            state["execution_attempted"]=True
            state["side_effects_enabled"]=payload.get("side_effects_enabled") is True
            required=(record.get("input") or {}).get("required_condition_names", [])
            conditions=state["conditions"]
            conditions_ok=bool(required) and all(conditions.get(name) is True for name in required)
            evidence_ok=state["evidence_sufficient"] and bool(state["evidence_ids"])
            permit=(state["request_seen"] and conditions_ok and evidence_ok and state["human_authority_bound"]
                    and state["authorization_valid"] and not state["authority_revoked"])
            result="PERMIT_SIMULATION" if permit else "REFUSE"
            timeline.append({"at_event":ev.get("seq"),"conditions_ok":conditions_ok,"evidence_ok":evidence_ok,
                             "authority_valid_at_execution":state["authorization_valid"],
                             "authority_revoked":state["authority_revoked"],"derived_result":result})
    if not state["execution_attempted"]:
        result="NOT_EXECUTED"
    elif not timeline:
        result="REFUSE"
    else:
        result=timeline[-1]["derived_result"]
    # A refusal is not a test-suite failure; this is a simulated authorization decision.
    return {"derived_result":result,"state_at_end":state,"decision_timeline":timeline,
            "side_effects_performed":False,"authority_ceiling":dict(AUTHORITY_CEILING)}

def replay(record: dict) -> dict:
    errors=validate_chain(record)
    outcome=derive_outcome(record)
    if errors:
        status="FAIL"
    elif not record.get("events"):
        status="FAIL"
    else:
        status="PASS"
    return {"schema":"swi.narrow-path.replay-result.v1","replayed_at":utc_now(),"status":status,
            "integrity_errors":errors,"record_sha256":sha_bytes(canonical(record)),"outcome":outcome,
            "interpretation":"PASS means the event chain is internally reproducible, not that SWI is proven or authorized.",
            "authority_ceiling":dict(AUTHORITY_CEILING)}

def main(argv=None) -> int:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--create-demo", metavar="PATH", help="write a revocation-during-execution scenario")
    ap.add_argument("--input", metavar="PATH", help="replay a JSON record (including user-edited records)")
    ap.add_argument("--output", metavar="PATH", help="write replay result JSON")
    args=ap.parse_args(argv)
    if args.create_demo:
        p=Path(args.create_demo); p.parent.mkdir(parents=True,exist_ok=True)
        p.write_text(json.dumps(build_scenario(True),indent=2,sort_keys=True)+"\n",encoding="utf-8")
        print(f"CREATED {p}"); return 0
    if not args.input:
        ap.error("provide --create-demo PATH or --input PATH")
    try: record=json.loads(Path(args.input).read_text(encoding="utf-8"))
    except Exception as e:
        print(json.dumps({"status":"FAIL","error":f"input unreadable: {e}","authority_ceiling":AUTHORITY_CEILING},indent=2)); return 2
    result=replay(record)
    if args.output:
        out=Path(args.output); out.parent.mkdir(parents=True,exist_ok=True)
        out.write_text(json.dumps(result,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    print(json.dumps(result,indent=2,sort_keys=True))
    return 0 if result["status"]=="PASS" else 2
if __name__=="__main__": raise SystemExit(main())
