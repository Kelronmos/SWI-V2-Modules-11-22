"""Deterministic startup tests for the narrow-path replay harness."""
from __future__ import annotations
import hashlib, json, sys, tempfile, unittest
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from replay_engine import AUTHORITY_CEILING, build_scenario, canonical, make_event, replay, GENESIS

def reseal(events):
    prev=GENESIS; out=[]
    for i, old in enumerate(events,1):
        ev=make_event(i,old["kind"],old.get("payload",{}),prev)
        out.append(ev); prev=ev["event_hash"]
    return out

class NarrowPathReplayTests(unittest.TestCase):
    def test_revocation_immediately_before_execution_refuses(self):
        r=build_scenario(True); out=replay(r)
        self.assertEqual(out["status"],"PASS")
        self.assertEqual(out["outcome"]["derived_result"],"REFUSE")
        self.assertTrue(out["outcome"]["state_at_end"]["authority_revoked"])
        self.assertFalse(out["outcome"]["side_effects_performed"])
    def test_same_inputs_without_revocation_derive_permit_simulation(self):
        r=build_scenario(False); out=replay(r)
        self.assertEqual(out["status"],"PASS")
        self.assertEqual(out["outcome"]["derived_result"],"PERMIT_SIMULATION")
        self.assertFalse(out["outcome"]["side_effects_performed"])
    def test_event_payload_tampering_breaks_hash(self):
        r=build_scenario(True); r["events"][1]["payload"]["conditions"]["scope_match"]=False
        self.assertEqual(replay(r)["status"],"FAIL")
    def test_reordered_events_fail_sequence_and_chain(self):
        r=build_scenario(True); r["events"][0],r["events"][1]=r["events"][1],r["events"][0]
        self.assertEqual(replay(r)["status"],"FAIL")
    def test_missing_event_fails_closed_as_refusal(self):
        r=build_scenario(True); r["events"]=[e for e in r["events"] if e["kind"]!="AUTHORITY_CHECKED"]
        # Existing chain no longer links correctly; refusal still derives from absence of authority.
        out=replay(r); self.assertEqual(out["status"],"FAIL")
        self.assertEqual(out["outcome"]["derived_result"],"REFUSE")
    def test_empty_event_list_fails(self):
        r=build_scenario(True); r["events"]=[]
        self.assertEqual(replay(r)["status"],"FAIL")
    def test_missing_conditions_refuses_even_if_chain_resealed(self):
        r=build_scenario(False); ev=[(e["kind"],e["payload"]) for e in r["events"] if e["kind"]!="CONDITIONS_EVALUATED"]
        r["events"]=reseal([{"kind":k,"payload":p} for k,p in ev])
        out=replay(r); self.assertEqual(out["status"],"PASS")
        self.assertEqual(out["outcome"]["derived_result"],"REFUSE")
    def test_missing_evidence_refuses_even_if_chain_resealed(self):
        r=build_scenario(False)
        for e in r["events"]:
            if e["kind"]=="EVIDENCE_CHECKED": e["payload"]={"evidence_ids":[],"sufficient":False}
        r["events"]=reseal(r["events"])
        self.assertEqual(replay(r)["outcome"]["derived_result"],"REFUSE")
    def test_authority_revocation_is_order_sensitive(self):
        r=build_scenario(False); raw=[(e["kind"],e["payload"]) for e in r["events"]]
        raw.insert(-1,("AUTHORITY_REVOKED",{"reason":"revoked before execution"}))
        r["events"]=reseal([{"kind":k,"payload":p} for k,p in raw])
        self.assertEqual(replay(r)["outcome"]["derived_result"],"REFUSE")
    def test_unknown_event_does_not_create_authority(self):
        r=build_scenario(False); raw=[(e["kind"],e["payload"]) for e in r["events"]]
        raw.insert(-1,("MAGIC_AUTHORITY_GRANTED",{"granted":True}))
        r["events"]=reseal([{"kind":k,"payload":p} for k,p in raw])
        self.assertEqual(replay(r)["outcome"]["derived_result"],"PERMIT_SIMULATION")
    def test_no_expected_result_field_is_trusted(self):
        r=build_scenario(True); r["expected_result"]="PERMIT_SIMULATION"
        self.assertEqual(replay(r)["outcome"]["derived_result"],"REFUSE")
    def test_authority_ceiling_never_elevates(self):
        for revoke in (False,True):
            self.assertTrue(all(v is False for v in replay(build_scenario(revoke))["authority_ceiling"].values()))
    def test_duplicate_sequence_fails(self):
        r=build_scenario(True); r["events"][2]["seq"]=2
        self.assertEqual(replay(r)["status"],"FAIL")
    def test_simulated_action_has_no_side_effects(self):
        for revoke in (False,True):
            self.assertFalse(replay(build_scenario(revoke))["outcome"]["side_effects_performed"])
    def test_user_can_replay_edited_record_and_see_integrity_failure(self):
        r=build_scenario(True); r["events"][-1]["payload"]["side_effects_enabled"]=True
        out=replay(r); self.assertEqual(out["status"],"FAIL")
        self.assertFalse(out["outcome"]["side_effects_performed"])

if __name__=="__main__": unittest.main(verbosity=2)
