# Narrow-path replay and startup tests

This package implements one deliberately small, non-side-effecting path to examine the relationship between conditions, evidence, authority, revocation, and a simulated execution attempt. It is not integrated into the canonical SWI runtime because the actual repository checkout was not available when this patch was assembled.

## Run at startup / boot

From the repository root, after reviewing the patch:

```sh
python3 public_evidence_lab/replay/run_at_boot.py
```

Windows PowerShell:

```powershell
py -3 public_evidence_lab/replay/run_at_boot.py
```

Each invocation writes `run.json`, `test_output.txt`, and `report.md` under `public_evidence_lab/evidence/boot_runs/<run-id>/`. The suite is limited to the harness's own registered tests; it does not run arbitrary repository tests. `orchestrator.py` also invokes this package-owned boot suite when installed.

**Canonical startup integration remains pending.** The app's actual startup entry point must call `run_at_boot.py` in the real checkout and be tested there. This package does not pretend that a hook file alone proves integration.

## Create and replay a record

```sh
python3 public_evidence_lab/replay/replay_engine.py --create-demo /tmp/revocation.input.json
python3 public_evidence_lab/replay/replay_engine.py --input /tmp/revocation.input.json --output /tmp/revocation.result.json
```

Open the input JSON and change events to experiment. Editing an event without recalculating the event chain should produce `status: FAIL` due to integrity errors. If you deliberately reseal a changed chain, replay derives a new result from the new event facts; that is a *different record*, not proof the original record was authentic. The chain uses SHA-256 for tamper detection, not signatures or trusted identity; a user able to rewrite the whole record can recalculate it. Store the original digest in an independently controlled location if you need stronger provenance.

## Expected narrow-path behavior

The default scenario records authority revocation immediately before the simulated execution attempt. Replay derives `REFUSE` from the state at the execution event. A second scenario without revocation derives `PERMIT_SIMULATION` only to test the positive branch. No real action is performed (`side_effects_performed=false` in all cases).

`PASS` means the event chain is internally reproducible and valid under this harness. It does not mean SWI is proven, sealed, independently reviewed, or production-authorized. Those authority fields are hard-locked false in the output.

## Mathematical model

`truth_kernel/NarrowPath.tla` states a small transition system and safety invariants. TLC was not available for this package build, so the TLA+ model is **NOT MODEL-CHECKED**. Python tests exercise the corresponding narrow path; they do not establish formal verification of the TLA+ model or the full SWI architecture.
