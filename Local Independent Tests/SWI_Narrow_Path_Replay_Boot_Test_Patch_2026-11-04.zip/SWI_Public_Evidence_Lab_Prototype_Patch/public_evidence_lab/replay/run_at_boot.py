"""Boot hook: run the local narrow-path contract suite and preserve machine-readable evidence.

Call this from the prototype's startup path only after reviewing this file. It never changes
SWI authority states and only executes this package's registered unittest module.
"""
from __future__ import annotations
import hashlib, json, subprocess, sys
from datetime import datetime, timezone
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
OUT=ROOT/"evidence"/"boot_runs"
CEILING={"PROVEN":False,"SEALED":False,"PRODUCTION_AUTHORIZED":False,"INDEPENDENT_REVIEW_APPROVED":False}
def main():
    OUT.mkdir(parents=True,exist_ok=True)
    started=datetime.now(timezone.utc).isoformat()
    cmd=[sys.executable,"-m","unittest","-v","boot_tests"]
    proc=subprocess.run(cmd,cwd=HERE,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=False)
    completed=datetime.now(timezone.utc).isoformat()
    output=proc.stdout
    run_id=datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    out=OUT/run_id; out.mkdir()
    (out/"test_output.txt").write_text(output,encoding="utf-8")
    # unittest's summary is parsed conservatively; return code remains the primary result.
    passed=proc.returncode==0 and "OK" in output.splitlines()[-1:]
    record={"schema":"swi.boot-test-run.v1","run_id":run_id,"started_at":started,"completed_at":completed,
      "command":cmd,"cwd":str(HERE),"exit_code":proc.returncode,"status":"PASS" if passed else "FAIL",
      "registered_suite":"boot_tests.NarrowPathReplayTests","test_output_sha256":hashlib.sha256(output.encode()).hexdigest(),
      "test_output":"test_output.txt","authority_ceiling":CEILING,
      "limitations":["local harness only","not the canonical SWI runner","not a full repository suite","no production actions executed"]}
    (out/"run.json").write_text(json.dumps(record,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    report=(f"# SWI narrow-path boot test {run_id}\n\n- Status: **{record['status']}**\n- Exit code: `{proc.returncode}`\n- Suite: `{record['registered_suite']}`\n- Output SHA-256: `{record['test_output_sha256']}`\n\n## Authority ceiling\n`PROVEN=NO`, `SEALED=NO`, `PRODUCTION_AUTHORIZED=NO`, `INDEPENDENT_REVIEW_APPROVED=NO`.\n\n## Limitations\n"+"\n".join(f"- {x}" for x in record["limitations"])+"\n")
    (out/"report.md").write_text(report,encoding="utf-8")
    print(json.dumps({"run_id":run_id,"status":record["status"],"evidence_dir":str(out),"exit_code":proc.returncode},indent=2))
    return 0 if passed else 2
if __name__=="__main__": raise SystemExit(main())
