----------------------------- MODULE NarrowPath -----------------------------
EXTENDS Naturals, FiniteSets

CONSTANTS TRUE_VALUE, FALSE_VALUE
VARIABLES stage, conditionsOK, evidenceOK, authorityValid, authorityRevoked, decision
vars == <<stage, conditionsOK, evidenceOK, authorityValid, authorityRevoked, decision>>

Init ==
  /\ stage = "REQUESTED"
  /\ conditionsOK = FALSE_VALUE
  /\ evidenceOK = FALSE_VALUE
  /\ authorityValid = FALSE_VALUE
  /\ authorityRevoked = FALSE_VALUE
  /\ decision = "UNDECIDED"

EvaluateConditions(ok) ==
  /\ stage = "REQUESTED"
  /\ conditionsOK' = ok
  /\ stage' = "CONDITIONS_EVALUATED"
  /\ UNCHANGED <<evidenceOK, authorityValid, authorityRevoked, decision>>

CheckEvidence(ok) ==
  /\ stage = "CONDITIONS_EVALUATED"
  /\ evidenceOK' = ok
  /\ stage' = "EVIDENCE_CHECKED"
  /\ UNCHANGED <<conditionsOK, authorityValid, authorityRevoked, decision>>

BindAuthority(valid) ==
  /\ stage = "EVIDENCE_CHECKED"
  /\ authorityValid' = valid
  /\ stage' = "AUTHORITY_BOUND"
  /\ UNCHANGED <<conditionsOK, evidenceOK, authorityRevoked, decision>>

RevokeAuthority ==
  /\ stage = "AUTHORITY_BOUND"
  /\ authorityRevoked' = TRUE_VALUE
  /\ authorityValid' = FALSE_VALUE
  /\ stage' = "AUTHORITY_REVOKED"
  /\ UNCHANGED <<conditionsOK, evidenceOK, decision>>

AttemptExecution ==
  /\ stage \in {"AUTHORITY_BOUND", "AUTHORITY_REVOKED"}
  /\ decision' = IF conditionsOK = TRUE_VALUE
                    /\ evidenceOK = TRUE_VALUE
                    /\ authorityValid = TRUE_VALUE
                    /\ authorityRevoked = FALSE_VALUE
                  THEN "PERMIT_SIMULATION"
                  ELSE "REFUSE"
  /\ stage' = "DECIDED"
  /\ UNCHANGED <<conditionsOK, evidenceOK, authorityValid, authorityRevoked>>

Next ==
  \/ \E ok \in {TRUE_VALUE, FALSE_VALUE} : EvaluateConditions(ok)
  \/ \E ok \in {TRUE_VALUE, FALSE_VALUE} : CheckEvidence(ok)
  \/ \E valid \in {TRUE_VALUE, FALSE_VALUE} : BindAuthority(valid)
  \/ RevokeAuthority
  \/ AttemptExecution

Spec == Init /\ [][Next]_vars

DecisionIsBounded == decision \in {"UNDECIDED", "PERMIT_SIMULATION", "REFUSE"}
RevocationCannotPermit == authorityRevoked = TRUE_VALUE => decision # "PERMIT_SIMULATION"
MissingConditionCannotPermit == conditionsOK = FALSE_VALUE => decision # "PERMIT_SIMULATION"
MissingEvidenceCannotPermit == evidenceOK = FALSE_VALUE => decision # "PERMIT_SIMULATION"

=============================================================================
