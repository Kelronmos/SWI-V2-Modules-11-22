# HA-before-execute repair — prototype patch only

## Scope
Patch is prepared against the public `main` source version of
`swi_v2/execution_integrity.py` whose blob SHA was observed as
`e4b970ac14377f41f847a00738c72039c8ee408e`.

This is an offline patch artifact. GitHub rejected branch creation with HTTP 403,
so this package has **not** changed the remote repository and is not a PR.

## Intended behavior
- Matching route without an action-bound authority returns `UNKNOWN`.
- No permit is minted and the synthetic execution counter remains zero.
- Authority is bound to an exact action identifier.
- New information clears the previous binding.
- The added tests use only the repository's synthetic demo action.

## Apply locally
From the repository root, inspect the patch first, then run:

```bash
git status --short
git switch -c fix/ha-before-execute-prototype-only
git apply --check /path/to/ha_before_execute.patch
git apply /path/to/ha_before_execute.patch
```

Copy `tests/test_authority_bound_execute.py` into
`test/adversarial/test_authority_bound_execute.py` (or adjust the import path
if your checkout's test layout differs).

Then run the new tests and the relevant existing tests. Existing happy-path tests
that expected execution without authority will need to be updated to bind a
synthetic authority explicitly; do not weaken the new refusal assertions just to
make legacy tests pass.

## Important limitations
`validate_human_authority()` currently validates object shape, non-empty token,
and workflow/action equality. It does **not** authenticate a real person, verify
a trusted identity provider, or establish legal/organizational authority.
Therefore the synthetic authority in these tests is a test fixture only.

Status remains:
`PROTOTYPE_PATCH_ONLY`
`PROVEN=NO`
`SEALED=NO`
`SWI_BOUND=NO`
`PRODUCTION_AUTHORIZED=NO`
