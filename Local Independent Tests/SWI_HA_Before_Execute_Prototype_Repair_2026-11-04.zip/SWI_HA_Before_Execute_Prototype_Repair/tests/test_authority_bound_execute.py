"""Prototype-only adversarial tests for HA-before-execute.

These tests exercise the synthetic demo action only. They do not establish
real human authority, production authorization, or deployment readiness.
"""
from swi_v2.execution_integrity import (
    AdmittedRoute, Decision, ExecutionIntegrityGate, IncomingNode,
    HumanAuthority, NewInformation, validate_human_authority,
)

def make_case():
    admitted = AdmittedRoute("W-TEST", "R-OK", "N-TEST", "I-OK", "P-OK", "A-OK")
    gate = ExecutionIntegrityGate(admitted)
    node = IncomingNode("N-TEST", "W-TEST", "R-OK", "I-OK", "P-OK", "A-OK")
    return admitted, gate, node

def bind_default(gate):
    authority = validate_human_authority(
        HumanAuthority("SYNTHETIC-AUTHORITY", "W-TEST", "default_action", "prototype-token"),
        workflow_id="W-TEST",
        action_id="default_action",
    )
    gate.bind_authority(authority, action_id="default_action")

def test_matching_route_without_authority_is_unknown_and_does_not_execute():
    _, gate, node = make_case()
    result = gate.execute(node)
    assert result.decision == Decision.UNKNOWN
    assert result.execution_occurred is False
    assert gate.execution_counter == 0

def test_matching_route_with_synthetic_bound_authority_allows_demo_only():
    _, gate, node = make_case()
    bind_default(gate)
    result = gate.execute(node)
    assert result.decision == Decision.EXECUTION_ALLOWED
    assert result.execution_occurred is True
    assert gate.execution_counter == 1

def test_new_information_clears_previous_authority_binding():
    _, gate, node = make_case()
    bind_default(gate)
    gate.apply_new_information(
        NewInformation("prototype boundary change", True, information_id="NI-TEST")
    )
    result = gate.execute(node)
    assert result.decision == Decision.UNKNOWN
    assert result.execution_occurred is False
    assert gate.execution_counter == 0

def test_wrong_action_binding_does_not_authorize_default_action():
    _, gate, node = make_case()
    authority = validate_human_authority(
        HumanAuthority("SYNTHETIC-AUTHORITY", "W-TEST", "delete_file", "prototype-token"),
        workflow_id="W-TEST",
        action_id="delete_file",
    )
    gate.bind_authority(authority, action_id="delete_file")
    result = gate.execute(node)
    assert result.decision == Decision.UNKNOWN
    assert result.execution_occurred is False
    assert gate.execution_counter == 0
