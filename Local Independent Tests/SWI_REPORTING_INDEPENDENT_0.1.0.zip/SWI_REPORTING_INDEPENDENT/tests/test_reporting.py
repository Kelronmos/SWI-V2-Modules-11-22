import pytest
from python.swi_reporting.records import make_synthetic_record
from python.swi_reporting.validation import validate_record
from python.swi_reporting.integrity import sha256_file

def test_synthetic_record_validates():
    r=make_synthetic_record(); validate_record(r); assert r['record_classification']=='SYNTHETIC_TEST_DATA'

def test_authorization_ceiling_is_enforced():
    r=make_synthetic_record(); r['authorization']['production_authorized']='YES'
    with pytest.raises(ValueError,match='ceiling'): validate_record(r)

def test_unknown_is_preserved():
    r=make_synthetic_record(); assert r['tests'][1]['status']=='UNKNOWN'; assert r['repository']['commit_sha'] is None

def test_bad_status_rejected():
    r=make_synthetic_record(); r['tests'][0]['status']='GREEN'
    with pytest.raises(ValueError,match='schema validation'): validate_record(r)
