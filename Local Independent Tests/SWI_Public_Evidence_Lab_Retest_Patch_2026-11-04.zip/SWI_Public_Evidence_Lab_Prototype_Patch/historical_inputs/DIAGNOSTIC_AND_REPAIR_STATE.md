# SWI Public Evidence Lab — Diagnostic and Repair State Record

**Date:** 2026-11-03  
**Repository:** `Kelronmos/SWI-V2-Modules-11-22`  
**Target branch:** `prototype/public-evidence-lab-2026-11-03`  
**Observed branch HEAD:** `1215f48409cd206b45e375ad89bc2c7dca5b4b56`  
**Expected starting HEAD:** `1215f48409cd206b45e375ad89bc2c7dca5b4b56`  
**Comparison:** identical; 0 ahead / 0 behind  
**Write attempt:** GitHub returned HTTP 403 `Resource not accessible by integration`.

## Executive result

The target branch was inspected read-only. Source-level defects are confirmed. No repository source was changed, no repair commit exists, and no test/replay execution was performed. The requested repair is therefore **BLOCKED**, not complete.

## Verified source inventory

| File | Observed blob SHA |
|---|---|
| `public_evidence_lab/runner/runtime_binding.py` | `aa017c373f3ff45b237090825e75e14a54dd929a` |
| `public_evidence_lab/runner/public_evidence_runner.py` | `35c8373a10b10198abcedd48ef4346c9c67dc0de` |
| `public_evidence_lab/tests/test_public_evidence_runner.py` | `f64ab9bfd671b4c8c4580cc0a83573602b00fe62` |
| `public_evidence_lab/public/index.html` | `474176aca4ee4d06968c03a06d83288fddb64b66` |
| `runner/status_engine.py` | `3164dfe69a8a7126f786a631c00985f87f102ae6` |

## Diagnosed defects

1. **Dirty worktree can still be called runtime-bound.** The adapter sets `runtime_bound` from the presence of an observed commit only. `dirty` is collected but does not gate the result.
2. **Expected commit mismatch does not fail binding.** `commit_match` is calculated for reporting, but is not part of `runtime_bound`.
3. **Incomplete Git metadata is accepted.** The adapter's `binding_status` is based on commit presence; branch, origin remote, and successful dirty-state observation are not required.
4. **Git failures are collapsed.** `_run_git` returns `None` for failures and does not preserve command, exit code, stderr, timeout, or executable identity.
5. **Ambiguous governing-engine import.** `from runner.status_engine import ...` can resolve a different package based on `sys.path`; it does not prove that `<observed repository root>/runner/status_engine.py` was loaded.
6. **Canonical runner bypasses the adapter.** `public_evidence_runner.py` has a separate `detect_git()` implementation and never consumes `runtime_binding.bind()`.
7. **Canonical runner has no binding check.** It only tests whether a commit string exists; it does not fail on dirty state, incomplete metadata, or expected SHA mismatch.
8. **HTML check is a false PASS.** The runner reports `HTML_PROTOTYPE_PRESENT` as true with the text `public-prototype/index.html expected`, without checking a file. The actual page is `public_evidence_lab/public/index.html`.
9. **Process/runtime evidence is incomplete.** The canonical record captures basic process inventory, but not the actual runner entry point, runtime start/completion interval, or a complete structured binding observation.
10. **Tests are insufficient.** The six existing tests cover locked claims, record shape, user-entered SHA labelling, unverified spine, basic exports, and hash presence. They do not test dirty/mismatch/missing-Git/shadowed-import/engine-load failures or end-to-end canonical binding.
11. **Manifest self-hash ambiguity.** The manifest is serialized and hashed, then rewritten with the hash included. The stored hash therefore describes the pre-final-write bytes, not the final manifest bytes. The format needs an explicit self-hash convention or detached checksum.
12. **No CI status evidence returned.** The queried commit had an empty combined-status list. This is not proof that tests passed or failed; test execution remains NOT_RUN.

## Existing governing ceiling

The exact repository file `runner/status_engine.py` exposes `overall_swi_ceiling()`. Its returned ceiling includes:
- `system_completion = INCOMPLETE`
- `proven = NO`
- `sealed = NO`
- `production_ready = UNKNOWN`
- `production_authorized = NO`
- `authorization_granted = false`
- `action_permitted = false`

The lab repair must observe this exact root file read-only. It must not create another authorization engine or elevate any authority state.

## Required repair sequence

1. Repair `runtime_binding.py` to preserve Git command diagnostics and require complete metadata, clean tracked/untracked worktree, valid full commit SHA, and expected-SHA match when supplied.
2. Load `runner/status_engine.py` by exact path beneath the observed repository root; record its resolved path and read-only ceiling. Import failure or path mismatch must return NOT_VERIFIED.
3. Integrate the adapter as the canonical runner's sole repository-identity observer. Remove duplicate Git identity logic from the canonical record path.
4. Add an independent `RUNTIME_BINDING` check. Any mismatch, dirty tree, incomplete metadata, or missing root engine must fail closed.
5. Replace the hardcoded HTML PASS with a filesystem check against `public/index.html` relative to the lab root.
6. Expand adversarial tests using temporary Git repositories and isolated import paths. Include clean, tracked-dirty, untracked, expected-match, expected-mismatch, missing repo, unavailable Git, incomplete metadata, fake user SHA, exact root engine, missing engine, import-shadowing, and all authority fields remaining false.
7. Repair manifest integrity semantics: hash each artifact's exact final bytes; use a detached manifest checksum or clearly exclude the checksum field from its own digest.
8. Run the lab tests, canonical first-start run, canonical subsequent-start run, and replay/reproducibility checks separately. Preserve commands, working directories, exit codes, outputs, artifact hashes, and limitations.
9. Write a timestamped diagnostic/repair report to the repository evidence reports directory, then commit only to the isolated target branch after local verification.

## Repair state ledger

| Work item | State | What was repaired |
|---|---|---|
| Remote branch / starting HEAD verification | PASS | Read-only identity comparison only |
| Runtime binding adapter | BLOCKED | Nothing changed; write permission denied |
| Canonical runner integration | BLOCKED | Nothing changed |
| HTML existence check | BLOCKED | Nothing changed |
| Adversarial tests | NOT_RUN | No test environment/checkout available |
| Full lab test suite | NOT_RUN | Not executed |
| First-start run | NOT_RUN | Not executed |
| Subsequent-start run | NOT_RUN | Not executed |
| Replay / reproducibility | NOT_RUN | Not executed |
| Manifest integrity retest | NOT_RUN | Not executed |
| Timestamped report in repository | BLOCKED | This local diagnostic is not uploaded |
| Repository commit / push | BLOCKED | GitHub write API returned 403 |

## Authority invariants

`PROVEN=NO`  
`SEALED=NO`  
`PRODUCTION_AUTHORIZED=NO`  
`INDEPENDENT_REVIEW_APPROVED=NO`

`IMPLEMENTED != TESTED != PROVEN != SEALED != PRODUCTION_AUTHORIZED`

## Required access to proceed

The linked GitHub integration needs authorized write access to the target repository/branch, or a writable local Git checkout must be supplied. Do not bypass the 403 using a different Git API route. Once access is available, apply the repairs, run the tests and replay, upload this report and the resulting evidence, then verify the resulting branch HEAD and changed-file list.
