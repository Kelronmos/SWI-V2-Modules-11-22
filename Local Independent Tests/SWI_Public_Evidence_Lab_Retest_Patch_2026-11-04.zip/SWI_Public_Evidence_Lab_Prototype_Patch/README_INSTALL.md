# SWI Public Evidence Lab — Local Prototype Patch Package

**Scope:** local prototype only. Not production-ready. Does not authorize actions, admit evidence, seal SWI, or establish ISO conformity.

## Important baseline gate
The diagnostic inputs supplied with this package record:
- Repository: `Kelronmos/SWI-V2-Modules-11-22`
- Branch: `prototype/public-evidence-lab-2026-11-03`
- Expected starting HEAD: `1215f48409cd206b45e375ad89bc2c7dca5b4b56`
- Previous GitHub write attempt: HTTP 403, `Resource not accessible by integration`
- Previous tests: NOT_RUN

This package was assembled from those diagnostic records. The actual repository checkout/source files were not present in the execution workspace, so it does **not** claim to have repaired the canonical runner or validated the recorded HEAD. Run the preflight against the real checkout before applying anything.

## Local install
1. Extract this ZIP.
2. Copy `public_evidence_lab/automation/` into the repository's existing `public_evidence_lab/automation/` directory, reviewing any collisions first.
3. Copy `.github/workflows/public-evidence-lab-continuous.yml` only after reviewing the workflow permissions and branch filters.
4. Do not overwrite `runtime_binding.py` or `public_evidence_runner.py` from this package: source-level integration must be made against the live files and tested in the target checkout.
5. From the repository root run:

Linux/macOS/Termux:
```sh
python3 public_evidence_lab/automation/orchestrator.py --repo . --expected-branch prototype/public-evidence-lab-2026-11-03 --expected-head 1215f48409cd206b45e375ad89bc2c7dca5b4b56
```

Windows PowerShell:
```powershell
py -3 public_evidence_lab/automation/orchestrator.py --repo . --expected-branch prototype/public-evidence-lab-2026-11-03 --expected-head 1215f48409cd206b45e375ad89bc2c7dca5b4b56
```

The orchestrator is observation/reporting-only by default. Repair policy defaults to BLOCK. It does not perform automatic source edits. Any mismatch or dirty state must be reviewed before running it against a real checkout.

## Status interpretation
`PASS` is a result for a named technical check only. It does not mean PROVEN, SEALED, authorized, or production-ready. Hashes establish byte equality under the stated procedure, not truth or authority.

## Current limitations
- No actual project checkout was available during package generation.
- Canonical runner/runtime-binding source changes remain pending.
- Tests in this package have not been run against the actual SWI repository.
- GitHub artifact upload and commit have not been attempted from this package.
