# TruthKernel candidate model status

- The uploaded `TruthKernel.tla` is preserved unchanged under `review_inputs/TruthKernel.original.tla`.
- `TruthKernel.candidate.tla` repairs the empty-chain indexing and renames the action to avoid colliding with the built-in sequence `Append` operator.
- `Hash(event, previousHash) == <<event, previousHash>>` is an abstract structural link for model checking, **not cryptographic hashing**.
- `Events` must be assigned a finite set in a TLC model configuration.
- TLC/TLA+ tooling was not installed in this execution environment, so parser/model checking is **NOT RUN**. This candidate is not called VERIFIED.
