----------------------------- MODULE TruthKernel -----------------------------
EXTENDS Naturals, Sequences

CONSTANT Events
VARIABLES log, hashChain
vars == <<log, hashChain>>

Init ==
  /\ log = << >>
  /\ hashChain = << >>

(* Abstract structural link for model checking only; NOT cryptographic hashing. *)
Hash(event, previousHash) == <<event, previousHash>>

AppendEvent(event) ==
  /\ log' = Append(log, event)
  /\ hashChain' = Append(
       hashChain,
       Hash(event, IF Len(hashChain) = 0
                   THEN "GENESIS"
                   ELSE hashChain[Len(hashChain)])
     )

Next == \E event \in Events : AppendEvent(event)
Spec == Init /\ [][Next]_vars

IntegrityInvariant ==
  /\ Len(log) = Len(hashChain)
  /\ \A i \in 1..Len(log):
       hashChain[i] = Hash(log[i], IF i = 1
                                   THEN "GENESIS"
                                   ELSE hashChain[i - 1])

=============================================================================
