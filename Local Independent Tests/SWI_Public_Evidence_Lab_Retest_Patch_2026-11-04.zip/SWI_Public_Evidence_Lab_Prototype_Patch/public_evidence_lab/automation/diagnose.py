"""Read-only repository/runtime diagnosis for SWI Public Evidence Lab."""
from __future__ import annotations
import hashlib, json, os, platform, subprocess, sys, time
from datetime import datetime, timezone
from pathlib import Path

STATUSES = {"NOT_RUN","STARTED","PASS","FAIL","UNKNOWN","HALTED","BLOCKED","ERROR","NOT_PROVEN"}
def now():
    return datetime.now(timezone.utc).isoformat()
def sha256_bytes(b):
    return hashlib.sha256(b).hexdigest()
def run_cmd(args, cwd, timeout=10):
    started = time.monotonic()
    rec = {"command": args, "cwd": str(cwd), "started_at": now()}
    try:
        p = subprocess.run(args, cwd=str(cwd), capture_output=True, text=True,
                           timeout=timeout, check=False)
        rec.update(status="PASS" if p.returncode == 0 else "FAIL",
                   exit_code=p.returncode, stdout=p.stdout, stderr=p.stderr,
                   duration_seconds=round(time.monotonic()-started, 6), timed_out=False)
    except subprocess.TimeoutExpired as e:
        rec.update(status="ERROR", exit_code=None, stdout=str(e.stdout or ""),
                   stderr=str(e.stderr or ""), timed_out=True, error="timeout",
                   duration_seconds=round(time.monotonic()-started, 6))
    except (OSError, ValueError) as e:
        rec.update(status="ERROR", exit_code=None, stdout="", stderr="",
                   timed_out=False, error=f"{type(e).__name__}: {e}",
                   duration_seconds=round(time.monotonic()-started, 6))
    rec["ended_at"] = now()
    return rec
def finding(fid, severity, component, path, description, expected, observed, status="NOT_PROVEN"):
    return {"finding_id":fid,"timestamp":now(),"severity":severity,"component":component,
            "path":path,"description":description,"expected":expected,"observed":observed,
            "reproduction_command":None,"evidence_reference":None,
            "repair_eligible":False,"repair_status":"NOT_RUN","verification_status":status}
def diagnose(repo, expected_branch=None, expected_head=None):
    repo=Path(repo).resolve()
    run_id=datetime.now(timezone.utc).strftime("SWI-%Y%m%dT%H%M%S%fZ")
    commands=[]
    def git(*args): 
        r=run_cmd(["git",*args], repo); commands.append(r); return r
    top=git("rev-parse","--show-toplevel")
    inside=top["status"]=="PASS" and Path(top["stdout"].strip()).resolve()==repo
    branch=git("branch","--show-current")
    head=git("rev-parse","--verify","HEAD^{commit}")
    remote=git("remote","get-url","origin")
    porcelain=git("status","--porcelain=v1","--untracked-files=all")
    status=git("status","--short","--branch")
    findings=[]
    def observed(rec, field="stdout"):
        return rec.get(field,"").strip() if rec.get(field) is not None else None
    if not inside:
        findings.append(finding("D-AUTO-001","CRITICAL","repository",None,"Repository root could not be verified as the supplied path.","Verified Git root",observed(top),"FAIL"))
    b=observed(branch)
    if branch["status"]!="PASS" or not b:
        findings.append(finding("D-AUTO-002","CRITICAL","git",None,"Branch identity unavailable.","Expected branch observed",b,"FAIL"))
    elif expected_branch and b!=expected_branch:
        findings.append(finding("D-AUTO-003","CRITICAL","git",None,"Branch does not match required prototype branch.",expected_branch,b,"FAIL"))
    h=observed(head)
    if head["status"]!="PASS" or len(h)!=40 or any(c not in "0123456789abcdef" for c in h.lower()):
        findings.append(finding("D-AUTO-004","CRITICAL","git",None,"Full commit SHA could not be verified.","Full 40-character commit SHA",h,"FAIL"))
    elif expected_head and h.lower()!=expected_head.lower():
        findings.append(finding("D-AUTO-005","CRITICAL","git",None,"HEAD differs from expected baseline; no changes should be made automatically.",expected_head,h,"FAIL"))
    if remote["status"]!="PASS" or not observed(remote):
        findings.append(finding("D-AUTO-006","HIGH","git",None,"Origin remote is unavailable.","Configured origin remote",observed(remote),"FAIL"))
    dirty=porcelain["status"]!="PASS" or bool(observed(porcelain))
    if dirty:
        findings.append(finding("D-AUTO-007","CRITICAL","git",None,"Working tree is dirty or status could not be observed.","Clean tracked and untracked state","dirty/unavailable","FAIL"))
    required=["public_evidence_lab/README.md","public_evidence_lab/runner/runtime_binding.py",
              "public_evidence_lab/runner/public_evidence_runner.py",
              "public_evidence_lab/tests/test_public_evidence_runner.py",
              "public_evidence_lab/public/index.html","runner/status_engine.py"]
    for i, rel in enumerate(required,1):
        p=repo/rel
        if not p.is_file():
            findings.append(finding(f"D-FILE-{i:03}","HIGH","application",rel,"Required file missing.","Regular file exists","missing","FAIL"))
    engine=repo/"runner/status_engine.py"
    if engine.is_file():
        try:
            import importlib.util
            spec=importlib.util.spec_from_file_location("_swi_exact_status_engine_diagnostic",engine)
            mod=importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            ceiling=mod.overall_swi_ceiling() if callable(getattr(mod,"overall_swi_ceiling",None)) else None
            findings.append(finding("D-SWI-001","INFO","swi_authority","runner/status_engine.py",
                "Status engine loaded by exact path for observation only.","Read-only ceiling observable",
                {"resolved_path":str(engine.resolve()),"ceiling":ceiling},
                "PASS" if ceiling is not None else "NOT_PROVEN"))
        except Exception as e:
            findings.append(finding("D-SWI-001","CRITICAL","swi_authority","runner/status_engine.py",
                "Exact-path status-engine load failed.","Read-only ceiling observable",f"{type(e).__name__}: {e}","FAIL"))
    runtime={"python_executable":sys.executable,"python_version":sys.version,
             "platform":platform.platform(),"architecture":platform.machine(),
             "pid":os.getpid(),"cwd":os.getcwd(),"started_at":now()}
    return {"schema":"swi.public-evidence-lab.diagnosis.v1","run_id":run_id,"timestamp":now(),
            "repository":str(repo),"branch":b,"head":h,"expected_branch":expected_branch,
            "expected_head":expected_head,"working_tree":"DIRTY" if dirty else "CLEAN" if porcelain["status"]=="PASS" else "UNKNOWN",
            "remote":observed(remote),"runtime":runtime,"commands":commands,"findings":findings,
            "authority":{"PROVEN":False,"SEALED":False,"PRODUCTION_AUTHORIZED":False,
                         "INDEPENDENT_REVIEW_APPROVED":False},
            "status":"PASS" if not findings and all(c["status"]=="PASS" for c in commands) else "FAIL"}
def main():
    import argparse
    ap=argparse.ArgumentParser()
    ap.add_argument("--repo",default=".")
    ap.add_argument("--expected-branch")
    ap.add_argument("--expected-head")
    ap.add_argument("--out")
    a=ap.parse_args()
    result=diagnose(a.repo,a.expected_branch,a.expected_head)
    raw=(json.dumps(result,indent=2,sort_keys=True)+"\n").encode()
    if a.out:
        p=Path(a.out); p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(raw)
    print(raw.decode(),end="")
    return 0 if result["status"]=="PASS" else 2
if __name__=="__main__": raise SystemExit(main())
