"""Conservative, local-only diagnosis and evidence packaging orchestrator."""
import argparse, csv, hashlib, json, os, platform, subprocess, sys, time
from datetime import datetime, timezone
from pathlib import Path
from diagnose import diagnose
from verify_manifest import verify
def now(): return datetime.now(timezone.utc).isoformat()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--repo",default=".")
    ap.add_argument("--expected-branch")
    ap.add_argument("--expected-head")
    ap.add_argument("--evidence-root",default="public_evidence_lab/evidence/runs")
    a=ap.parse_args()
    repo=Path(a.repo).resolve(); started=now()
    d1=diagnose(repo,a.expected_branch,a.expected_head)
    run_id=d1["run_id"]; out=(repo/a.evidence_root/run_id).resolve()
    if repo not in out.parents:
        print("BLOCKED: evidence path escapes repository",file=sys.stderr); return 3
    out.mkdir(parents=True,exist_ok=False)
    (out/"initial_diagnosis.json").write_text(json.dumps(d1,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    policy_path=repo/"public_evidence_lab/automation/repair_policy.json"
    policy={"status":"BLOCKED","reason":"repair policy not found"}
    if policy_path.is_file():
        try:
            p=json.loads(policy_path.read_text(encoding="utf-8"))
            policy={"status":"PASS" if p.get("default_action")=="BLOCK" and p.get("automatic_source_repairs_enabled") is False else "FAIL",
                    "default_action":p.get("default_action"),"automatic_source_repairs_enabled":p.get("automatic_source_repairs_enabled")}
        except Exception as e: policy={"status":"FAIL","reason":str(e)}
    (out/"repair_ledger.json").write_text(json.dumps({"status":"REPAIR_NOT_REQUIRED","policy":policy,"attempts":[],
       "note":"No source repairs are executed by this orchestrator."},indent=2)+"\n",encoding="utf-8")
    # Build is intentionally an observation-only compile check; no dependency installation.
    pyfiles=[]
    for base in [repo/"public_evidence_lab"]:
        if base.exists(): pyfiles.extend(x for x in base.rglob("*.py") if "__pycache__" not in x.parts)
    compile_errors=[]
    for p in pyfiles:
        try: compile(p.read_bytes(),str(p),"exec")
        except Exception as e: compile_errors.append({"path":str(p.relative_to(repo)),"error":f"{type(e).__name__}: {e}"})
    build={"status":"PASS" if pyfiles and not compile_errors else "FAIL" if compile_errors else "NOT_RUN",
           "command":"python compile() over discovered public_evidence_lab/**/*.py",
           "files_checked":len(pyfiles),"errors":compile_errors,"dependency_installation":"NOT_RUN"}
    (out/"build_report.json").write_text(json.dumps(build,indent=2)+"\n",encoding="utf-8")
    # Never run arbitrary tests from a repository without the user reviewing commands; record discovery.
    tests=list((repo/"public_evidence_lab/tests").glob("test*.py")) if (repo/"public_evidence_lab/tests").is_dir() else []
    test_report={"status":"NOT_RUN","reason":"This conservative package does not execute repository-supplied tests automatically.",
                 "discovered_test_files":[str(p.relative_to(repo)) for p in tests],"test_count":None,
                 "authority":{"PROVEN":False,"SEALED":False,"PRODUCTION_AUTHORIZED":False,"INDEPENDENT_REVIEW_APPROVED":False}}
    (out/"test_report.json").write_text(json.dumps(test_report,indent=2)+"\n",encoding="utf-8")
    replay={"status":"NOT_RUN","reason":"Replay requires the actual runner and recorded input contracts; no synthetic replay was claimed."}
    (out/"replay_report.json").write_text(json.dumps(replay,indent=2)+"\n",encoding="utf-8")
    d2=diagnose(repo,a.expected_branch,a.expected_head)
    (out/"final_diagnosis.json").write_text(json.dumps(d2,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    independent={"status":"NOT_PROVEN","reason":"No isolated clean checkout was created; this run is not independent verification.",
                 "diagnosis_status":d2["status"]}
    (out/"independent_verification.json").write_text(json.dumps(independent,indent=2)+"\n",encoding="utf-8")
    run={"schema":"swi.public-evidence-lab.run.v1","run_id":run_id,"repository":str(repo),
         "branch":d1.get("branch"),"initial_head":d1.get("head"),"final_head":d2.get("head"),
         "started_at":started,"completed_at":now(),"python":sys.version,"platform":platform.platform(),
         "repair_policy":policy,"build_status":build["status"],"tests_status":test_report["status"],
         "replay_status":replay["status"],"diagnosis_status":d2["status"],
         "authority":{"PROVEN":False,"SEALED":False,"PRODUCTION_AUTHORIZED":False,"INDEPENDENT_REVIEW_APPROVED":False}}
    (out/"run.json").write_text(json.dumps(run,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    report=f"""# SWI Public Evidence Lab Run {run_id}

- Repository path: `{repo}`
- Branch: `{d1.get('branch')}`
- Initial HEAD: `{d1.get('head')}`
- Final HEAD: `{d2.get('head')}`
- Diagnosis: **{d2['status']}**
- Build syntax check: **{build['status']}**
- Tests: **{test_report['status']}**
- Replay: **{replay['status']}**
- Independent verification: **{independent['status']}**

## Limitations
This report records local observations only. It does not claim the canonical runtime binding is repaired, tests passed, replay matched, or the run is independently verified.

## Authority ceiling
`PROVEN=NO`, `SEALED=NO`, `PRODUCTION_AUTHORIZED=NO`, `INDEPENDENT_REVIEW_APPROVED=NO`.
"""
    (out/"report.md").write_text(report,encoding="utf-8")
    (out/"report.txt").write_text(report,encoding="utf-8")
    with (out/"report.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=["finding_id","severity","component","path","description","expected","observed","verification_status"])
        w.writeheader(); w.writerows(d2["findings"])
    artifacts=[]
    for p in sorted(out.iterdir()):
        if p.is_file() and p.name not in {"evidence_manifest.json","evidence_manifest.json.sha256"}:
            artifacts.append({"path":p.name,"sha256":sha(p),"size_bytes":p.stat().st_size})
    manifest={"schema":"swi.public-evidence-lab.evidence-manifest.v1","run_id":run_id,
              "hash_scope":"SHA-256 of exact final bytes; detached checksum is not included as an artifact.",
              "artifacts":artifacts}
    mp=out/"evidence_manifest.json"; mp.write_text(json.dumps(manifest,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    (out/"evidence_manifest.json.sha256").write_text(f"{sha(mp)}  evidence_manifest.json\n",encoding="utf-8")
    verified=verify(mp)
    (out/"manifest_verification.json").write_text(json.dumps(verified,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({"run_id":run_id,"evidence_dir":str(out),"diagnosis":d2["status"],
                      "build":build["status"],"tests":test_report["status"],"replay":replay["status"],
                      "manifest_verification":verified["status"]},indent=2))
    return 0 if d2["status"]=="PASS" and build["status"]=="PASS" and test_report["status"]=="PASS" else 2
if __name__=="__main__": raise SystemExit(main())
