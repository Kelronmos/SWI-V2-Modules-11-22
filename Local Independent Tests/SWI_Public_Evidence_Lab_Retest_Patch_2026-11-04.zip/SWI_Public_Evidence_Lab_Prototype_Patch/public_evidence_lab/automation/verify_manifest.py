"""Verify detached SHA-256 manifest checksum and listed artifact bytes."""
import hashlib, json, sys
from pathlib import Path
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def verify(manifest_path):
    m=Path(manifest_path).resolve()
    checksum=Path(str(m)+".sha256")
    if not m.is_file() or not checksum.is_file():
        return {"status":"FAIL","reason":"manifest or detached checksum missing"}
    expected=checksum.read_text(encoding="utf-8").split()[0]
    actual=sha(m)
    if expected != actual:
        return {"status":"FAIL","reason":"manifest checksum mismatch","expected":expected,"actual":actual}
    data=json.loads(m.read_text(encoding="utf-8"))
    results=[]
    base=m.parent
    for item in data.get("artifacts",[]):
        p=(base/item["path"]).resolve()
        if base not in p.parents:
            results.append({"path":item["path"],"status":"BLOCKED","reason":"path escape"}); continue
        if not p.is_file():
            results.append({"path":item["path"],"status":"FAIL","reason":"missing"}); continue
        got=sha(p)
        results.append({"path":item["path"],"status":"PASS" if got==item["sha256"] else "FAIL",
                        "expected":item["sha256"],"actual":got})
    return {"status":"PASS" if all(x["status"]=="PASS" for x in results) else "FAIL",
            "manifest_sha256":actual,"artifacts":results}
if __name__=="__main__":
    r=verify(sys.argv[1]); print(json.dumps(r,indent=2)); raise SystemExit(0 if r["status"]=="PASS" else 2)
