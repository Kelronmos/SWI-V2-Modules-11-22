import json, tempfile, hashlib, unittest, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"public_evidence_lab"/"automation"))
from verify_manifest import verify
class PackageContracts(unittest.TestCase):
    def test_detached_manifest_checksum(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); a=root/"a.txt"; a.write_text("evidence")
            digest=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
            m=root/"evidence_manifest.json"
            m.write_text(json.dumps({"artifacts":[{"path":"a.txt","sha256":digest(a)}]}))
            (root/"evidence_manifest.json.sha256").write_text(digest(m)+"  evidence_manifest.json\\n")
            self.assertEqual(verify(m)["status"],"PASS")
    def test_manifest_tamper_detected(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); m=root/"evidence_manifest.json"; m.write_text(json.dumps({"artifacts":[]}))
            (root/"evidence_manifest.json.sha256").write_text(hashlib.sha256(m.read_bytes()).hexdigest()+"  evidence_manifest.json\\n")
            m.write_text(m.read_text()+" ")
            self.assertEqual(verify(m)["status"],"FAIL")
    def test_repair_policy_defaults_to_block(self):
        p=json.loads((ROOT/"public_evidence_lab/automation/repair_policy.json").read_text())
        self.assertEqual(p["default_action"],"BLOCK")
        self.assertIs(p["automatic_source_repairs_enabled"],False)
    def test_authority_ceiling_false(self):
        p=json.loads((ROOT/"public_evidence_lab/automation/repair_policy.json").read_text())
        self.assertTrue(all(v is False for v in p["authority_ceiling"].values()))
if __name__=="__main__": unittest.main()
