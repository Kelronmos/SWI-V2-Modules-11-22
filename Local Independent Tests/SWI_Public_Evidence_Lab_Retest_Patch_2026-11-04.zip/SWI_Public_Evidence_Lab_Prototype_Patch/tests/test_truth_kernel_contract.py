"""Static contract checks for the TLA+ candidate; not a TLC model check."""
from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parents[1]
MODEL = (ROOT / "truth_kernel" / "TruthKernel.candidate.tla").read_text(encoding="utf-8")
class TruthKernelContract(unittest.TestCase):
    def test_uses_distinct_action_name(self):
        self.assertIn("AppendEvent(event)", MODEL)
        self.assertNotIn("Append(event) ==", MODEL)
    def test_first_link_uses_genesis_not_index_zero(self):
        self.assertIn('THEN "GENESIS"', MODEL)
        self.assertNotIn("Last(hashChain)", MODEL)
    def test_chain_and_log_lengths_match(self):
        self.assertIn("Len(log) = Len(hashChain)", MODEL)
    def test_integrity_checks_previous_link(self):
        self.assertIn("hashChain[i - 1]", MODEL)
        self.assertIn("Hash(log[i]", MODEL)
    def test_cryptographic_claim_is_disclaimed(self):
        status=(ROOT / "truth_kernel" / "MODEL_STATUS.md").read_text(encoding="utf-8")
        self.assertIn("not cryptographic hashing", status)
        self.assertIn("NOT RUN", status)
if __name__ == "__main__": unittest.main()
