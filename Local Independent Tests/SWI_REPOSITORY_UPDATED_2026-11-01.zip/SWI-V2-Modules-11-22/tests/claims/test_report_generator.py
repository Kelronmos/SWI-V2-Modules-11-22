import json
import subprocess
import sys
from pathlib import Path


def test_claim_report_renders_legacy_run_id_and_verification_pointer(tmp_path):
    root = Path(__file__).resolve().parents[2]
    history = tmp_path / "history.jsonl"
    report = tmp_path / "report.md"
    record = {
        "run_id": "DCRE-REPORT-FALLBACK-001",
        "scope": "bounded local test run",
        "truth": "UNKNOWN",
        "state": "PARTIAL",
        "verification_run": "evidence/runs/run.json",
        "verification_run_sha256": "sha256:" + "a" * 64,
    }
    from swi_v2.claims.history import append_record
    append_record(history, record)
    result = subprocess.run(
        [sys.executable, "tools/generate_claim_report.py", str(history), "--output", str(report)],
        cwd=root, text=True, capture_output=True,
    )
    assert result.returncode == 0, result.stderr
    rendered = report.read_text(encoding="utf-8")
    assert "DCRE-REPORT-FALLBACK-001" in rendered
    assert "evidence/runs/run.json" in rendered
    assert "sha256:" + "a" * 64 in rendered
