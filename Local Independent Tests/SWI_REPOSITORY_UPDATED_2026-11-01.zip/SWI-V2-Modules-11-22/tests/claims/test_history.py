import json
import pytest
from swi_v2.claims.history import append_record, verify_history


def test_history_appends_and_verifies(tmp_path):
    path = tmp_path / "history.jsonl"
    append_record(path, {"claim_id": "C1", "outcome": "UNKNOWN"})
    append_record(path, {"claim_id": "C1", "outcome": "TRUE"})
    result = verify_history(path)
    assert result["valid"] and result["records"] == 2


def test_history_tampering_is_detected(tmp_path):
    path = tmp_path / "history.jsonl"
    append_record(path, {"claim_id": "C1", "outcome": "UNKNOWN"})
    row = json.loads(path.read_text())
    row["record"]["outcome"] = "TRUE"
    path.write_text(json.dumps(row) + "\n")
    assert not verify_history(path)["valid"]


def test_append_refuses_corrupt_history(tmp_path):
    path = tmp_path / "history.jsonl"
    path.write_text("not-json\n")
    with pytest.raises(ValueError):
        append_record(path, {"claim_id": "C1"})
