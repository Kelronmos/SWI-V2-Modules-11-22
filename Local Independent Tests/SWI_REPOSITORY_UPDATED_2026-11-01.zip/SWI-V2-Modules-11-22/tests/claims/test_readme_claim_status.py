from tools.render_readme_claim_status import main_publishable


def _record():
    return {
        "git_state": {"branch": "main", "head_sha": "abc123"},
        "truth": "TRUE",
        "state": "VERIFIED",
        "level": "L4_VERIFIED",
        "test_summary": {"exit_code": 0},
        "build_summary": {"exit_code": 0},
        "schema_validation": {"exit_code": 0},
        "ci": {"status": "PASS"},
        "production_authorized": False,
    }


def test_main_badge_requires_clean_exact_head_and_ci_pass():
    assert main_publishable(_record(), "main", "abc123", True)


def test_feature_branch_never_displays_public_main_verification():
    assert not main_publishable(_record(), "feature/swi-dcre-core-doctrine", "abc123", True)


def test_stale_commit_never_displays_public_main_verification():
    assert not main_publishable(_record(), "main", "def456", True)


def test_dirty_worktree_never_displays_public_main_verification():
    assert not main_publishable(_record(), "main", "abc123", False)


def test_ci_not_run_never_displays_public_main_verification():
    record = _record()
    record["ci"]["status"] = "NOT_RUN"
    assert not main_publishable(record, "main", "abc123", True)
