from swi_v2.claims.engine import ClaimAssessment, Level, State, Truth
from swi_v2.claims.swi_report_adapter import add_assessment_to_report
from swi_v2.reports.test_report import TestReportBuilder as SWITestReportBuilder


def test_dcre_assessment_uses_existing_report_spine_without_authority_escalation():
    builder = SWITestReportBuilder(root=__import__('pathlib').Path.cwd())
    assessment = ClaimAssessment(
        claim_id="DCRE-ADAPTER-001", scope="one bounded feature", truth=Truth.UNKNOWN,
        level=Level.L2_IMPLEMENTED, state=State.PARTIAL,
        reasons=("missing_current_evidence",), production_authorized=False,
    )
    claim = add_assessment_to_report(builder, assessment)
    report = builder.to_dict()
    assert len(report["observations"]) == 1
    assert len(report["claims"]) == 1
    assert claim.verification_status == "UNRESOLVED"
    assert report["governance"]["production_authorized"] == "NO"
