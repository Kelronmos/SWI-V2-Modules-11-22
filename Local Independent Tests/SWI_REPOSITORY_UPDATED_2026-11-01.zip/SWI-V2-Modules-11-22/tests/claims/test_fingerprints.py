from swi_v2.claims.fingerprints import digest_paths


def test_digest_changes_when_input_changes(tmp_path):
    f = tmp_path / "source.py"
    f.write_text("x = 1\n")
    first = digest_paths([f])
    f.write_text("x = 2\n")
    assert digest_paths([f]) != first


def test_digest_is_deterministic_for_order(tmp_path):
    a, b = tmp_path / "a", tmp_path / "b"
    a.write_text("A")
    b.write_text("B")
    assert digest_paths([a, b]) == digest_paths([b, a])


def test_command_digest_binds_exact_argv():
    from swi_v2.claims import command_digest
    assert command_digest(["python", "-m", "pytest"]) == command_digest(("python", "-m", "pytest"))
    assert command_digest(["python", "-m", "pytest"]) != command_digest(["python", "-m", "pytest", "-q"])
