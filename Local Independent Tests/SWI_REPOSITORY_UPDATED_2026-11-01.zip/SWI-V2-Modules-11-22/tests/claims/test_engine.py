from dataclasses import replace

from swi_v2.claims import (
    Claim, EvidenceReference, Fingerprint, GovernanceAttestation, Level, State, Truth, Verification,
    command_digest, evaluate_claim,
)


def passing(**kw):
    base = dict(
        verification_id="V-1", scope="unit-test", outcome=Truth.TRUE, executed=True,
        acceptance_criteria=("reject empty evidence",), passed_criteria=("reject empty evidence",),
        implementation_digest="sha256:abc", tested_implementation_digest="sha256:abc",
        dependency_digest="sha256:deps", config_digest="sha256:config", test_digest="sha256:tests",
        environment_digest="sha256:env", commit_sha="deadbeef",
        recorded_at="2026-10-31T22:00:00+02:00",
        evidence_refs=(EvidenceReference("evidence/test.log", "sha256:" + "a" * 64, "pytest", "L1-L8"),),
        command=("python", "-m", "pytest", "tests/test_gate.py"), exit_code=0,
    )
    base.update(kw)
    return Verification(**base)


def assess(claim, **kwargs):
    return evaluate_claim(claim, evidence_validator=lambda ref: ref.source == "pytest", **kwargs)


def claim_with(v=None, **kw):
    base = dict(
        claim_id="C-1", feature="empty evidence rejected", scope="unit-test",
        requirements=("reject empty evidence",), design_refs=("docs/design.md",),
        implementation_refs=("swi_v2/kernel/gate.py",), implementation_digest="sha256:abc",
        fingerprint=Fingerprint(implementation_digest="sha256:abc", dependency_digest="sha256:deps",
                                command_digest=command_digest(("python", "-m", "pytest", "tests/test_gate.py")),
                          config_digest="sha256:config", test_digest="sha256:tests",
                                environment_digest="sha256:env", commit_sha="deadbeef"),
        verifications=() if v is None else (v,),
    )
    base.update(kw)
    return Claim(**base)


def test_no_verification_is_unknown_not_true():
    a = assess(claim_with())
    assert a.truth == Truth.UNKNOWN and a.state == State.NOT_RUN
    assert a.level == Level.L2_IMPLEMENTED


def test_complete_evidence_pass_reaches_verified_not_proven():
    a = assess(claim_with(passing()))
    assert a.truth == Truth.TRUE and a.level == Level.L4_VERIFIED
    assert not a.production_authorized


def test_failed_claim_requires_counterexample_and_evidence():
    bad = passing(outcome=Truth.FALSE, passed_criteria=(), failed_criteria=("reject empty evidence",),
                  counterexample="Observed: empty evidence was accepted; see evidence/test.log:L4", exit_code=1)
    a = assess(claim_with(bad))
    assert a.truth == Truth.FALSE and a.state == State.FAILED and a.level == Level.L3_TESTED
    no_counterexample = replace(bad, counterexample=None)
    assert assess(claim_with(no_counterexample)).truth == Truth.UNKNOWN
    no_failed_criterion = replace(bad, failed_criteria=())
    assert assess(claim_with(no_failed_criterion)).truth == Truth.UNKNOWN
    no_evidence = replace(bad, evidence_refs=())
    assert assess(claim_with(no_evidence)).truth == Truth.UNKNOWN


def test_changed_implementation_makes_old_verification_stale():
    a = assess(claim_with(passing(), implementation_digest="sha256:new",
                                  fingerprint=Fingerprint(implementation_digest="sha256:new", dependency_digest="sha256:deps",
                                                          command_digest=command_digest(("python", "-m", "pytest", "tests/test_gate.py")),
                          config_digest="sha256:config", test_digest="sha256:tests",
                                                          environment_digest="sha256:env", commit_sha="deadbeef")))
    assert a.truth == Truth.UNKNOWN and a.state == State.STALE


def test_missing_current_dependency_binding_is_unknown():
    v = passing()
    c = claim_with(v, fingerprint=Fingerprint(implementation_digest="sha256:abc"))
    a = assess(c)
    assert a.truth == Truth.UNKNOWN


def test_config_change_invalidates_prior_verification():
    v = passing()
    changed = Fingerprint(implementation_digest="sha256:abc", dependency_digest="sha256:deps",
                          command_digest=command_digest(("python", "-m", "pytest", "tests/test_gate.py")),
                          config_digest="sha256:changed", test_digest="sha256:tests",
                          environment_digest="sha256:env", commit_sha="deadbeef")
    a = assess(claim_with(v, fingerprint=changed))
    assert a.truth == Truth.UNKNOWN and a.state == State.STALE


def test_incomplete_criteria_cannot_pass():
    v = passing(acceptance_criteria=("r1", "r2"), passed_criteria=("r1",))
    assert assess(claim_with(v)).truth == Truth.UNKNOWN


def test_invalid_criteria_overlap_cannot_pass():
    v = passing(passed_criteria=("reject empty evidence",), failed_criteria=("reject empty evidence",))
    assert assess(claim_with(v)).truth == Truth.UNKNOWN


def test_independent_reproduction_requires_external_reviewer_validation():
    c = claim_with(passing(independent_reproduction=True, reviewer_id="reviewer-1"))
    assert assess(c).level == Level.L4_VERIFIED
    accepted = assess(c, reviewer_validator=lambda reviewer, _: reviewer == "reviewer-1")
    assert accepted.level == Level.L5_REPRODUCED


def test_arbitrary_governance_reference_never_promotes_without_validator():
    att = GovernanceAttestation(Level.L8_PRODUCTION_AUTHORIZED, "AUTH-123", "authority-x")
    a = assess(claim_with(passing(), governance_attestations=(att,)))
    assert a.level == Level.L4_VERIFIED and not a.production_authorized


def test_governance_adapter_must_validate_external_attestation():
    att = GovernanceAttestation(Level.L8_PRODUCTION_AUTHORIZED, "AUTH-123", "authority-x")
    c = claim_with(passing(), governance_attestations=(att,))
    assert assess(c, attestation_validator=lambda _: False).level == Level.L4_VERIFIED
    accepted = assess(c, attestation_validator=lambda item: item.reference == "AUTH-123")
    assert accepted.level == Level.L8_PRODUCTION_AUTHORIZED
    assert accepted.production_authorized is False


def test_governance_validator_exception_fails_closed():
    att = GovernanceAttestation(Level.L7_SEALED, "SEAL-1", "seal-authority")
    def broken(_):
        raise RuntimeError("offline")
    a = assess(claim_with(passing(), governance_attestations=(att,)), attestation_validator=broken)
    assert a.level == Level.L4_VERIFIED


def test_missing_claim_scope_or_requirements_blocks():
    c = Claim("C", "feature", "unit", ())
    a = assess(c)
    assert a.truth == Truth.UNKNOWN and a.state == State.BLOCKED


def test_feature_level_is_bounded_by_weakest_required_claim():
    from swi_v2.claims import evaluate_feature
    high = claim_with(passing())
    low = Claim("C-2", "empty evidence rejected", "unit-test", ("reject empty evidence",),
                design_refs=("docs/design.md",))
    result = evaluate_feature("empty evidence rejected", (high, low), evidence_validator=lambda ref: True)
    assert result.truth == Truth.UNKNOWN
    assert result.level == Level.L1_DESIGNED


def test_feature_false_if_any_required_claim_has_counterexample():
    from swi_v2.claims import evaluate_feature
    good = claim_with(passing())
    bad_v = passing(outcome=Truth.FALSE, passed_criteria=(), failed_criteria=("reject empty evidence",),
                    counterexample="Observed: empty evidence accepted at line 4", exit_code=1)
    bad = claim_with(bad_v, claim_id="C-2")
    result = evaluate_feature("empty evidence rejected", (good, bad), evidence_validator=lambda ref: True)
    assert result.truth == Truth.FALSE


def test_evidence_reference_requires_external_validation():
    c = claim_with(passing())
    assert evaluate_claim(c).truth == Truth.UNKNOWN


def test_malformed_evidence_reference_fails_closed():
    bad_ref = EvidenceReference("evidence/test.log", "not-a-hash", "pytest", "L1")
    v = passing(evidence_refs=(bad_ref,))
    assert assess(claim_with(v)).truth == Truth.UNKNOWN


def test_partial_executed_verification_reaches_tested_not_verified():
    v = passing(passed_criteria=())
    a = assess(claim_with(v))
    assert a.truth == Truth.UNKNOWN and a.level == Level.L3_TESTED and a.state == State.PARTIAL


def test_missing_current_command_fingerprint_marks_verification_stale():
    c = claim_with(passing(), fingerprint=Fingerprint(
        implementation_digest="sha256:abc", dependency_digest="sha256:deps",
        config_digest="sha256:config", test_digest="sha256:tests",
        environment_digest="sha256:env", commit_sha="deadbeef"))
    a = assess(c)
    assert a.truth == Truth.UNKNOWN and a.state == State.STALE


def test_changed_command_fingerprint_marks_verification_stale():
    changed = replace(claim_with(passing()).fingerprint,
                      command_digest=command_digest(("python", "-m", "pytest", "different_test.py")))
    a = assess(claim_with(passing(), fingerprint=changed))
    assert a.truth == Truth.UNKNOWN and a.state == State.STALE


def test_external_l8_attestation_never_sets_action_authorization_flag():
    att = GovernanceAttestation(Level.L8_PRODUCTION_AUTHORIZED, "AUTH-456", "existing-authority")
    a = assess(claim_with(passing(), governance_attestations=(att,)),
               attestation_validator=lambda item: item.reference == "AUTH-456")
    assert a.level == Level.L8_PRODUCTION_AUTHORIZED
    assert a.production_authorized is False


def test_invalidated_state_is_preserved():
    v = passing(state=State.INVALIDATED)
    a = assess(claim_with(v))
    assert a.truth == Truth.UNKNOWN and a.state == State.INVALIDATED


def test_verification_must_cover_every_claim_requirement():
    v = passing(acceptance_criteria=("r1",), passed_criteria=("r1",))
    c = claim_with(v, requirements=("r1", "r2"))
    a = assess(c)
    assert a.truth == Truth.UNKNOWN and a.level == Level.L3_TESTED and a.state == State.PARTIAL


def test_out_of_scope_acceptance_criterion_cannot_prove_claim():
    v = passing(acceptance_criteria=("unrelated",), passed_criteria=("unrelated",))
    a = assess(claim_with(v))
    assert a.truth == Truth.UNKNOWN


def test_false_without_explicit_counterexample_is_unknown():
    v = passing(outcome=Truth.FALSE, passed_criteria=(),
                failed_criteria=("reject empty evidence",), exit_code=1)
    assert assess(claim_with(v)).truth == Truth.UNKNOWN
