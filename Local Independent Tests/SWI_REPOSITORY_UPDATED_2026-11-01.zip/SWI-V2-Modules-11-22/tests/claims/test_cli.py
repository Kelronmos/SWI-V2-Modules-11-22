import hashlib
import json
import subprocess
import sys
from pathlib import Path

from swi_v2.claims.engine import command_digest


def test_evaluate_claim_cli_validates_evidence_digest(tmp_path):
    root = tmp_path
    evidence = root / "evidence.log"
    evidence.write_text("observed result: all criteria pass\n")
    digest = "sha256:" + hashlib.sha256(evidence.read_bytes()).hexdigest()
    fingerprint = {
        "implementation_digest": "sha256:" + "1" * 64,
        "dependency_digest": "sha256:" + "2" * 64,
        "config_digest": "sha256:" + "3" * 64,
        "test_digest": "sha256:" + "4" * 64,
        "environment_digest": "sha256:" + "5" * 64,
        "command_digest": command_digest(["python", "-m", "pytest"]),
        "commit_sha": "abcdef123456",
    }
    claim = {
        "claim_id": "CLI-1", "feature": "demo", "scope": "unit",
        "requirements": ["criterion-1"], "implementation_refs": ["src/demo.py"],
        "implementation_digest": fingerprint["implementation_digest"],
        "fingerprint": fingerprint,
        "verifications": [{
            "verification_id": "V-CLI-1", "scope": "unit", "outcome": "TRUE", "executed": True,
            "acceptance_criteria": ["criterion-1"], "passed_criteria": ["criterion-1"],
            "implementation_digest": fingerprint["implementation_digest"],
            "tested_implementation_digest": fingerprint["implementation_digest"],
            "dependency_digest": fingerprint["dependency_digest"], "config_digest": fingerprint["config_digest"],
            "test_digest": fingerprint["test_digest"], "environment_digest": fingerprint["environment_digest"],
            "commit_sha": fingerprint["commit_sha"], "recorded_at": "2026-10-31T22:00:00+02:00",
            "command": ["python", "-m", "pytest"], "exit_code": 0,
            "evidence_refs": [{"reference": "evidence.log", "sha256": digest, "source": "pytest", "locator": "line 1"}]
        }]
    }
    claim_file = root / "claim.json"
    claim_file.write_text(json.dumps(claim))
    tool = Path(__file__).resolve().parents[2] / "tools" / "evaluate_claim.py"
    result = subprocess.run([sys.executable, str(tool), str(claim_file), "--root", str(root)],
                            text=True, capture_output=True, check=True)
    assert json.loads(result.stdout)["truth"] == "TRUE"


def test_evaluate_claim_cli_rejects_path_traversal_evidence(tmp_path):
    outside = tmp_path.parent / "outside-evidence.txt"
    outside.write_text("not in root")
    digest = "sha256:" + hashlib.sha256(outside.read_bytes()).hexdigest()
    root = tmp_path / "root"
    root.mkdir()
    fp = {"implementation_digest": "sha256:"+"1"*64, "command_digest": command_digest(["pytest"]), "dependency_digest":"sha256:"+"2"*64,
          "config_digest":"sha256:"+"3"*64, "test_digest":"sha256:"+"4"*64,
          "environment_digest":"sha256:"+"5"*64, "commit_sha":"abcdef"}
    claim = {"claim_id":"C","feature":"F","scope":"S","requirements":["R"],
             "implementation_refs":["src.py"],"implementation_digest":fp["implementation_digest"],"fingerprint":fp,
             "verifications":[{"verification_id":"V","scope":"S","outcome":"TRUE","executed":True,
             "acceptance_criteria":["R"],"passed_criteria":["R"],"implementation_digest":fp["implementation_digest"],
             "tested_implementation_digest":fp["implementation_digest"],"dependency_digest":fp["dependency_digest"],
             "config_digest":fp["config_digest"],"test_digest":fp["test_digest"],"environment_digest":fp["environment_digest"],
             "commit_sha":fp["commit_sha"],"recorded_at":"2026-10-31T22:00:00+02:00","command":["pytest"],"exit_code":0,
             "evidence_refs":[{"reference":"../outside-evidence.txt","sha256":digest,"source":"pytest","locator":"line 1"}]}]}
    claim_file=root/"claim.json"; claim_file.write_text(json.dumps(claim))
    tool=Path(__file__).resolve().parents[2]/"tools"/"evaluate_claim.py"
    result=subprocess.run([sys.executable,str(tool),str(claim_file),"--root",str(root)],text=True,capture_output=True,check=True)
    assert json.loads(result.stdout)["truth"] == "UNKNOWN"
