from tools.run_repository_verification import counts, verification_passes


def test_plural_pytest_error_count_is_preserved():
    assert counts("1 failed, 703 passed, 1 warning, 5 errors") == {
        "passed": 703,
        "failed": 1,
        "errors": 5,
    }


def test_passing_subset_cannot_hide_full_suite_failure():
    checks = {
        "formula": {"role": "required", "status": "PASS"},
        "full_suite": {"role": "required", "status": "FAIL"},
        "optional_iso": {"role": "optional", "status": "ABSENT"},
    }
    assert verification_passes(True, checks) is False


def test_optional_absence_does_not_become_a_pass_or_block_scoped_checks():
    checks = {
        "formula": {"role": "required", "status": "PASS"},
        "full_suite": {"role": "required", "status": "PASS"},
        "optional_iso": {"role": "optional", "status": "ABSENT"},
    }
    assert verification_passes(True, checks) is True


def test_dirty_source_tree_prevents_verification():
    checks = {"formula": {"role": "required", "status": "PASS"}}
    assert verification_passes(False, checks) is False
