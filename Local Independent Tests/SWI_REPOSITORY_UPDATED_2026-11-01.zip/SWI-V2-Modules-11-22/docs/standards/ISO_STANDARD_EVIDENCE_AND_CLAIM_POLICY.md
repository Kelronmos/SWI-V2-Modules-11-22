# SWI ISO standard references, claims and evidence policy

## Purpose

This register names standards using their official identifiers and links to the official ISO source pages. It is a reference register, not an ISO conformity assessment, certification, or declaration that SWI satisfies any standard.

## Current official references

- **ISO/IEC 42001:2023 — Information technology — Artificial intelligence — Management system.** Official ISO source: <https://www.iso.org/standard/42001>. ISO describes this as requirements and guidance for establishing, implementing, maintaining and continually improving an AI management system (AIMS).
- **ISO/IEC 23894:2023 — Information technology — Artificial intelligence — Guidance on risk management.** Official ISO source: <https://www.iso.org/standard/77304.html>. ISO describes this as guidance for managing risks specifically related to AI and integrating AI risk management into organizational activities.

The public pages establish standard identity and general scope. They do not replace the licensed standard text. No clause numbers, normative requirements, or SWI clause allocations are asserted here.

## Claim rules

Every SWI claim must be bounded by an identified feature, version/commit, scope, acceptance criteria, and evidence references. The record must identify the command, environment, dependency/configuration fingerprints, source commit, exit code, raw output, and hashes. Evidence must be current for the inputs it covers. Missing evidence yields `UNKNOWN`; a `FALSE` outcome requires a concrete counterexample to the bounded claim.

A repository engineering claim may be supported by tests and source evidence. It must not be relabelled as an ISO conformity claim unless the applicable licensed requirements have been mapped, all relevant criteria assessed, evidence validated, and the required independent/organizational assessment completed.

## Runtime and lifecycle binding

DCRE is currently an evidence/reporting capability with a tested adapter to the existing `TestReportBuilder`. Runtime-wide hooks into every execution path, `ExecutionIntegrityGate`, admission, `HaltedWorkflow`, `ReplayGuard`, and `write_reports()` persistence are NOT ESTABLISHED by the current evidence. Treat overall runtime binding as `PARTIAL`, not complete. Any further binding must reuse those existing contracts and must not create a parallel authorization or execution-control system.

## Local operation and telemetry

A claim verification run is performed against the actual local checkout and active environment. The run records environment identity and relevant fingerprints; it does not silently assume that another machine or environment is equivalent. No telemetry upload or remote evidence submission is required by this doctrine. Evidence remains local unless an explicitly approved repository operation publishes it.

On a rebuild, first inspect repository state and record BEFORE. Pull/rebase is permitted only when a genuine upstream checkout, correct target branch, clean/reconciled working tree, and network access are verified. Then rebuild, run the scoped and regression suites, replay the recorded run, validate schemas and hashes, record AFTER, and preserve both results. Do not overwrite historical evidence.

## Green is not readiness

`CI_GREEN`, passing tests, successful compilation, schema validity, hash-chain validity, and replay match are individual observations only. None establishes universal correctness, ISO conformity, operational readiness, authorization, or production safety. `PROVEN`, `SEALED`, `AUTHORIZED`, and `PRODUCTION_AUTHORIZED` remain separate states governed by their existing SWI contracts.

## Before / During / After

- **Before:** identify repository, branch, commit, dirty/untracked/ignored state, runtime/environment, dependencies and configuration; inventory and hash files; create and verify a recoverable backup.
- **During:** record every command and change; preserve originals; checkpoint; record failures and repair decisions; detect unexpected state changes.
- **After:** rebuild and test; replay; validate schemas, references and hashes; compare inventories; verify rollback; report defects, limitations and governance state.
