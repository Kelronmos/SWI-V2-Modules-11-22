# SWI DCRE — ISO Reference, Runtime and Evidence Boundary

**Status:** reference register only; no ISO conformity assessment.  
**Date:** 2026-11-01

## Register scope and separation

The DCRE-local `ISO_STANDARD_REFERENCE_REGISTER.json` contains **three** reference entries (ISO/IEC 42001:2023, ISO/IEC 23894:2023 and ISO/IEC 27001:2022). A separate ISO Evidence & Replay Lab / research dossier has **five** entries (the three above plus ISO/IEC 5338:2023, ISO/IEC 12792:2025 and ISO/IEC TS 42119-2:2025). These are distinct inventories with different scopes; do not report the count from one as the count in the other. The five-standard research register is documented in `docs/review/ISO_STANDARDS_REVIEW.md`.

Neither inventory is a completed assessment. All entries remain `NOT_ASSESSED` or `UNMAPPED`; the number of references is not a measure of conformity.

## Official standards references

The machine-readable register is `docs/iso/ISO_STANDARD_REFERENCE_REGISTER.json`.

- [ISO/IEC 42001:2023 — AI management system](https://www.iso.org/standard/42001): management-system requirements for organizations establishing, implementing, maintaining and continually improving an AI management system.
- [ISO/IEC 23894:2023 — AI risk-management guidance](https://www.iso.org/standard/77304.html): guidance for integrating AI risk management into organizational activities and functions.
- [ISO/IEC 27001:2022 — Information security management systems requirements](https://www.iso.org/standard/27001): requirements for an information security management system; ISO lists Amendment 1:2024.

These are official reference links and high-level descriptions, not substitutes for the controlled standard text. No clause-level allocation is asserted. Licensed text, applicability decisions and competent review are required before clause mapping. Every standard remains `NOT_ASSESSED`; no conformity claim is made.

## DCRE runtime boundary

DCRE is a bounded development-claim evaluator and reporting component. It may consume explicit run outputs, evidence references, fingerprints and existing `TestReportBuilder` records. It is not an ambient observer, telemetry collector, runtime hook, kernel gate, admission engine, authority engine, or action executor. It does not install background agents or send telemetry. A static source scan is not proof that every transitive dependency or runtime environment is telemetry-free.

Current integration evidence demonstrates an adapter to `swi_v2.reports.test_report.TestReportBuilder`. It does **not** establish that DCRE is wired into every runtime path, `ExecutionIntegrityGate`, admission, `HaltedWorkflow`, `ReplayGuard`, or `write_reports()` persistence. Those remain explicit integration gaps. Do not imply runtime-wide coverage.

## Claim verification discipline

Each claim must be bounded by feature, scope and explicit acceptance criteria. A verification record must bind exact argv, source/test/dependency/config/environment fingerprints, commit, exit code and retrievable evidence references. Missing or mismatched bindings produce `UNKNOWN`/`STALE`, not `FALSE`. `FALSE` requires a concrete evidenced counterexample against a declared criterion. A test pass is scoped evidence only; it is not universal proof.

The existing frozen `docs/runtime/EVIDENCE_FRESHNESS_CONTRACT.md` remains authoritative. Never rewrite historical `source_tip` values. A new run creates a new evidence record. Runtime evidence is not silently upgraded to current evidence merely because the code or report is green.

## Before / During / After and rebuild

- **Before:** record repository identity, branch, HEAD, worktree, environment, dependency/config fingerprints, and backup manifest.
- **During:** record exact commands, outputs, exit codes, changed files, checkpoints and failed repair attempts. No automatic consequential action.
- **After:** rebuild only using the available project build contract; run scoped and full tests; validate schemas and evidence references; verify history; produce after-manifest and recovery verification.

The supplied snapshot has no verified upstream ancestry. `git pull`, upstream comparison and CI are therefore `NOT_RUN`/`BLOCKED` until a genuine upstream checkout is available. Do not treat a synthetic local branch as `main` or push it to `main`.

## `SEALED` terminology boundary

`SEALED` is overloaded in historical SWI records and must never be presented without naming the object and meaning being sealed. In particular, an immutable/hash-chained evidence record or a workflow's record-integrity seal is **not** an ISO conformity claim, conformity assessment, certification, or authorization. If a legacy field says `CONFORMITY_CLAIM: SEALED` while `ISO_CONFORMITY: NOT_ESTABLISHED`, the only safe interpretation is that a record/status object was closed or made immutable; it does not establish conformity. The human-readable post and dashboards must display this clarification adjacent to the word `SEALED`.

For ISO claims, use explicit fields: `record_integrity_state`, `clause_mapping_state`, `conformity_assessment_state`, `certification_state`, and `production_authorization_state`. Do not reuse a generic `SEALED` value as a conformity status. Existing historical records remain unchanged; corrections are additive and must cite the affected record.

## Production-readiness boundary

`CI_GREEN`, local tests, a successful build, a matching hash or an ISO reference do not establish production readiness. `PROVEN`, `SEALED`, `AUTHORIZED` and `PRODUCTION AUTHORIZED` remain separate and governed by existing SWI contracts. DCRE always reports `production_authorized: false` and never authorizes action.
