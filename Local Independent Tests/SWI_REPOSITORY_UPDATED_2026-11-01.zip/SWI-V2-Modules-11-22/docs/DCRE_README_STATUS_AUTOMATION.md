# DCRE README Claim Status Automation

The README claim panel is generated from a schema-valid DCRE aggregate verification run.

## Local regeneration

```bash
python tools/validate_claim_schemas.py --summary evidence/runs/2026-11-01/dcre-main-read-status-final/verification_run.json
python tools/verify_claim_history.py evidence/claims/claim_history.jsonl
python tools/render_readme_claim_status.py evidence/runs/2026-11-01/dcre-main-read-status-final/verification_run.json
```

The renderer verifies every referenced evidence file against its SHA-256 digest before displaying the evidence count. It displays `VERIFIED` only when the record declares `truth=TRUE`, `state=VERIFIED`, a qualifying verification level, successful test/build/schema results, `ci.status=PASS`, and all evidence references validate. Otherwise it preserves the recorded bounded state and truth value. It never upgrades a claim, signs an attestation, grants authority, or permits execution.

The main SWI CI workflow reruns the focused DCRE tests, validates the aggregate record and append-only history, regenerates the panel, and checks that the committed README panel is current. A GitHub CI pass is evidence only within that CI run and does not authorize production.

## Current recorded limitation

The 2026-11-01 local run is `PARTIAL / UNKNOWN` at `L3_TESTED`. The focused DCRE suite passed 35 tests; the full repository suite did not complete because collection is blocked by the malformed `swi_v2/execution_integrity_body.py` fragment and the literal placeholder in `swi_v2/trusted_source/spine_inspector.py`. The checkout was ZIP-derived with synthetic local Git history; upstream ancestry and GitHub CI were not verified.

`production_authorized` remains `false`.
