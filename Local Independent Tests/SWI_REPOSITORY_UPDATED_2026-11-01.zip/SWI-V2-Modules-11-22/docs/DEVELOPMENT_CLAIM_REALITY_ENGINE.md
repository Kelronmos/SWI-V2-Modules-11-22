# SWI Development Claim & Reality Engine (DCRE)

**Status: integrated into the supplied ZIP-derived local feature branch; upstream ancestry and remote publication are unverified.**

DCRE evaluates narrowly scoped feature claims from explicit requirements and provenance-bound verification records. It reports what supplied evidence supports; it is not an execution gate, authority system, proof system, seal system, or ISO-conformity engine.

## Governing distinctions

- Observation is not a claim.
- Data is not evidence; evidence is not admission.
- Admission is not authorization; authorization is not action.
- `UNKNOWN` is not permitted.
- A test pass is not universal proof.
- A hash match establishes byte integrity only, not truth or relevance.
- `PROVEN` is not `SEALED`; `SEALED` is not `PRODUCTION AUTHORIZED`.
- A report is not authorization.

DCRE must not call or replace `ExecutionIntegrityGate`, admission/kernel boundaries, or any authority primitive. Integration should consume existing SWI evidence and authority contracts through adapters, not build parallel ones.

## Claim contract

Every claim has a stable `claim_id`, feature, explicit scope, non-empty requirements, implementation references, and implementation digest. A claim is bounded: for example, “the evaluator rejects an empty evidence object for operation X under contract Y at commit Z,” not “the evaluator is secure.”

A verification record must bind:

- exact claim scope and acceptance criteria;
- executed command and exit code;
- timestamp and structured evidence references (URI/path, SHA-256, source identity and line/range locator); an injected evidence-reference validator must confirm each reference before it can support truth;
- implementation, exact-command, dependency, configuration, test, environment and commit fingerprints;
- passed/failed criteria; and
- independent reviewer identity if reproduction is claimed.

A verification lacking any of the required current fingerprints, or without a successful evidence-reference validator, is not fresh/provenanced enough to produce `TRUE` or `FALSE`; it remains `UNKNOWN`. The fingerprint values are compared exactly. Recompute them when source, tests, dependencies, configuration, environment, or commit changes.

### Truth vs verification state

| Field | Values | Meaning |
|---|---|---|
| Claim truth | `TRUE`, `FALSE`, `UNKNOWN` | Result for the declared claim and scope |
| Verification state | `NOT_RUN`, `BLOCKED`, `PARTIAL`, `STALE`, `INVALIDATED`, `VERIFIED`, `FAILED` | State of the verification evidence |

`FALSE` requires an executed verification, a declared failed acceptance criterion, a non-empty concrete counterexample description tied to evidence locators, evidence references, complete matching fingerprints, and a recorded non-zero result. A failed command without a criterion-level counterexample is `UNKNOWN`, not `FALSE`. Without the evidence validator, all verification outcomes remain `UNKNOWN`. Missing or incomplete evidence is always `UNKNOWN`.

### Development levels

- L0 `PROPOSED`: bounded claim identified.
- L1 `DESIGNED`: design references supplied.
- L2 `IMPLEMENTED`: implementation references and implementation digest supplied.
- L3 `TESTED`: a current executed verification exists.
- L4 `VERIFIED`: current passing verification records collectively cover every requirement in the bounded claim.
- L5 `REPRODUCED`: an independent reproduction and reviewer identity are recorded and validated by an injected reviewer-trust adapter. A boolean and free-form reviewer string alone do not advance the level.
- L6 `PROVEN`, L7 `SEALED`, L8 `PRODUCTION AUTHORIZED`: never derived from tests, booleans, hashes, or free-form strings. These require an injected adapter that validates external attestations against the existing SWI governance authority. Without a reviewer adapter, DCRE stops at L4. Without the governance adapter, it cannot advance beyond L5. A validated external L8 attestation may be reported as an externally governed level, but `production_authorized` remains `false`; DCRE never authorizes an action.

A claim can be `TRUE` only when the union of passing, current verification criteria covers every requirement in the claim; out-of-scope criteria cannot prove it. Explicit `INVALIDATED` records remain distinguishable from merely `STALE` records. For a feature with multiple required claims, `evaluate_feature` reports the lowest attained level among those claims. This prevents one advanced subclaim from masking a missing or weaker required claim. The feature is `FALSE` if any required claim has a supported counterexample, `TRUE` only if all required claims are true, and otherwise `UNKNOWN`.

## Freshness and history

Any mismatch or missing current binding in the fingerprint boundary (including the exact argv command digest) makes the old verification ineffective and the claim `UNKNOWN`/`STALE` or `PARTIAL`. Historical records are append-only. `history.py` stores JSONL envelopes linked by SHA-256 hashes; this detects byte alteration or chain breaks but does not prove record truth, origin, or relevance. Do not edit or replace prior records to make a new result appear continuous.

## Local commands

From the pack root:

```bash
python -m pytest -q
python -m compileall -q swi_v2 tools tests
python tools/fingerprint_paths.py swi_v2/claims tests/claims --command-json '["python","-m","pytest","-q"]'
python tools/validate_claim_schemas.py
python tools/evaluate_claim.py path/to/feature_claim.json --root .
python tools/verify_claim_history.py evidence/claims/claim_history.jsonl
python tools/generate_claim_report.py evidence/claims/claim_history.jsonl --output reports/dcre_claim_report.md
```

`fingerprint_paths.py` fingerprints selected files/directories and optionally the exact argv vector. `validate_claim_schemas.py` validates all bundled schemas and can validate an aggregate run summary. The aggregate schema records command outcomes, environment, Git/remote state, CI `NOT_RUN`, evidence references, limitations and `not_proven`. The Python API requires an evidence-reference validator to establish that each evidence reference is retrievable and matches its digest; a mere non-empty path is insufficient. The caller must explicitly include all relevant source, test, lock, config and environment inputs. The command digest hashes the exact argv vector; the environment digest records Python and platform identity; it is not a complete container/OS attestation. `verify_claim_history.py` checks the append-only hash chain only.

Schemas are in `schemas/feature_claim.schema.json`, `schemas/verification_result.schema.json`, and `schemas/verification_run.schema.json`. `evaluate_claim.py` validates local evidence-file SHA-256 values and rejects path traversal; it has no reviewer or governance adapters, so it cannot report L5-L8. Tools are deliberately narrow and do not write to SWI authorization state. The report generator is read-only and consumes the append-only history.

## Integration status and remaining gates

Completed against the supplied ZIP-derived snapshot:

1. Inspected existing claim ledger, frozen evidence-freshness contract, `TestReportBuilder`, observation/claim structures, kernel authority, admission and replay boundaries.
2. Added `swi_v2/claims/swi_report_adapter.py`, which uses the existing `TestReportBuilder`, `ObservationRecord`, and `ClaimRecord`; its adapter test confirms no production-authorization escalation.
3. Added DCRE tests under `tests/claims/`, JSON schemas, CLI tools, append-only evidence history, and a machine-readable run record.
4. Preserved `evidence/claim-ledger.json` and `docs/runtime/EVIDENCE_FRESHNESS_CONTRACT.md`; no historical `source_tip` was rewritten.

Still open:

1. The supplied archive has no upstream `.git` metadata. Reconcile on a genuine checkout and verify branch ancestry before treating any local branch evidence as upstream-bound.
2. Wire durable output through `write_reports()` and the full established report lifecycle; the adapter currently adds records to `TestReportBuilder` but does not invoke report persistence.
3. Integrate typed reviewer and governance adapters from existing SWI contracts; generic caller-supplied validators remain an explicit trust boundary.
4. Bind complete source/test/dependency/config/environment/commit fingerprints from a genuine repository checkout and CI job.
5. Resolve the supplied snapshot's missing execution-integrity payload fragments and trusted-source inspector placeholder from their original source, not by reconstruction guesses.
6. Run the complete existing adversarial suite and CI in a genuine checkout; current full-suite collection is blocked by those snapshot defects.
7. Reproduce in a clean clone with upstream history and preserve exact commands, outputs, exit codes and report hashes.

## Explicit non-claims

This integration does not connect DCRE to the kernel execution path, `ExecutionIntegrityGate`, admission, replay guard, or any action-permission path. It does not call `write_reports()` or establish CI status. It does not establish universal correctness, production safety, independent review, PROVEN, SEALED, ISO conformity, or authorization. The 34 passing DCRE tests validate the bounded DCRE package and its `TestReportBuilder` adapter only.
