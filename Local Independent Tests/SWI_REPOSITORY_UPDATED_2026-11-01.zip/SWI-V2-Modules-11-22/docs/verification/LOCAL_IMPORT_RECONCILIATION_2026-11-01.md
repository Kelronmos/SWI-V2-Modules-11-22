# Local artifact import reconciliation — 2026-11-01

## Decision

The supplied repository ZIP, Git bundle, patches, and evidence were inspected
against the active local checkout before any replacement. The active checkout
was retained; no older repository snapshot was overlaid onto it.

## Repository ZIP comparison

The uploaded `UPDATED_LOCAL_REPOSITORY_2026-11-01.zip` contains 660 files. All
660 paths already exist in the active checkout. Four files differ, and the
active versions are newer/additive:

- `README.md` — current checkout-bound status panel and five-versus-three ISO
  register clarification;
- `docs/iso/ISO_DCRE_ALIGNMENT_AND_RUNTIME_BOUNDARY.md` — current explicit
  `SEALED` terminology boundary;
- `evidence/claims/claim_history.jsonl` — current append-only history with
  additional reconciliation records;
- `tools/render_readme_claim_status.py` — current stricter branch/HEAD/CI gate.

None of the four incoming versions replaced the active versions.

## Patch reconciliation

- Patch 1 proposed `tools/generate_verified_claims.py`. Its check-runner
  function was adapted into `tools/run_repository_verification.py`; the
  duplicate README claim block was not copied. Existing DCRE claim rendering
  remains the single claim-display path.
- Patch 2's reviewer-run JSON and stdout captures were preserved under
  `evidence/external/2026-11-01/reviewer-main-run/`. Its README hunk was not
  applied because it would create a second status panel and display
  `VERIFIED (SCOPED)` despite a failing full suite.
- `.pyc` and `__pycache__` entries present in the patch were excluded as
  generated interpreter artifacts.
- The uploaded top-level `verification_run.json` matches an already-present
  historical DCRE record and was not used to overwrite the newer current
  record.

## Bundle reconciliation

The uploaded feature bundle pointed to an earlier local feature-branch tip
`4afbca1...`; the active checkout already contained later discipline commits.
It was not imported over the active branch. A new bundle is generated from the
final local branch for handoff. Its ancestry remains synthetic and must not be
pushed directly to public `main`.

## Governance

The imported reviewer results remain separately attributed and are not
silently promoted to independently reproduced main-branch evidence. The
current local run remains `NOT_VERIFIED` because the kernel subset has one
provenance/ancestry failure and the full suite has one failure plus five
collection errors. `PROVEN=false`, `SEALED=false`,
`PRODUCTION_AUTHORIZED=false`, and ISO conformity remains
`NOT_ESTABLISHED`.
