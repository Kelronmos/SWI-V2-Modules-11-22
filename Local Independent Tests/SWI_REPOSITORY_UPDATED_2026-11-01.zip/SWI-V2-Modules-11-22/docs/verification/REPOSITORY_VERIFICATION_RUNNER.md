# Repository verification runner

`tools/run_repository_verification.py` runs the governing-formula tests, kernel
subset, any present ISO claim checks, and the full pytest suite. It records each
command, stdout, stderr, exit code, source fingerprint, environment, and a
SHA-256 manifest under `evidence/runs/<UTC-date>/repository-verification/`.

A check whose required files are absent is recorded as `ABSENT`; it is never
reported as a pass. The full suite is required: a passing subset cannot mask a
failing full suite. The runner emits `VERIFIED_SCOPED` only when the source tree
was clean before the run and every required check, including the full suite,
passed. Otherwise it emits `NOT_VERIFIED`.

This runner is not a second claim or authority engine. The existing DCRE claim
ledger and `tools/render_readme_claim_status.py` remain the sole mechanism for
rendering the README claim panel. Public-main publication still requires a
clean `main` checkout, exact HEAD-bound DCRE evidence, valid evidence hashes,
passing build/schema/tests, and CI `PASS`. A local test run does not satisfy
that publication gate.

The report always records `proven=false`, `sealed=false`,
`production_authorized=false`, and `iso_conformity=NOT_ESTABLISHED`.

When an append-only history ledger is included as evidence for a specific run,
that run must reference an immutable snapshot of the ledger at the time of the
run. It must not hash-reference the live JSONL file, because later valid appends
would otherwise invalidate an older run's evidence pointer. The live history
chain is validated separately.
