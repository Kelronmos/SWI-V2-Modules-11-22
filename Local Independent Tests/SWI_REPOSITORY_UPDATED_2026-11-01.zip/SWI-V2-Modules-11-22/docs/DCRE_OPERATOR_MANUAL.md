# DCRE Operator Manual (local candidate)

1. Define one claim per bounded behavior. Name the feature, scope, requirements and acceptance criteria before running tests.
2. Identify implementation files, test files, dependency lockfiles and configuration files. Compute and record each relevant fingerprint, including the exact command argv digest (`python tools/fingerprint_paths.py <paths...> --command-json '["python","-m","pytest"]'`).
3. Execute the exact verification command. Preserve stdout/stderr, exit code, timestamp and evidence references.
4. Record all acceptance criteria as passed or failed. A failed process alone is not a counterexample; a `FALSE` record must include a concrete counterexample description tied to a provenance locator.
5. Recompute the complete fingerprint boundary after changes. Old records remain in history; changed bindings make them stale/unknown.
6. Validate schemas with `python tools/validate_claim_schemas.py`; validate an aggregate record with `--summary path/to/run.json`.
7. Use `evaluate_claim` to assess each claim and `evaluate_feature` to aggregate all required claims. Never manually assign a level. L5 requires a trusted reviewer adapter; L6-L8 require the existing SWI governance adapter.
8. Append assessments to the hash-chained JSONL history. Verify the chain before appending.
9. Do not promote L6-L8 unless the existing SWI governance adapter validates a typed external attestation. The DCRE implementation itself cannot create those statuses. Even if an existing external governance adapter validates an L8 attestation, DCRE keeps `production_authorized=false` and never authorizes an action.
10. Report limitations and `UNKNOWN` states explicitly. Never translate missing evidence into `FALSE`, `TRUE`, or permission.

The package is integrated in the supplied ZIP-derived local feature branch. The DCRE-to-`TestReportBuilder` adapter is implemented and tested; durable `write_reports()` wiring, CI, typed reviewer/governance adapters, and upstream checkout reconciliation remain open. This package is not connected to execution or authorization paths.
