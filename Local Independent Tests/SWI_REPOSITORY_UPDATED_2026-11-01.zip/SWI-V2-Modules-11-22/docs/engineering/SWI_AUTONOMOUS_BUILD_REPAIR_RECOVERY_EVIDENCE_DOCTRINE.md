# SWI Autonomous Build, Repair, Recovery & Evidence Governance Doctrine

**Status:** Engineering doctrine proposal / implementation boundary. This document does not assert that a continuous autonomous repair service is deployed.

## Permanent lifecycle invariant

| Stage | Required responsibility |
|---|---|
| BEFORE | Identify repository, branch, commit and working tree; inventory tracked, untracked and ignored files; fingerprint dependencies/configuration/environment; preserve evidence; create and verify a recoverable baseline. |
| DURING | Record commands, outputs, exit codes and changes; checkpoint recoverable state; classify defects and repairs; monitor unexpected source/environment changes; preserve failed attempts. |
| AFTER | Re-run scoped verification; compare hashes and inventories; validate schemas and evidence references; verify backup integrity and rollback procedure; record unresolved defects and limitations. |

The doctrine applies to software engineering operations and consequential operational workflows. A backup is valid only when its contents, manifest, hashes, and recoverability are checked; ZIP existence alone is insufficient.

## Observation and decision boundaries

```text
OBSERVATION -> CONTEXT -> RULE / KNOWLEDGE EVALUATION -> CONSEQUENCE & RISK
             -> VALIDATION -> EVIDENCE -> EXISTING SWI AUTHORITY GATE -> ACTION
                                                        ^
                                            no DCRE authority path
```

Intelligence may observe. Knowledge contextualizes. Evidence establishes what is supported. Validation evaluates bounded criteria. Only the existing SWI governance spine may permit action. Monitoring records consequences. Observation, confidence, a model output, a test pass, or an automatic repair never grants authority.

## Repair classes

- **Class A — deterministic, reversible, non-authoritative:** formatting, deterministic derived-index regeneration, or verified import-path correction. Require a baseline, a recorded diff, post-checks, and rollback.
- **Class B — controlled engineering change:** validation logic, evidence structures, security controls, authorization conditions, claim generation, and ISO allocation logic. Require a defect record, reproduction, proposed patch, backup, reviewable diff, regression tests, and explicit reviewer sign-off before application.
- **Class C — human authorization required:** production deployment, consequential external API execution, deletion of original evidence, authorization-policy changes, irreversible operations, or actions affecting people, property, or ecosystems. DCRE and automated repair tools must never execute these.

A repair classification is not permission. When classification is uncertain, stop and escalate. Never overwrite or rewrite frozen contracts or historical evidence; append a new record and link the predecessor.

## Consequence and environmental boundary

Assess plausible effects on human life and wellbeing, children and vulnerable people, land/property, water, soil/agriculture, wildlife/biodiversity, ecosystems, air quality, public infrastructure, natural resources, and future generations. Potentially irreversible effects require current source/context evidence, impact and uncertainty assessment, applicable legal/environmental review, competent human review, explicit authorization from the appropriate authority, bounded execution records, and post-action monitoring. Credible uncertainty about environmental harm triggers further assessment, not permission. If required safeguards are incomplete, remain BLOCKED/SEALED under the applicable existing contract.

## Evidence freshness and history

Evidence is re-evaluated when code, tests, requirements, dependencies, configuration, environment, claim scope, or authority boundaries change. Preserve original records. New verification creates a new append-only record; it does not overwrite a failure or alter historical `source_tip`. Distinguish HEAD_CURRENT, TIP_BOUND, HISTORICAL, ORPHANED, and REFRESH_REQUIRED according to `docs/runtime/EVIDENCE_FRESHNESS_CONTRACT.md`.

## DCRE boundary

DCRE derives bounded claim outcomes TRUE/FALSE/UNKNOWN and development levels from explicit requirements and current evidence. FALSE requires a concrete counterexample. Missing or inadequate evidence is UNKNOWN. The engine is an observer and reporting component. It does not create a second admission, authority, execution, sealing, or production-authorization engine. Reports must use the existing `TestReportBuilder` and preserve its `observations`, `claims`, `limitations`, and `not_proven` separation.

## Required non-claims

- TESTED is not PROVEN; a passing test is not universal proof.
- PROVEN is not SEALED; SEALED is not PRODUCTION AUTHORIZED.
- CI_GREEN is not SWI_AUTHORIZED.
- A valid JSON document or hash does not establish truth or claim sufficiency.
- An archive hash does not establish full-tree completeness unless the inventory scope is independently established.
- This doctrine is not an ISO certification or a statement of deployment.
