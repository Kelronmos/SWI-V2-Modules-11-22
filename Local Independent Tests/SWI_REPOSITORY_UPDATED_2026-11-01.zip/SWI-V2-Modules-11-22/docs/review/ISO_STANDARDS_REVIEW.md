# ISO/IEC Standards Review — Research Register

**Review date:** 2026-10-31  
**Repository:** `Kelronmos/SWI-V2-Modules-11-22`  
**Review branch intended:** `docs/iso-reference-corrections-2026-10-31`  
**Base branch intended:** `repair/iso-evidence-replay-integrity`  
**Purpose:** Record candidate standards references and define the evidence required for a future assessment.

> **Status boundary:** This document is a research register, not an ISO conformity assessment, certification statement, legal opinion, or independent audit. Catalogue verification is not clause mapping. All five SWI mappings remain **UNMAPPED**.

## 1. Executive status

| Question | Current recorded status |
|---|---|
| Official catalogue references identified | **5 / 5** |
| Clause-by-clause mapping completed | **NO** |
| Applicability decisions approved | **NO** |
| Conformity evidence reviewed against normative clauses | **NO** |
| Independent assessment performed | **NO** |
| ISO compliance established | **NO** |
| Certification obtained or claimed | **NO** |

The descriptions in this register are limited to the published catalogue descriptions and abstracts. They are candidate subject-matter relevance only. They must not be represented as requirements extracted from the complete standards.

## 2. Standards register

### 2.1 ISO/IEC 12792:2025 — Transparency taxonomy of AI systems

- Official catalogue: https://www.iso.org/standard/84111.html
- Catalogue identity: ISO/IEC 12792:2025, Edition 1, published 2025-11.
- Published subject description: taxonomy of information elements intended to help AI stakeholders identify and address transparency needs.
- Potential SWI relevance: evidence records, observations, claims, limitations, provenance, and communication of what a test did and did not establish.
- Mapping status: **UNMAPPED**.
- Required next evidence: obtain and review the applicable normative text; identify relevant information elements and stakeholders; map each applicable element to a specific SWI artifact and test; record omissions and non-applicability with reasons.

### 2.2 ISO/IEC TS 42119-2:2025 — Testing of AI, Part 2: Overview of testing AI systems

- Official catalogue: https://www.iso.org/standard/84127.html
- Catalogue identity: ISO/IEC TS 42119-2:2025, Edition 1, published 2025-11. This is a Technical Specification.
- Published subject description: requirements and guidance for applying the ISO/IEC/IEEE 29119 series to AI-system testing, using a risk-based approach.
- Potential SWI relevance: test planning, test design, test execution, risk-based coverage, and test documentation for any AI-system components that fall within scope.
- Mapping status: **UNMAPPED**.
- Required next evidence: determine whether SWI itself, a component, or a test harness is within the document's scope; review normative text; map applicable testing and documentation provisions to executable tests and retained reports.

### 2.3 ISO/IEC 42001:2023 — Artificial intelligence management system

- Official catalogue: https://www.iso.org/standard/42001
- Catalogue identity: ISO/IEC 42001:2023, Edition 1, published 2023-12.
- Published subject description: requirements for establishing, implementing, maintaining, and continually improving an AI management system within an organization.
- Potential SWI relevance: only if an organization operating or providing SWI defines an in-scope AI management system. A software repository or technical gate alone does not establish that an organizational management system exists.
- Mapping status: **UNMAPPED**.
- Required next evidence: define the organization and AI management-system scope, roles, processes, policies, records, and boundaries before assessing any requirements. Do not treat technical controls as a substitute for organization-level management-system evidence.

### 2.4 ISO/IEC 23894:2023 — Artificial intelligence, Guidance on risk management

- Official catalogue: https://www.iso.org/standard/77304.html
- Catalogue identity: ISO/IEC 23894:2023, Edition 1, published 2023-02.
- Published subject description: guidance for organizations developing, producing, deploying, or using AI products, systems, and services to manage AI-related risk and integrate risk management into AI-related activities.
- Potential SWI relevance: risk identification, analysis, treatment, monitoring, and traceability for in-scope AI-related activities.
- Mapping status: **UNMAPPED**.
- Required next evidence: establish the relevant organizational and system context; review the full guidance; map applicable risk activities to owned procedures, decisions, records, and demonstrated execution.

### 2.5 ISO/IEC 5338:2023 — AI system life-cycle processes

- Official catalogue: https://www.iso.org/standard/81118.html
- Catalogue identity: ISO/IEC 5338:2023, Edition 1, published 2023-12.
- Published subject description: processes and concepts for describing AI-system life cycles, based on and extending established system and software life-cycle process standards.
- Potential SWI relevance: development, acquisition, operation, maintenance, control, and improvement activities where SWI or an integrated AI system falls within scope.
- Mapping status: **UNMAPPED**.
- Required next evidence: define the system boundary and life-cycle stages; review the normative text; map applicable processes to named SWI procedures, responsible actors, records, and tests.

## 3. Mapping method required before any alignment claim

For each standard, create a separate controlled mapping table with at least these fields:

| Field | Required meaning |
|---|---|
| Standard and edition | Exact identifier and edition reviewed |
| Clause / subclause | Exact location in the normative text |
| Requirement type | Requirement, recommendation, definition, or informative material |
| Applicability | Applicable / not applicable / unresolved, with rationale |
| SWI control or process | Exact implementation path or named process; no inferred controls |
| Evidence reference | Immutable commit, file path, test ID, report, and hash where available |
| Test method | How the claimed implementation is challenged and reproduced |
| Result | Observed outcome, including failures and limitations |
| Gap | Missing, partial, untested, or conflicting implementation |
| Reviewer | Named reviewer and review date |
| Status | UNMAPPED / MAPPED / PARTIAL / TESTED / independently assessed |

Do not fill clause numbers or quote requirements from memory, abstracts, secondary summaries, or catalogue titles. Use an authorized copy of the applicable standard text and record the edition reviewed.

## 4. Evidence rules

1. A catalogue link proves only that the referenced catalogue entry is available; it does not prove SWI conformity.
2. A source file is not, by itself, evidence that a control operates as intended.
3. A passing unit test supports only the behaviour and scope actually exercised by that test.
4. A test record must identify the exact commit, command, environment, test selection, output, and limitations.
5. A missing or inaccessible standard clause must remain **UNASSESSED**, not assumed satisfied.
6. Non-applicability must be justified against the system and organizational scope; it must not be used as a convenient way to avoid an inconvenient requirement.
7. Preserve original evidence and failed historical records. Corrections must be additive and traceable; do not silently rewrite historical outcomes.
8. Independent assessment must be distinguished from project-authored self-assessment.

## 5. Explicit non-claims

This register does **not** establish that:

- SWI is compliant with any of the five standards;
- SWI is certified, accredited, or independently assessed;
- the standards' complete normative requirements have been reviewed;
- every standard applies to SWI in its current system or organizational scope;
- the ISO Evidence Replay Lab is fully integrated with the SWI kernel;
- a passing repository test establishes standards conformity.

```text
CATALOGUE REFERENCES VERIFIED ≠ CLAUSE MAPPING
CLAUSE MAPPING ≠ IMPLEMENTATION
IMPLEMENTATION ≠ TESTED EFFECTIVENESS
TESTED EFFECTIVENESS ≠ CONFORMITY
CONFORMITY ASSESSMENT ≠ CERTIFICATION
```

## 6. Next controlled steps

1. Obtain authorized copies of the standards that are determined to be in scope.
2. Define the SWI system boundary and, separately, any organization-level management-system boundary relevant to ISO/IEC 42001.
3. Complete clause-by-clause applicability mapping with reviewer attribution.
4. Link each applicable clause to specific implementation artifacts and reproducible tests.
5. Record gaps and failed tests without deleting historical evidence.
6. Seek independent review only after the mapping and supporting evidence are complete.

**Current disposition:** Research references recorded. Clause mapping not started. No compliance, certification, seal, or production-authorization status is changed by this document.

## 7. Third-party public-branch reproduction note (not independently reproduced here)

A reviewer report supplied on 2026-11-01 states that a separate public-repository clone showed review-branch head `24aad6f…`, public `main` at `51a67e4`, and no published `feature/swi-dcre-core-doctrine` branch. The same report states that seven critical files matched hashes in `restore_verification.json`, 13 ISO claim-gate tests passed, 536 selected kernel tests passed, and the validator exited 0 in structural-fallback mode because `jsonschema` was unavailable. It further reports that the five ISO entries were all `NOT_ASSESSED` at rung 0, with only placeholder requirements and no clause mapping or substantive evidence.

These are **reviewer-reported observations**, not results reproduced by this document's authoring workspace. This workspace's remote lookup failed with `Could not resolve host: github.com`; therefore no current remote branch, main HEAD, remote commit, or public availability assertion is independently confirmed here. The reviewer explicitly states that the reported tests ran on the review branch, not on `main`.

The reviewer also identified a legacy ambiguity where a `CONFORMITY_CLAIM` field displayed `SEALED` while `ISO_CONFORMITY` remained `NOT_ESTABLISHED`. This repository's terminology rule is that record closure, immutability, or hash-chain sealing never establishes conformity. Historical source records must be corrected additively with an explicit object/status explanation; do not silently rewrite their prior contents.
