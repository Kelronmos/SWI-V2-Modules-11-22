"""Adapter from DCRE assessments into the existing SWI TestReportBuilder.

This is a reporting bridge only. It does not call admission, authority,
execution, sealing, or production-governance APIs.
"""
from __future__ import annotations

from typing import Any

from swi_v2.reports.test_report import ClaimRecord, ObservationRecord

from .engine import ClaimAssessment, Truth


def add_assessment_to_report(builder: Any, assessment: ClaimAssessment) -> ClaimRecord:
    """Record a bounded assessment using existing SWI observation/claim types.

    The report builder remains the single report spine. The assessment is
    represented as an observation of the DCRE evaluator output; its claim is
    separately represented and never promoted to authority.
    """
    observation_id = f"dcre-assessment:{assessment.claim_id}"
    builder.add_observation(ObservationRecord(
        observation_id=observation_id,
        observation_type="DCRE_ASSESSMENT",
        description=(
            f"DCRE evaluated bounded claim {assessment.claim_id!r}: "
            f"truth={assessment.truth.value}, state={assessment.state.value}, "
            f"derived_level={assessment.level.value}."
        ),
        source="swi_v2.claims.evaluate_claim",
        observed_status=assessment.state.value,
        incomplete=assessment.truth is Truth.UNKNOWN,
        uncertain=assessment.truth is Truth.UNKNOWN,
    ))
    status = {
        Truth.TRUE: "VERIFIED",
        Truth.FALSE: "REJECTED",
        Truth.UNKNOWN: "UNRESOLVED",
    }[assessment.truth]
    return builder.add_claim(ClaimRecord(
        claim_id=assessment.claim_id,
        claim_text=f"Bounded claim for scope: {assessment.scope}",
        category="development_claim",
        supporting_observation_ids=[observation_id],
        verification_status=status,
        limitations=list(assessment.reasons) + [
            "DCRE reporting does not grant admission, authority, sealing, or execution permission."
        ],
        unproven=[
            "PROVEN is not inferred from TESTED or VERIFIED.",
            "SEALED and PRODUCTION AUTHORIZED remain under separate SWI governance contracts.",
        ],
    ))
