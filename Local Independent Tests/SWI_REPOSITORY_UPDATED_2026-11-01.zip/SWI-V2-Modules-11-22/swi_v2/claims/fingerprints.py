"""Deterministic content fingerprints; a hash does not establish truth."""
from __future__ import annotations
import hashlib
import platform
import sys
from pathlib import Path
from .engine import Fingerprint, command_digest


def digest_paths(paths: list[str | Path], root: str | Path = ".") -> str:
    base = Path(root).resolve()
    h = hashlib.sha256()
    ignored = {"__pycache__", ".pytest_cache", ".git", ".mypy_cache", ".ruff_cache"}
    for item in sorted((Path(p) for p in paths), key=lambda p: str(p)):
        path = item if item.is_absolute() else base / item
        label = str(path.relative_to(base)) if path.is_relative_to(base) else str(path)
        h.update(label.encode("utf-8") + b"\0")
        if not path.exists():
            h.update(b"MISSING\0")
        elif path.is_file():
            h.update(path.read_bytes())
        elif path.is_dir():
            for child in sorted(p for p in path.rglob("*") if p.is_file() and not ignored.intersection(p.parts)
                                and p.suffix not in {".pyc", ".pyo"}):
                h.update(str(child.relative_to(path)).encode("utf-8") + b"\0")
                h.update(child.read_bytes())
    return "sha256:" + h.hexdigest()


def environment_digest() -> str:
    payload = f"python={sys.version}\nplatform={platform.platform()}\nimplementation={platform.python_implementation()}"
    return "sha256:" + hashlib.sha256(payload.encode()).hexdigest()


def fingerprint(*, implementation: list[str], command: list[str] = (), dependencies: list[str] = (),
                config: list[str] = (), tests: list[str] = (), commit_sha: str | None = None,
                root: str | Path = ".") -> Fingerprint:
    return Fingerprint(
        implementation_digest=digest_paths(implementation, root),
        command_digest=command_digest(command) if command else None,
        dependency_digest=digest_paths(list(dependencies), root) if dependencies else None,
        config_digest=digest_paths(list(config), root) if config else None,
        test_digest=digest_paths(list(tests), root) if tests else None,
        environment_digest=environment_digest(),
        commit_sha=commit_sha,
    )
