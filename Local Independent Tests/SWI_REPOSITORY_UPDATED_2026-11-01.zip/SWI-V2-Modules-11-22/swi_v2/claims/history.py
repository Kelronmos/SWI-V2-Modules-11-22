"""Append-only, hash-chained DCRE history records (integrity, not truth)."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any


def canonical_json(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def append_record(path: str | Path, record: dict[str, Any]) -> dict[str, Any]:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    previous = "GENESIS"
    if target.exists() and target.stat().st_size:
        verified = verify_history(target)
        if not verified["valid"]:
            raise ValueError("history_chain_invalid; refusing to append")
        previous = verified["last_hash"] or "GENESIS"
    body = {"previous_hash": previous, "record": record}
    digest = hashlib.sha256(canonical_json(body)).hexdigest()
    envelope = {**body, "record_hash": f"sha256:{digest}"}
    with target.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(envelope, sort_keys=True, ensure_ascii=False) + "\n")
        stream.flush()
    return envelope


def verify_history(path: str | Path) -> dict[str, Any]:
    target = Path(path)
    previous = "GENESIS"
    count = 0
    if not target.exists():
        return {"valid": True, "records": 0, "last_hash": None, "reason": "history_file_missing"}
    for number, line in enumerate(target.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            envelope = json.loads(line)
            supplied = envelope.pop("record_hash")
        except (json.JSONDecodeError, KeyError, TypeError):
            return {"valid": False, "records": count, "last_hash": previous, "reason": f"malformed_record:{number}"}
        if envelope.get("previous_hash") != previous:
            return {"valid": False, "records": count, "last_hash": previous, "reason": f"chain_link_mismatch:{number}"}
        expected = "sha256:" + hashlib.sha256(canonical_json(envelope)).hexdigest()
        if supplied != expected:
            return {"valid": False, "records": count, "last_hash": previous, "reason": f"record_hash_mismatch:{number}"}
        previous = supplied
        count += 1
    return {"valid": True, "records": count, "last_hash": None if not count else previous, "reason": "hash_chain_valid"}
