"""Evidence-driven, bounded feature claims for SWI.

DCRE is an observer/reporting component. It never grants execution permission,
proof authority, sealing authority, or production authorization.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import hashlib
import json
from enum import Enum
from typing import Callable, Optional


class Truth(str, Enum):
    TRUE = "TRUE"
    FALSE = "FALSE"
    UNKNOWN = "UNKNOWN"


class State(str, Enum):
    NOT_RUN = "NOT_RUN"
    BLOCKED = "BLOCKED"
    PARTIAL = "PARTIAL"
    STALE = "STALE"
    INVALIDATED = "INVALIDATED"
    VERIFIED = "VERIFIED"
    FAILED = "FAILED"


class Level(str, Enum):
    L0_PROPOSED = "L0_PROPOSED"
    L1_DESIGNED = "L1_DESIGNED"
    L2_IMPLEMENTED = "L2_IMPLEMENTED"
    L3_TESTED = "L3_TESTED"
    L4_VERIFIED = "L4_VERIFIED"
    L5_REPRODUCED = "L5_REPRODUCED"
    L6_PROVEN = "L6_PROVEN"
    L7_SEALED = "L7_SEALED"
    L8_PRODUCTION_AUTHORIZED = "L8_PRODUCTION_AUTHORIZED"


_LEVEL_ORDER = list(Level)


@dataclass(frozen=True)
class Fingerprint:
    """Current feature boundary. Any declared binding must match exactly."""
    implementation_digest: Optional[str] = None
    command_digest: Optional[str] = None
    dependency_digest: Optional[str] = None
    config_digest: Optional[str] = None
    test_digest: Optional[str] = None
    environment_digest: Optional[str] = None
    commit_sha: Optional[str] = None


def command_digest(command: tuple[str, ...] | list[str]) -> str:
    """Hash the exact argv vector; this binds evidence to the invoked command."""
    payload = json.dumps(list(command), ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return "sha256:" + hashlib.sha256(payload).hexdigest()


@dataclass(frozen=True)
class EvidenceReference:
    reference: str
    sha256: str
    source: str
    locator: str


@dataclass(frozen=True)
class Verification:
    verification_id: str
    scope: str
    outcome: Truth
    executed: bool
    acceptance_criteria: tuple[str, ...] = ()
    passed_criteria: tuple[str, ...] = ()
    failed_criteria: tuple[str, ...] = ()
    counterexample: Optional[str] = None
    implementation_digest: Optional[str] = None
    tested_implementation_digest: Optional[str] = None
    environment_digest: Optional[str] = None
    recorded_at: Optional[str] = None
    independent_reproduction: bool = False
    reviewer_id: Optional[str] = None
    state: Optional[State] = None
    evidence_refs: tuple[EvidenceReference, ...] = ()
    command: tuple[str, ...] = ()
    exit_code: Optional[int] = None
    dependency_digest: Optional[str] = None
    config_digest: Optional[str] = None
    test_digest: Optional[str] = None
    commit_sha: Optional[str] = None

    def is_stale(self, current: Fingerprint) -> bool:
        bindings = (
            (self.implementation_digest, current.implementation_digest),
            (command_digest(self.command) if self.command else None, current.command_digest),
            (self.dependency_digest, current.dependency_digest),
            (self.config_digest, current.config_digest),
            (self.test_digest, current.test_digest),
            (self.environment_digest, current.environment_digest),
            (self.commit_sha, current.commit_sha),
        )
        return any(recorded is not None and recorded != now for recorded, now in bindings)

    def has_current_evidence(
        self, current: Fingerprint,
        evidence_validator: Optional[Callable[[EvidenceReference], bool]] = None,
    ) -> bool:
        if self.state in {State.STALE, State.INVALIDATED, State.BLOCKED, State.NOT_RUN}:
            return False
        bindings = {
            "implementation_digest": (self.implementation_digest, current.implementation_digest),
            "command_digest": (command_digest(self.command) if self.command else None, current.command_digest),
            "dependency_digest": (self.dependency_digest, current.dependency_digest),
            "config_digest": (self.config_digest, current.config_digest),
            "test_digest": (self.test_digest, current.test_digest),
            "environment_digest": (self.environment_digest, current.environment_digest),
            "commit_sha": (self.commit_sha, current.commit_sha),
        }
        if any(not recorded or not now or recorded != now for recorded, now in bindings.values()):
            return False
        if not self.executed or not self.command or self.exit_code is None or not self.recorded_at:
            return False
        if not current.command_digest or command_digest(self.command) != current.command_digest:
            return False
        if self.tested_implementation_digest != self.implementation_digest:
            return False
        if not self.evidence_refs or evidence_validator is None:
            return False
        if any(not ref.reference or not ref.source or not ref.locator or
               not ref.sha256.startswith("sha256:") or len(ref.sha256) != 71
               or any(ch not in "0123456789abcdefABCDEF" for ch in ref.sha256[7:])
               for ref in self.evidence_refs):
            return False
        try:
            return all(evidence_validator(ref) for ref in self.evidence_refs)
        except Exception:
            return False

    def effective_outcome(
        self, current: Fingerprint,
        evidence_validator: Optional[Callable[[EvidenceReference], bool]] = None,
    ) -> Truth:
        if not self.has_current_evidence(current, evidence_validator):
            return Truth.UNKNOWN
        criteria = set(self.acceptance_criteria)
        passed, failed = set(self.passed_criteria), set(self.failed_criteria)
        if (not criteria or len(self.acceptance_criteria) != len(criteria)
                or any(not item.strip() for item in self.acceptance_criteria)
                or len(self.passed_criteria) != len(passed) or len(self.failed_criteria) != len(failed)
                or not passed.issubset(criteria) or not failed.issubset(criteria) or passed & failed):
            return Truth.UNKNOWN
        if self.outcome == Truth.FALSE:
            # FALSE requires an executed, evidenced counterexample against a
            # declared criterion. A generic failed process is not enough.
            return Truth.FALSE if failed and self.counterexample and self.counterexample.strip() and self.exit_code != 0 else Truth.UNKNOWN
        if self.outcome != Truth.TRUE or self.exit_code != 0:
            return Truth.UNKNOWN
        if failed or passed != criteria:
            return Truth.UNKNOWN
        return Truth.TRUE


@dataclass(frozen=True)
class GovernanceAttestation:
    """Opaque reference to an external authority's decision; not self-validating."""
    level: Level
    reference: str
    authority_id: str


@dataclass(frozen=True)
class Claim:
    claim_id: str
    feature: str
    scope: str
    requirements: tuple[str, ...]
    implementation_refs: tuple[str, ...] = ()
    implementation_digest: Optional[str] = None
    design_refs: tuple[str, ...] = ()
    verifications: tuple[Verification, ...] = ()
    fingerprint: Fingerprint = field(default_factory=Fingerprint)
    governance_attestations: tuple[GovernanceAttestation, ...] = ()


@dataclass(frozen=True)
class ClaimAssessment:
    claim_id: str
    scope: str
    truth: Truth
    level: Level
    state: State
    reasons: tuple[str, ...] = field(default_factory=tuple)
    production_authorized: bool = False


def evaluate_claim(
    claim: Claim,
    *,
    evidence_validator: Optional[Callable[[EvidenceReference], bool]] = None,
    reviewer_validator: Optional[Callable[[str, Verification], bool]] = None,
    attestation_validator: Optional[Callable[[GovernanceAttestation], bool]] = None,
) -> ClaimAssessment:
    """Derive a claim level from evidence; never infer governance authority.

    L6-L8 are reported only if an injected, existing SWI governance adapter
    independently validates the corresponding external attestation. Without
    that adapter, the maximum automatically-derived level is L5.
    """
    reasons: list[str] = []
    if (not claim.claim_id.strip() or not claim.feature.strip() or not claim.scope.strip()
            or not claim.requirements or any(not item.strip() for item in claim.requirements)
            or len(set(claim.requirements)) != len(claim.requirements)):
        return ClaimAssessment(claim.claim_id, claim.scope, Truth.UNKNOWN, Level.L0_PROPOSED,
                               State.BLOCKED, ("claim_identity_scope_or_requirements_missing",))

    level = Level.L0_PROPOSED
    if claim.design_refs:
        level = Level.L1_DESIGNED
    if claim.implementation_refs and claim.implementation_digest:
        level = Level.L2_IMPLEMENTED
    else:
        reasons.append("implementation_reference_or_digest_missing")

    scoped = [v for v in claim.verifications if v.scope == claim.scope]
    current_fingerprint = claim.fingerprint
    if current_fingerprint == Fingerprint() and claim.implementation_digest:
        current_fingerprint = Fingerprint(implementation_digest=claim.implementation_digest)
    required = set(claim.requirements)
    current_evidence = [v for v in scoped if set(v.acceptance_criteria).issubset(required)
                        and v.has_current_evidence(current_fingerprint, evidence_validator)]
    if current_evidence:
        level = max(level, Level.L3_TESTED, key=_LEVEL_ORDER.index)
    effective = [(v, v.effective_outcome(current_fingerprint, evidence_validator)
                  if set(v.acceptance_criteria).issubset(required) else Truth.UNKNOWN) for v in scoped]
    valid = [(v, result) for v, result in effective if result != Truth.UNKNOWN]

    if any(result == Truth.FALSE for _, result in valid):
        return ClaimAssessment(claim.claim_id, claim.scope, Truth.FALSE, level, State.FAILED,
                               tuple(reasons + ["evidenced_counterexample_for_claim_scope"]))
    if not scoped:
        return ClaimAssessment(claim.claim_id, claim.scope, Truth.UNKNOWN, level, State.NOT_RUN,
                               tuple(reasons + ["no_verification_for_scope"]))
    if not valid:
        invalidated = any(v.state == State.INVALIDATED for v in scoped)
        stale = any(v.state == State.STALE or v.is_stale(current_fingerprint) for v in scoped)
        state = (State.INVALIDATED if invalidated else State.STALE if stale else
                 State.BLOCKED if all(v.state == State.BLOCKED for v in scoped) else State.PARTIAL)
        return ClaimAssessment(claim.claim_id, claim.scope, Truth.UNKNOWN, level, state,
                               tuple(reasons + ["no_current_complete_verification"]))

    passing = [v for v, result in valid if result == Truth.TRUE]
    if not passing:
        return ClaimAssessment(claim.claim_id, claim.scope, Truth.UNKNOWN, level, State.PARTIAL,
                               tuple(reasons + ["no_complete_passing_verification"]))

    level = max(level, Level.L3_TESTED, key=_LEVEL_ORDER.index)
    covered_requirements = set().union(*(set(v.passed_criteria) for v in passing))
    if required.issubset(covered_requirements):
        level = Level.L4_VERIFIED
    else:
        return ClaimAssessment(claim.claim_id, claim.scope, Truth.UNKNOWN, level, State.PARTIAL,
                               tuple(reasons + ["verification_does_not_cover_all_claim_requirements"]))
    if reviewer_validator:
        for verification in passing:
            if verification.independent_reproduction and verification.reviewer_id and verification.reviewer_id.strip():
                try:
                    if reviewer_validator(verification.reviewer_id, verification):
                        level = Level.L5_REPRODUCED
                        break
                except Exception:
                    pass

    # External governance is queried, never created, by this engine.
    if attestation_validator:
        for attestation in claim.governance_attestations:
            if not attestation.reference or not attestation.authority_id:
                continue
            try:
                accepted = bool(attestation_validator(attestation))
            except Exception:
                accepted = False
            if accepted and attestation.level in {Level.L6_PROVEN, Level.L7_SEALED, Level.L8_PRODUCTION_AUTHORIZED}:
                level = max(level, attestation.level, key=_LEVEL_ORDER.index)

    # Even a validated external attestation is only observed and reported.
    # This assessment object never grants permission or authorizes action.
    return ClaimAssessment(claim.claim_id, claim.scope, Truth.TRUE, level, State.VERIFIED,
                           tuple(reasons), False)

@dataclass(frozen=True)
class FeatureAssessment:
    feature: str
    truth: Truth
    level: Level
    claim_assessments: tuple[ClaimAssessment, ...]
    reasons: tuple[str, ...] = ()


def evaluate_feature(
    feature: str,
    required_claims: tuple[Claim, ...],
    *,
    evidence_validator: Optional[Callable[[EvidenceReference], bool]] = None,
    attestation_validator: Optional[Callable[[GovernanceAttestation], bool]] = None,
    reviewer_validator: Optional[Callable[[str, Verification], bool]] = None,
) -> FeatureAssessment:
    """Aggregate required claims conservatively for one feature.

    A feature's level is the lowest attained level among its required claims;
    one advanced subclaim cannot mask a missing or weaker required subclaim.
    """
    if not feature or not required_claims:
        return FeatureAssessment(feature, Truth.UNKNOWN, Level.L0_PROPOSED, (),
                                 ("feature_or_required_claims_missing",))
    assessments = tuple(evaluate_claim(c, evidence_validator=evidence_validator,
                                        reviewer_validator=reviewer_validator,
                                        attestation_validator=attestation_validator) for c in required_claims)
    if any(c.feature != feature for c in required_claims):
        return FeatureAssessment(feature, Truth.UNKNOWN, Level.L0_PROPOSED, assessments,
                                 ("claim_feature_mismatch",))
    level = min((a.level for a in assessments), key=_LEVEL_ORDER.index)
    if any(a.truth == Truth.FALSE for a in assessments):
        truth = Truth.FALSE
    elif all(a.truth == Truth.TRUE for a in assessments):
        truth = Truth.TRUE
    else:
        truth = Truth.UNKNOWN
    reasons = tuple(f"{a.claim_id}:{a.state.value}" for a in assessments if a.truth != Truth.TRUE)
    return FeatureAssessment(feature, truth, level, assessments, reasons)
