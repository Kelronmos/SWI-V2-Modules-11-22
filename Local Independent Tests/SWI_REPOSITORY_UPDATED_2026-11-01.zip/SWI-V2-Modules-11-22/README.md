# SWI V2 — Modules 11–22

```text
Serialized V1 evidence → M11 → AdmittedInput → post-admission seal → Kernel
```

**Licence:** [Apache License 2.0](LICENSE) · **Provenance:** [NOTICE](NOTICE) · [AUTHORS_AND_LEGACY.md](AUTHORS_AND_LEGACY.md)  
**Contribute:** [CONTRIBUTING.md](CONTRIBUTING.md) · **Security:** [SECURITY.md](SECURITY.md)

**M11:** **SEALED** — record: [`docs/M11_SEAL_RECORD.md`](docs/M11_SEAL_RECORD.md)  
**Evidence tip:** V2 `1d6d7dc` · CI run [35253244912](https://github.com/Kelronmos/SWI-V2-Modules-11-22/actions/runs/35253244912)  
**M12–22:** **OPEN for controlled development** (claim → implement → test; not auto-complete)  
**CRTG / prod keys:** NOT IMPLEMENTED  

```bash
pip install -r requirements.txt && python -m pytest -q
```

Two-checkout: `.github/workflows/two_checkout_travel.yml`  
Status notes: [`docs/TWO_CHECKOUT_CI_STATUS.md`](docs/TWO_CHECKOUT_CI_STATUS.md)

## Governing formula (authorization spine)

```text
Permit(a) ⟺ ∀L,G,S,H: C(a) ⊆ L ∩ G ∩ S ∩ H  ∧  E(a) ≠ ∅
```

| Artifact | Path | Status |
|----------|------|--------|
| Predicate (pure evaluator) | [`swi_v2/kernel/governing_permit.py`](swi_v2/kernel/governing_permit.py) | **IMPLEMENTED / TESTED** |
| Executable tests | [`test/test_governing_formula.py`](test/test_governing_formula.py) | **TESTED** |
| Machine-readable test record | [`evidence/governing_formula_test_record.json`](evidence/governing_formula_test_record.json) | evidence only |
| Human-readable test record | [`docs/evidence/SWI_GOVERNING_FORMULA_TEST_RECORD.md`](docs/evidence/SWI_GOVERNING_FORMULA_TEST_RECORD.md) | evidence only |

**Hard non-claims (do not upgrade automatically):**

```text
TESTED ≠ PROVEN
PROVEN ≠ SEALED
SEALED ≠ PRODUCTION AUTHORIZED
production_authorized = false
```

## S9 / formal attack surface (not a proof)

S9 remains **NOT PROVEN**. The formal records document the equation under attack and counterexamples X1–X10:

| Record | Path |
|--------|------|
| S9 mathematical attack | [`docs/formal/S9_MATHEMATICAL_ATTACK_2026-09-24.md`](docs/formal/S9_MATHEMATICAL_ATTACK_2026-09-24.md) |
| S9 → 360 phase obligation binding | [`docs/formal/S9_360_PHASE_OBLIGATION_BINDING.md`](docs/formal/S9_360_PHASE_OBLIGATION_BINDING.md) |
| S9 ZIP / proof-package manual (branch) | `s9/zip-proof-package-harness` → [`docs/formal/S9_ZIP_PROOF_PACKAGE_MANUAL.md`](https://github.com/Kelronmos/SWI-V2-Modules-11-22/blob/s9/zip-proof-package-harness/docs/formal/S9_ZIP_PROOF_PACKAGE_MANUAL.md) |

```text
GENERATED ZIP ≠ EXECUTED PROOF
REPLAY RECORD ≠ DURABLE REPLAY
GREEN TEST ≠ S9 PROVEN
SIGNATURE ≠ AUTHORITY
```

Global: **S9 = NOT PROVEN** · **Execution corridor not production-authorized** · **Durable replay = NOT IMPLEMENTED** (see [`docs/MODULE_STATUS.md`](docs/MODULE_STATUS.md)).

## Collaboration

SWI is open to technical collaboration under Apache-2.0.

Developers, researchers, security reviewers, and independent implementers may inspect the repositories, reproduce tests, identify limitations, propose changes, and contribute improvements.

SWI follows an evidence-first model:

Claim → Implementation → Test → Result → Limitation → Next iteration.

Contributors must distinguish proposed, implemented, tested, CI-verified, audited, sealed, and independently verified behaviour.

Project provenance and contributor attribution are maintained separately from the technical evidence record.  
**Licence change does not alter the M11 seal or any historical technical evidence.**


## Current DCRE claim status

<!-- DCRE_CLAIM_STATUS:START -->
## Current DCRE claim status for this checkout (machine-generated)

- **Claim:** `SWI-DCRE-LOCAL-RECONCILIATION-001` — Import missing public-main reconciliation evidence into the existing SWI DCRE feature checkout without overwriting newer files
- **Assessment:** **PARTIAL / UNKNOWN** · **L3_TESTED**
- **Checkout branch:** `feature/swi-dcre-core-doctrine`
- **Evidence references:** 25/25 hash-checked
- **Source commit tested:** `52567d1a496bd90d04385b3456ae7c0fa2e36750`
- **Public main claim:** **NOT VERIFIED**
- **CI:** NOT_RUN
- **Production authorized:** **NO**
- **Record:** [`evidence/claims/current_verification_run.json`](evidence/claims/current_verification_run.json)
- **Main publication gate:** NOT MET — requires clean `main`, an exact HEAD-bound record, valid evidence hashes, passing tests/build/schema checks and CI PASS.

> This is a bounded checkout-specific development assessment, not proof, sealing, conformity, or permission to execute. A feature-branch record is not a public-main verification.
<!-- DCRE_CLAIM_STATUS:END -->

## Engineering claims and recovery doctrine

SWI's bounded Development Claim & Reality Engine (DCRE) and the BEFORE → DURING → AFTER engineering doctrine are documented here:

- [Development Claim & Reality Engine](docs/DEVELOPMENT_CLAIM_REALITY_ENGINE.md)
- [DCRE Operator Manual](docs/DCRE_OPERATOR_MANUAL.md)
- [DCRE README Claim Status Automation](docs/DCRE_README_STATUS_AUTOMATION.md)
- [Repository Verification Runner](docs/verification/REPOSITORY_VERIFICATION_RUNNER.md)
- [Local Import Reconciliation (2026-11-01)](docs/verification/LOCAL_IMPORT_RECONCILIATION_2026-11-01.md)
- [Autonomous Build, Repair, Recovery & Evidence Governance Doctrine](docs/engineering/SWI_AUTONOMOUS_BUILD_REPAIR_RECOVERY_EVIDENCE_DOCTRINE.md)
- [Claim-Level Evidence Ledger](docs/runtime/CLAIM_EVIDENCE_LEDGER.md)
- [Evidence Freshness Contract](docs/runtime/EVIDENCE_FRESHNESS_CONTRACT.md)
- [Official ISO Standard Reference Register (reference only; no conformity claim)](docs/standards/ISO_STANDARD_REFERENCE_REGISTER.json)
- [ISO Standard Evidence and Claim Policy](docs/standards/ISO_STANDARD_EVIDENCE_AND_CLAIM_POLICY.md)
- [ISO Standards Review Register (five separate research references; unmapped)](docs/review/ISO_STANDARDS_REVIEW.md)

**ISO status clarification:** the DCRE reference register has three entries; the separate ISO Evidence & Replay Lab research register has five. All remain unassessed/unmapped. A `SEALED` record or hash-chain state means record integrity/closure only; it does **not** mean ISO conformity, certification, authorization, or production approval. See [ISO Reference, Runtime and Evidence Boundary](docs/iso/ISO_DCRE_ALIGNMENT_AND_RUNTIME_BOUNDARY.md).

DCRE is an evidence/reporting component only. It does not grant authority, authorize execution, seal a system, or authorize production.
