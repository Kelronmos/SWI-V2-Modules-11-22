# DCRE Claim History Report

- History chain valid: **True**
- Records: **9**
- Last record hash: `sha256:15d981a2cee14c37eb248f119a5175768d95783a6195387a66bdc3c4cb8c3247`

> Hash-chain validity is byte-integrity evidence only; it does not establish claim truth, evidence relevance, or authority.

## Records

### 1. DCRE-LOCAL-TEST-001

- Feature: SWI Development Claim & Reality Engine local candidate
- Scope: the isolated local update pack at /mnt/data/swi_dcre_update; not the target SWI repository
- Truth: UNKNOWN
- Level: L2_IMPLEMENTED
- State: PARTIAL
- Evidence: evidence/LOCAL_VERIFICATION_2026-10-31.txt

### 2. DCRE-LOCAL-TEST-002

- Feature: SWI Development Claim & Reality Engine local candidate
- Scope: isolated local update pack at /mnt/data/swi_dcre_update; exact source tree not tied to a Git commit
- Truth: UNKNOWN
- Level: L2_IMPLEMENTED
- State: PARTIAL
- Evidence: evidence/LOCAL_VERIFICATION_2026-10-31.txt

### 3. DCRE-EVIDENCE-REF-CORRECTION-001

- Feature: DCRE evidence ledger correction
- Scope: append-only history evidence reference reconciliation
- Truth: UNKNOWN
- Level: L0_PROPOSED
- State: INVALIDATED
- Evidence: evidence/EVIDENCE_REFERENCE_CORRECTION_2026-10-31.txt

### 4. DCRE-LOCAL-TEST-003

- Feature: SWI Development Claim & Reality Engine local candidate
- Scope: isolated candidate package at /mnt/data/SWI_DCRE_AUTOMATION_RUN_2026-11-01/candidate; not the target SWI repository
- Truth: UNKNOWN
- Level: L2_IMPLEMENTED
- State: PARTIAL
- Evidence: evidence/runs/2026-11-01/command_log.jsonl, evidence/runs/2026-11-01/remote_access.txt

### 5. DCRE-CORE-001

- Feature: SWI Development Claim & Reality Engine integrated with supplied SWI snapshot reporting spine
- Scope: Bounded DCRE engine, schemas, CLI, append-only evidence history, and adapter to existing TestReportBuilder; supplied snapshot only; no upstream Git metadata.
- Truth: UNKNOWN
- Level: L3_TESTED
- State: PARTIAL
- Evidence: evidence/runs/2026-11-01/dcre-update/focused_pytest.stdout.txt, evidence/runs/2026-11-01/dcre-update/full_pytest.stdout.txt, evidence/runs/2026-11-01/dcre-update/compileall.stdout.txt, evidence/runs/2026-11-01/dcre-update/schema_validation.stdout.txt, evidence/runs/2026-11-01/dcre-update/history_validation.stdout.txt

### 6. UNNAMED

- Feature: NOT_RECORDED
- Scope: Existing SWI observation/claim separation, authority non-escalation, evidence freshness, and replay tests on synthetic ZIP-derived local branch.
- Truth: UNKNOWN
- Level: NOT_RECORDED
- State: NOT_RECORDED
- Evidence: NONE

### 7. DCRE-RUNTIME-BOUNDARY-001

- Feature: SWI DCRE runtime-bound evidence verification and ISO reference register
- Scope: Supplied ZIP-derived local branch only; focused DCRE tests, compile, schema validation, ISO reference register JSON validity, static telemetry-string scan; full repository test collection and remote access assessed separately. No runtime-wide wiring or ISO clause conformity claimed.
- Truth: UNKNOWN
- Level: L3_TESTED
- State: PARTIAL
- Evidence: evidence/runs/2026-11-01/dcre-runtime-refresh/focused_dcre.stdout.txt, evidence/runs/2026-11-01/dcre-runtime-refresh/focused_dcre.exit_code, evidence/runs/2026-11-01/dcre-runtime-refresh/compileall.stdout.txt, evidence/runs/2026-11-01/dcre-runtime-refresh/compileall.exit_code, evidence/runs/2026-11-01/dcre-runtime-refresh/schemas.stdout.txt, evidence/runs/2026-11-01/dcre-runtime-refresh/schemas.exit_code, evidence/runs/2026-11-01/dcre-runtime-refresh/full_pytest.stdout.txt, evidence/runs/2026-11-01/dcre-runtime-refresh/full_pytest.exit_code, evidence/runs/2026-11-01/dcre-runtime-refresh/iso_register_json.stdout.txt, evidence/runs/2026-11-01/dcre-runtime-refresh/iso_register_json.exit_code, evidence/runs/2026-11-01/dcre-runtime-refresh/remote_ls_remote.stdout.txt, evidence/runs/2026-11-01/dcre-runtime-refresh/remote_ls_remote.stderr.txt, evidence/runs/2026-11-01/dcre-runtime-refresh/remote_ls_remote.exit_code

### 8. UNNAMED

- Feature: NOT_RECORDED
- Scope: NOT_RECORDED
- Truth: UNKNOWN
- Level: NOT_RECORDED
- State: NOT_RECORDED
- Evidence: NONE

### 9. DCRE-RUNTIME-BOUNDARY-002

- Feature: SWI DCRE bounded development claim engine, evidence replay and ISO reference register
- Scope: Local supplied ZIP-derived synthetic checkout only: DCRE focused tests, selected replay/observation/authority regression, compile, schema validation and append-only history validation. Not full SWI runtime validation or ISO conformity assessment.
- Truth: UNKNOWN
- Level: L3_TESTED
- State: PARTIAL
- Evidence: NONE
