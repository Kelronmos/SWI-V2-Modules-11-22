# DCRE Claim History Report

- History chain valid: **True**
- Records: **6**
- Last record hash: `sha256:cdc1d746e81dccb7fe1702096291362113c81250d3c5a9d375476f56adc8d4ba`

> Hash-chain validity is byte-integrity evidence only; it does not establish claim truth, evidence relevance, or authority.

## Records

### 1. DCRE-LOCAL-TEST-001

- Feature: SWI Development Claim & Reality Engine local candidate
- Scope: the isolated local update pack at /mnt/data/swi_dcre_update; not the target SWI repository
- Truth: UNKNOWN
- Level: L2_IMPLEMENTED
- State: PARTIAL
- Evidence: evidence/LOCAL_VERIFICATION_2026-10-31.txt

### 2. DCRE-LOCAL-TEST-002

- Feature: SWI Development Claim & Reality Engine local candidate
- Scope: isolated local update pack at /mnt/data/swi_dcre_update; exact source tree not tied to a Git commit
- Truth: UNKNOWN
- Level: L2_IMPLEMENTED
- State: PARTIAL
- Evidence: evidence/LOCAL_VERIFICATION_2026-10-31.txt

### 3. DCRE-EVIDENCE-REF-CORRECTION-001

- Feature: DCRE evidence ledger correction
- Scope: append-only history evidence reference reconciliation
- Truth: UNKNOWN
- Level: L0_PROPOSED
- State: INVALIDATED
- Evidence: evidence/EVIDENCE_REFERENCE_CORRECTION_2026-10-31.txt

### 4. DCRE-LOCAL-TEST-003

- Feature: SWI Development Claim & Reality Engine local candidate
- Scope: isolated candidate package at /mnt/data/SWI_DCRE_AUTOMATION_RUN_2026-11-01/candidate; not the target SWI repository
- Truth: UNKNOWN
- Level: L2_IMPLEMENTED
- State: PARTIAL
- Evidence: evidence/runs/2026-11-01/command_log.jsonl, evidence/runs/2026-11-01/remote_access.txt

### 5. DCRE-CORE-001

- Feature: SWI Development Claim & Reality Engine integrated with supplied SWI snapshot reporting spine
- Scope: Bounded DCRE engine, schemas, CLI, append-only evidence history, and adapter to existing TestReportBuilder; supplied snapshot only; no upstream Git metadata.
- Truth: UNKNOWN
- Level: L3_TESTED
- State: PARTIAL
- Evidence: evidence/runs/2026-11-01/dcre-update/focused_pytest.stdout.txt, evidence/runs/2026-11-01/dcre-update/full_pytest.stdout.txt, evidence/runs/2026-11-01/dcre-update/compileall.stdout.txt, evidence/runs/2026-11-01/dcre-update/schema_validation.stdout.txt, evidence/runs/2026-11-01/dcre-update/history_validation.stdout.txt

### 6. UNNAMED

- Feature: NOT_RECORDED
- Scope: Existing SWI observation/claim separation, authority non-escalation, evidence freshness, and replay tests on synthetic ZIP-derived local branch.
- Truth: UNKNOWN
- Level: NOT_RECORDED
- State: NOT_RECORDED
- Evidence: NONE
