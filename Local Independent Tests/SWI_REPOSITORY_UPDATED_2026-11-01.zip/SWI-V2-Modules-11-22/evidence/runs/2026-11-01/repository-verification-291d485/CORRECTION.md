# Historical run correction

This run was produced by commit `291d48558fe0955d31a328bcd3a780a74324e06d`.
Its raw pytest output records **5 errors** in the full suite and **1 failed**
in the kernel subset. The first runner version's summary parser matched the
singular word `error` but not plural `errors`, so the JSON count field reported
zero errors incorrectly. The raw output and exit codes are preserved unchanged.

The parser was corrected and regression-tested in commit
`5bf3657bf347f77859f082a84a115b64e10175a1`. Do not use this historical JSON
count field as a corrected count; use the raw stdout files. No test was changed
or weakened to conceal the failures.
