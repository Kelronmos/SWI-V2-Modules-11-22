# SWI repository verification — 2026-11-01

## Scope and checkout

- Branch: `feature/swi-dcre-core-doctrine`
- Source commit tested: `19fafd13312c1fea85a851dd9c19cf1a5f5103d7`
- Source tree clean before the run: `true`
- This is a synthetic local Git history created from a source ZIP, not a proven descendant of public `main`.

## Results

| Check | Result |
|---|---:|
| Governing formula tests | **11 passed** |
| Kernel subset (`cek_alignment_monitor`, `law`, `pre_r`) | **535 passed, 1 failed** |
| ISO claim validator | **ABSENT** — files are not on this branch |
| ISO claim-gate tests | **ABSENT** — file is not on this branch |
| Full repository suite | **703 passed, 1 failed, 5 collection errors** |
| DCRE claim tests | **44 passed** |
| Python compileall | **PASS** |
| Three JSON schemas + aggregate verification record | **VALID** |
| Append-only claim history | **18 records; hash chain valid** |
| GitHub remote lookup | **BLOCKED** — DNS could not resolve `github.com` (exit 128) |

### Failure diagnosis

The kernel subset failure is `tests/law/test_evidence_freshness.py::test_evidence_source_tip_reachable_from_head`. The preserved law evidence records source tip `8245e3f03d8673c966abf9c63be9d838073159b0`, which is not present/reachable in this synthetic local Git history. This is a provenance/ancestry failure. The source-tip fields and test were not weakened or rewritten to make the result green.

The full-suite collection errors include four adversarial imports blocked by the malformed `swi_v2/execution_integrity_body.py` source and one trusted-source inspector import blocked by the literal placeholder in `swi_v2/trusted_source/spine_inspector.py`. The full-suite output is preserved in `full_suite.stdout.txt`.

## Imported reviewer evidence

The separately supplied reviewer run is preserved under `evidence/external/2026-11-01/reviewer-main-run/`. Its own JSON records commit `9d1576e8af81...`, while the accompanying narrative identifies public `main` as `51a67e4`. Because these commit identifiers differ and no upstream Git object bundle was supplied to reconcile them, the imported run is not treated as independently verified public-main evidence.

## Governance result

- Repository assessment: **NOT_VERIFIED**
- Claim truth: **UNKNOWN**
- State: **PARTIAL**
- Development level: **L3_TESTED**
- `proven`: **false**
- `sealed`: **false**
- `production_authorized`: **false**
- ISO conformity: **NOT ESTABLISHED**

A passing subset does not override a failing kernel subset or full suite. The existing DCRE README renderer remains the only claim-display mechanism and continues to require its strict clean-`main`, exact-HEAD, evidence, test/build/schema, and CI gate before public-main verification. This feature branch cannot publish a public-main VERIFIED claim.
