# SWI Discipline Update — ISO Claim Clarity and Main-Branch Publication Gate

**Run date:** 2026-11-01  
**Tested source commit:** `e2cccb9db6688c025758946d92379368ba3aafa0`  
**Branch:** `feature/swi-dcre-core-doctrine`  
**Truth:** `UNKNOWN` · **State:** `PARTIAL` · **Level:** `L3_TESTED`  
**Production authorized:** `NO`

## Changes delivered

1. The README claim panel now identifies the current checkout and displays `Public main claim: NOT VERIFIED` on feature branches.
2. A public-main `VERIFIED` display now requires all of the following: current branch is `main`; record branch is `main`; record commit exactly equals current HEAD; worktree is clean; evidence references hash-match; tests/build/schema checks pass; CI is `PASS`; and `production_authorized` remains false.
3. Added five adversarial tests for the main-publication gate: feature branch, stale commit, dirty tree, CI not run, and the positive exact-main condition.
4. Clarified that the DCRE-local ISO register contains three standards, while the separate ISO Evidence & Replay Lab research dossier contains five. They are separate inventories, not conflicting counts.
5. Added the five-standard research register and explicitly attributed the external review's public-branch/test observations as reviewer-reported, not independently reproduced in this workspace.
6. Added a `SEALED` terminology boundary: record closure, immutability, or hash-chain sealing does not establish ISO conformity, certification, authorization, or production approval. Historical records were not silently rewritten.
7. Appended a bounded `UNKNOWN / PARTIAL / L3_TESTED` event to the existing DCRE append-only claim history. The history now verifies as 17 records.

## Local verification

| Check | Result | Exit |
|---|---:|---:|
| `python -m pytest -q tests/claims` | 40 passed | 0 |
| `python -m compileall -q swi_v2 tools tests` | PASS | 0 |
| Three DCRE schemas + aggregate run JSON | VALID | 0 |
| DCRE claim history | 17 records, hash chain valid | 0 |
| Evidence references | 32 / 32 hash-checked | 0 |
| Full `python -m pytest -q` | BLOCKED at collection; 5 errors | 2 |
| `git ls-remote origin ...` | DNS failure; remote refs unavailable | 128 |

### Full-suite collection blockers

- Four adversarial test imports fail while dynamically compiling `swi_v2/execution_integrity_body.py`: `IndentationError` at line 56, `authority.token:`.
- One trusted-source test import fails because `swi_v2/trusted_source/spine_inspector.py` executes the unresolved placeholder `PLACEHOLDER_LOAD_FROM_LOCAL_FILE_20747_BYTES` and raises `NameError`.

These source defects were not patched because the required original payload/source was not available in this checkout. `compileall` does not validate dynamically reconstructed payload strings.

## Remote/publication boundary

This update is committed only to the local feature branch. The workspace remote lookup failed with `Could not resolve host: github.com`; no push, pull, PR, GitHub CI, or public-main update occurred. The local repository history is synthetic and upstream ancestry has not been proven. The external review's stated public `main` SHA `51a67e4` and review branch SHA `24aad6f…` are recorded only as reviewer-reported observations in `docs/review/ISO_STANDARDS_REVIEW.md`.

The ISO lab's reported 13 claim-gate tests and 536 selected kernel tests were not rerun in this workspace. No ISO clause mapping, conformity assessment, certification, independent audit, proof, seal, or production authorization is claimed.

## Current README display

The README now reports `PARTIAL / UNKNOWN · L3_TESTED`, identifies `feature/swi-dcre-core-doctrine`, and explicitly displays `Public main claim: NOT VERIFIED`. This is the intended safe behaviour until a clean, exact-HEAD-bound record and passing CI are produced on the real public `main` branch.
