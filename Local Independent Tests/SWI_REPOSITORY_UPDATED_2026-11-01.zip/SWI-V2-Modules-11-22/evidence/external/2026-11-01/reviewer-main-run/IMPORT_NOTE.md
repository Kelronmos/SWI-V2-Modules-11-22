# Imported reviewer run — provenance boundary

This directory preserves the uploaded `evidence_run_2026-11-01.zip` without
relabeling it as a run performed in this checkout.

The included `auto-claim-display/verification_run.json` records commit
`9d1576e8af81a79f54409cd3cd9b4d1a78f957ad`, Python 3.12.3, 11 governing-formula
tests passed, 536 kernel-subset tests passed, the ISO validator and ISO gate
tests as `ABSENT`, and the full suite as 704 passed with 5 errors. It reports
`VERIFIED (SCOPED)` for those two bounded subsets while explicitly reporting the
full suite as failed and production authorization as false.

The accompanying narrative supplied with the upload separately says public
`main` was at `51a67e4`. Those identifiers do not match the commit recorded in
the JSON. No source bundle or independently verifiable Git ancestry was
provided to reconcile that discrepancy. Accordingly, this is imported,
reviewer-supplied evidence, not independently reproduced evidence and not a
public-main verification by this checkout.

The uploaded evidence is preserved as received. Its original SHA-256 manifest
is retained. No `__pycache__` or `.pyc` files from the accompanying patch were
imported into the repository.

`proven=false`; `sealed=false`; `production_authorized=false`;
`ISO_CONFORMITY=NOT_ESTABLISHED`.
