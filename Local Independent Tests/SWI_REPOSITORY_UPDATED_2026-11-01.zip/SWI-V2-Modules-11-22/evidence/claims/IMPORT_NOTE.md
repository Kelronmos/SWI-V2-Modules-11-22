# Public-main snapshot evidence import boundary — 1 November 2026

The adjacent `runs/2026-11-01/repository-verification-snapshot-no-git-final3/`
records and `reports/PUBLIC_MAIN_RECONCILIATION_2026-11-01.md` were imported
from a local reconciliation of the supplied source ZIP. That ZIP had no `.git`
metadata and was not proven to be the public `main` commit named in the review
narrative. These records are retained as source-snapshot evidence only.

They are not current verification for this Git checkout, do not establish
upstream ancestry, and must not be used as a public-main badge. The
`current_verification_run.json` source-snapshot record was deliberately not
copied to that canonical path. A new checkout-bound record must be generated
from a clean, identified Git commit after running the checks in this checkout.

`truth=UNKNOWN`; `proven=false`; `sealed=false`;
`ISO_CONFORMITY=NOT_ESTABLISHED`; `production_authorized=false`.
