# Historical claim-history snapshots

Files in this directory are immutable historical snapshots. They are not the live ledger. The current append-only ledger is `../claim_history.jsonl` and is validated independently. A snapshot with 17 records is intentionally retained as historical evidence and must not be described as the current record count.

`claim_history_18_records_2026-11-01.jsonl` is the immutable 18-record
snapshot used by the 1 November 2026 public-main evidence-import verification.
The live ledger may continue to append; historical run references point to the
snapshot, not the mutable live file.
