# SWI Firefly Replay — Experimental Evidence Package

Operation: SWI-FIREFLY-FULL-REPLAY-001

Classification: EXPERIMENTAL / LOCAL SYNTHETIC BENCHMARK

Recorded test:
- Transactions: 100,000
- Runtime: 27.216156058 seconds
- Throughput: 3,674.288 transactions/second
- Replay status: PASS (reported)
- Evidence manifest: PASS (locally verified)
- ZIP integrity: PASS (locally verified)

Limitations:
- Synthetic data only.
- Independent correctness NOT ESTABLISHED.
- Privacy enforcement NOT PROVEN.
- 3.5 billion transactions in 1.2 seconds NOT TESTED.
- Production authorization NOT GRANTED.

The package must not be interpreted as production approval,
ISO certification, independent validation, or proof of the
requested performance target.
