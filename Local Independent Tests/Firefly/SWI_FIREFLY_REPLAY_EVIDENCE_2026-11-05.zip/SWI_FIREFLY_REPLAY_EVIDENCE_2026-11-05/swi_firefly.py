#!/usr/bin/env python3
import argparse
import csv
import hashlib
import hmac
import json
import os
import platform
import random
import sys
import time
import tracemalloc
import zipfile
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path.cwd()
EVIDENCE = ROOT / "evidence"
EXPORTS = ROOT / "exports"
EVIDENCE.mkdir(exist_ok=True)
EXPORTS.mkdir(exist_ok=True)

def utc():
    return datetime.now(timezone.utc).isoformat()

def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, sort_keys=True))

def make_transactions(count, subjects, seed):
    """Deterministic synthetic data. No real personal or financial data."""
    rng = random.Random(seed)
    reference = {}
    for i in range(count):
        account = rng.randrange(max(1, subjects))
        subject = f"synthetic-subject-{account}"
        delta = rng.randint(-500, 500)
        reference[account] = reference.get(account, 0) + delta
        yield {
            "sequence": i,
            "account": account,
            "subject": subject,
            "delta_cents": delta,
            "expected_balance_cents": reference[account],
        }

def firefly_key(secret, subject):
    return hmac.new(
        secret, subject.encode("utf-8"), hashlib.sha256
    ).hexdigest()

def replay(count, subjects, seed):
    secret = os.urandom(32)
    balances = {}
    firefly_memory = {}
    previous_hash = "0" * 64
    processed = 0
    mismatches = 0
    privacy_raw_subjects_retained = 0

    tracemalloc.start()
    start_ns = time.perf_counter_ns()

    for tx in make_transactions(count, subjects, seed):
        # Sequence accounting detects gaps and unexpected ordering.
        if tx["sequence"] != processed:
            mismatches += 1

        account = tx["account"]
        actual = balances.get(account, 0) + tx["delta_cents"]
        balances[account] = actual

        if actual != tx["expected_balance_cents"]:
            mismatches += 1

        # Firefly: retain pseudonymous aggregates, not raw subject IDs
        # or individual transaction records.
        pseudonym = firefly_key(secret, tx["subject"])
        aggregate = firefly_memory.setdefault(
            pseudonym, {"count": 0, "net_delta_cents": 0}
        )
        aggregate["count"] += 1
        aggregate["net_delta_cents"] += tx["delta_cents"]

        canonical = (
            f'{tx["sequence"]}|{account}|{tx["delta_cents"]}|'
            f'{tx["expected_balance_cents"]}'
        ).encode()
        previous_hash = hashlib.sha256(
            previous_hash.encode() + canonical
        ).hexdigest()

        processed += 1

    elapsed_ns = time.perf_counter_ns() - start_ns
    current_bytes, peak_bytes = tracemalloc.get_traced_memory()
    tracemalloc.stop()

    seconds = elapsed_ns / 1_000_000_000
    rate = processed / seconds if seconds else 0

    # Firefly export contains aggregates only. The random HMAC key is
    # deliberately not exported, so exported pseudonyms are not reversible.
    firefly_export = {
        "mode": "LOCAL_SYNTHETIC_PRIVACY_MINIMISED_AGGREGATES",
        "raw_subject_identifiers_exported": False,
        "transaction_records_retained": False,
        "purpose": "benchmark replay and aggregate verification",
        "external_transfer": False,
        "aggregate_count": len(firefly_memory),
        "aggregates": firefly_memory,
    }
    write_json(EXPORTS / "firefly_memory.json", firefly_export)

    result = {
        "operation_id": "SWI-FIREFLY-FULL-REPLAY-001",
        "timestamp_utc": utc(),
        "dataset": "synthetic_generated_stream",
        "requested_transactions": count,
        "processed_transactions": processed,
        "sequence_gaps_or_order_errors": 0,
        "balance_mismatches": mismatches,
        "account_states_reconstructed": len(balances),
        "firefly_aggregate_subjects": len(firefly_memory),
        "raw_subject_identifiers_exported": False,
        "transaction_level_records_exported": False,
        "external_transfer": False,
        "elapsed_seconds": seconds,
        "transactions_per_second": rate,
        "tracemalloc_current_bytes": current_bytes,
        "tracemalloc_peak_bytes": peak_bytes,
        "replay_chain_sha256": previous_hash,
        "target_transactions": 3500000000,
        "target_seconds": 1.2,
        "target_required_transactions_per_second": 3500000000 / 1.2,
        "target_3_5B_1_2s_tested": False,
        "full_target_proven": False,
        "independent_reproduction": "NOT_ESTABLISHED",
        "production_authorization": "NOT_GRANTED",
        "limitations": [
            "Synthetic data only.",
            "This is a local benchmark, not a production deployment.",
            "tracemalloc measures Python allocations, not total device RAM.",
            "No independent machine reproduction has been performed.",
            "A smaller replay does not prove the 3.5-billion target.",
            "This Firefly demonstration is not a certified privacy system."
        ]
    }
    return result

def self_test():
    # Independent small deterministic runs must produce the same replay hash.
    a = replay(1000, 100, 12345)
    b = replay(1000, 100, 12345)
    assert a["processed_transactions"] == 1000
    assert a["balance_mismatches"] == 0
    assert a["replay_chain_sha256"] == b["replay_chain_sha256"]
    assert a["raw_subject_identifiers_exported"] is False
    assert a["external_transfer"] is False
    return {
        "self_test": "PASS",
        "tests": [
            "deterministic_replay_hash",
            "transaction_accounting",
            "balance_reconstruction",
            "privacy_export_boundary",
            "no_external_transfer"
        ],
        "test_count": 5,
        "production_authorization": "NOT_GRANTED"
    }

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--transactions", type=int, default=100000)
    parser.add_argument("--subjects", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20261105)
    args = parser.parse_args()

    if args.transactions < 1 or args.subjects < 1:
        raise SystemExit("Transactions and subjects must be positive.")

    environment = {
        "timestamp_utc": utc(),
        "python": sys.version,
        "platform": platform.platform(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "cpu_count_reported": os.cpu_count(),
        "transaction_count": args.transactions,
        "subject_count": args.subjects,
        "seed": args.seed,
        "data_source": "synthetic",
    }
    write_json(EVIDENCE / "environment.json", environment)

    tests = self_test()
    write_json(EVIDENCE / "self_test.json", tests)

    result = replay(args.transactions, args.subjects, args.seed)
    result["self_test_status"] = tests["self_test"]
    result["overall_replay_status"] = (
        "PASS"
        if result["processed_transactions"] == args.transactions
        and result["balance_mismatches"] == 0
        else "FAIL"
    )
    write_json(EVIDENCE / "replay_report.json", result)

    with (EXPORTS / "replay_summary.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(result.keys()))
        writer.writeheader()
        writer.writerow(result)

    spec = {
        "operation_id": "SWI-FIREFLY-FULL-REPLAY-001",
        "purpose": "Reproducible synthetic replay and privacy-memory benchmark",
        "target": {"transactions": 3500000000, "seconds": 1.2},
        "required_rate_per_second": 3500000000 / 1.2,
        "acceptance": [
            "Every input transaction accounted for",
            "No sequence gaps or duplicates",
            "All reconstructed balances match reference values",
            "Replay hash recorded",
            "Firefly export contains aggregates rather than raw subject IDs",
            "Runtime and memory measurements recorded",
            "Independent reproduction required before a proof claim"
        ],
        "status": "SPECIFICATION_CREATED_BENCHMARK_LIMITED_TO_REQUESTED_RUN"
    }
    write_json(EVIDENCE / "benchmark_specification.json", spec)

    readme = """# SWI Firefly Replay Benchmark

Run:
    python swi_firefly.py --transactions 100000 --subjects 10000

Outputs:
- evidence/environment.json
- evidence/self_test.json
- evidence/replay_report.json
- evidence/benchmark_specification.json
- exports/firefly_memory.json
- exports/replay_summary.csv

Synthetic data only. This is not a production-authorized system.
A successful small replay does not prove 3.5 billion transactions in 1.2 seconds.
"""
    (ROOT / "README.md").write_text(readme)

    # Hash the generated evidence and exports.
    manifest = {}
    for folder in (EVIDENCE, EXPORTS):
        for path in sorted(folder.glob("*")):
            if path.is_file() and path.name != "sha256_manifest.json":
                manifest[str(path.relative_to(ROOT))] = hashlib.sha256(
                    path.read_bytes()
                ).hexdigest()
    write_json(EVIDENCE / "sha256_manifest.json", manifest)

    archive = ROOT / "SWI_FIREFLY_REPLAY_EVIDENCE.zip"
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as z:
        for path in ROOT.rglob("*"):
            if path.is_file() and path != archive and "__pycache__" not in str(path):
                z.write(path, path.relative_to(ROOT))

    print(json.dumps({
        "self_test": tests["self_test"],
        "replay_status": result["overall_replay_status"],
        "processed": result["processed_transactions"],
        "seconds": result["elapsed_seconds"],
        "transactions_per_second": result["transactions_per_second"],
        "python_peak_memory_bytes": result["tracemalloc_peak_bytes"],
        "replay_sha256": result["replay_chain_sha256"],
        "target_3_5B_1_2s": "NOT_TESTED",
        "production_authorization": "NOT_GRANTED",
        "export_zip": str(archive)
    }, indent=2))

if __name__ == "__main__":
    main()
