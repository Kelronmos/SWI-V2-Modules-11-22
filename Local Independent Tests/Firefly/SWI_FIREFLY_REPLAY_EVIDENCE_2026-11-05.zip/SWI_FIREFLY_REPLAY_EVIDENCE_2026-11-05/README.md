# SWI Firefly Replay Benchmark

Run:
    python swi_firefly.py --transactions 100000 --subjects 10000

Outputs:
- evidence/environment.json
- evidence/self_test.json
- evidence/replay_report.json
- evidence/benchmark_specification.json
- exports/firefly_memory.json
- exports/replay_summary.csv

Synthetic data only. This is not a production-authorized system.
A successful small replay does not prove 3.5 billion transactions in 1.2 seconds.
