from pathlib import Path
import json, hashlib, subprocess, sys, datetime
ROOT=Path(__file__).resolve().parent
cmd=[sys.executable,"-m","pytest","-q","tests/test_camera_telemetry_gate.py"]
p=subprocess.run(cmd,cwd=ROOT,text=True,capture_output=True)
summary={"suite":"camera_telemetry_authority","command":" ".join(cmd),"return_code":p.returncode,
 "stdout":p.stdout,"stderr":p.stderr,"timestamp_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
 "scope":"isolated research harness; simulated protected action only; no physical hardware or live sensor connected",
 "development_history":["Initial run: 3 failed, 4 passed; exposed bytes-vs-Ed25519PublicKey handling and replay-test key conversion defects.","Corrections applied to public-key construction and replay-test serialization.",
 "Evidence enrichment briefly produced 7 failures because Result did not declare new telemetry metadata fields; dataclass schema was extended and full suite rerun.","Final run rerun from source after corrections."],
 "cases":[
  {"id":"T01","case":"fresh signed sensor telemetry","expected":"PASS"},
  {"id":"T02","case":"camera-only observation","expected":"UNKNOWN / no execution"},
  {"id":"T03","case":"mathematical explanation only","expected":"UNKNOWN / no execution"},
  {"id":"T04","case":"stale sensor telemetry","expected":"HALT / no execution"},
  {"id":"T05","case":"wrong sensor identity","expected":"HALT / no execution"},
  {"id":"T06","case":"tampered telemetry signature","expected":"HALT / no execution"},
  {"id":"T07","case":"identical input replay","expected":"same decision and evidence hash"}
 ]}
(ROOT/"evidence/test_run.json").write_text(json.dumps(summary,indent=2)+"\n")
md="# Camera / Physical Telemetry Authority — Test Run\n\n"
md+=f"- Timestamp (UTC): {summary['timestamp_utc']}\n- Command: `{summary['command']}`\n- Exit code: `{p.returncode}`\n- Scope: {summary['scope']}\n\n## Result\n\n```text\n{p.stdout}{p.stderr}```\n\n## Scenarios\n\n"
for c in summary['cases']: md+=f"- **{c['id']}** — {c['case']}: expected {c['expected']}\n"
md+="\n## Development history\n\n- Initial run: 3 failed, 4 passed; exposed two test-harness defects.\n- Corrected public-key construction and replay-test key serialization.\n- Evidence enrichment briefly caused 7 failures due to missing Result metadata fields; the schema was extended.\n- Re-ran the full test file after corrections.\n\n## Limitations\n\nThis run validates a standalone Python policy harness, not the repository's production SWI gate. The Ed25519 key is test-generated; no real sensor, calibration authority, hardware attestation, trusted clock, network transport, actuator, or human authorization service is connected. No production authorization, sealing, or conformity claim is made.\n"
(ROOT/"evidence/TEST_REPORT.md").write_text(md)
# Hash a stable manifest of the source, tests, and evidence outputs.
files=[ROOT/"README.md",ROOT/"requirements.txt",ROOT/"camera_telemetry_gate.py",ROOT/"tests/test_camera_telemetry_gate.py",ROOT/"run_tests.py",ROOT/"evidence/test_run.json",ROOT/"evidence/TEST_REPORT.md"]
lines=[]
for f in files: lines.append(f"{hashlib.sha256(f.read_bytes()).hexdigest()}  {f.relative_to(ROOT)}")
(ROOT/"evidence/SHA256SUMS").write_text("\n".join(lines)+"\n")
print(p.stdout,end="")
print(p.stderr,end="",file=sys.stderr)
print(f"REPORT={ROOT/'evidence/TEST_REPORT.md'}")
print(f"JSON={ROOT/'evidence/test_run.json'}")
print(f"SHA256={ROOT/'evidence/SHA256SUMS'}")
sys.exit(p.returncode)
