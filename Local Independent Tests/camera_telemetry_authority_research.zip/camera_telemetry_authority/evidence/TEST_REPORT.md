# Camera / Physical Telemetry Authority — Test Run

- Timestamp (UTC): 2026-11-04T19:23:26.897797+00:00
- Command: `/opt/pyvenv/bin/python -m pytest -q tests/test_camera_telemetry_gate.py`
- Exit code: `0`
- Scope: isolated research harness; simulated protected action only; no physical hardware or live sensor connected

## Result

```text
.......                                                                  [100%]
7 passed in 0.07s
```

## Scenarios

- **T01** — fresh signed sensor telemetry: expected PASS
- **T02** — camera-only observation: expected UNKNOWN / no execution
- **T03** — mathematical explanation only: expected UNKNOWN / no execution
- **T04** — stale sensor telemetry: expected HALT / no execution
- **T05** — wrong sensor identity: expected HALT / no execution
- **T06** — tampered telemetry signature: expected HALT / no execution
- **T07** — identical input replay: expected same decision and evidence hash

## Development history

- Initial run: 3 failed, 4 passed; exposed two test-harness defects.
- Corrected public-key construction and replay-test key serialization.
- Evidence enrichment briefly caused 7 failures due to missing Result metadata fields; the schema was extended.
- Re-ran the full test file after corrections.

## Limitations

This run validates a standalone Python policy harness, not the repository's production SWI gate. The Ed25519 key is test-generated; no real sensor, calibration authority, hardware attestation, trusted clock, network transport, actuator, or human authorization service is connected. No production authorization, sealing, or conformity claim is made.
