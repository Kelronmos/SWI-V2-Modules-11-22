# SWI Camera / Physical Telemetry Authority — Research Harness

**Status:** isolated research experiment; not integrated into SWI's production authorization spine.

## Purpose

Test the boundary between (1) camera observations, (2) mathematical/model explanations, and (3) authenticated physical telemetry. A physical-action request fails closed unless a fresh telemetry record is signed by the configured trusted test key and matches the expected sensor/device identity.

## Run

```bash
python -m pip install -r requirements.txt
python run_tests.py
```

## Test scenarios

1. Fresh signed telemetry — PASS (test-only simulated action counter increments).
2. Camera-only observation — UNKNOWN; no action.
3. Camera observation plus mathematical explanation — UNKNOWN; no action.
4. Stale telemetry — HALT; no action.
5. Wrong sensor identity — HALT; no action.
6. Altered telemetry with original signature — HALT; no action.
7. Identical input replay — identical decision and evidence hash.

## Evidence

- `evidence/TEST_REPORT.md` — human-readable run report.
- `evidence/test_run.json` — machine-readable run record.
- `evidence/SHA256SUMS` — SHA-256 manifest.

## Limitations

The tests use generated Ed25519 test keys and a simulated protected-action counter. They do not connect to a real camera, sensor, calibration authority, hardware attestation service, trusted clock, network transport, human authority service, or actuator. A valid signature proves only that the test record was signed by the corresponding test key; it does not prove the sensor is physically genuine or correctly calibrated. This is not a test of the production SWI execution gate and does not establish PROVEN, SEALED, PRODUCTION_AUTHORIZED, ISO conformity, or safety certification.
