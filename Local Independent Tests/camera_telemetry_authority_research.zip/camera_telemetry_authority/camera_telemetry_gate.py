"""Research harness: separate camera/model claims from authenticated telemetry.

This is an isolated test harness, NOT a production actuator or replacement SWI gate.
It demonstrates a fail-closed policy for physical actions.
"""
from __future__ import annotations
import base64, hashlib, json, math, time
from dataclasses import dataclass
from enum import Enum
from typing import Optional
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

class Decision(str, Enum):
    PASS = "PASS"
    UNKNOWN = "UNKNOWN"
    HALT = "HALT"

@dataclass(frozen=True)
class Telemetry:
    sensor_id: str
    device_id: str
    measurement: str
    value: float
    unit: str
    observed_at: float
    calibration_id: str
    signature_b64: str
    def payload(self) -> bytes:
        obj = {"sensor_id":self.sensor_id,"device_id":self.device_id,"measurement":self.measurement,
               "value":self.value,"unit":self.unit,"observed_at":self.observed_at,
               "calibration_id":self.calibration_id}
        return json.dumps(obj, sort_keys=True, separators=(",",":"), allow_nan=False).encode()

@dataclass(frozen=True)
class Case:
    name: str
    visual_observation: Optional[str] = None
    model_explanation: Optional[str] = None
    telemetry: Optional[Telemetry] = None

@dataclass
class Result:
    case: str
    decision: str
    reason: str
    execution_allowed: bool
    execution_occurred: bool
    observation_present: bool
    model_explanation_present: bool
    telemetry_verified: bool
    telemetry_payload_sha256: Optional[str] = None
    sensor_id: Optional[str] = None
    device_id: Optional[str] = None
    measurement: Optional[str] = None
    observed_at: Optional[float] = None
    calibration_id: Optional[str] = None
    evidence_hash: str = ""

class PhysicalActionGate:
    def __init__(self, *, trusted_public_key: bytes, expected_sensor_id: str,
                 expected_device_id: str, now: float, max_age_seconds: float = 5.0):
        self.public_key = Ed25519PublicKey.from_public_bytes(trusted_public_key)
        self.sensor_id = expected_sensor_id
        self.device_id = expected_device_id
        self.now = now
        self.max_age = max_age_seconds
        self.execution_counter = 0

    def evaluate(self, case: Case) -> Result:
        t = case.telemetry
        verified = False
        if t is None:
            decision, reason = Decision.UNKNOWN, "PHYSICAL_TELEMETRY_MISSING"
        elif t.sensor_id != self.sensor_id or t.device_id != self.device_id:
            decision, reason = Decision.HALT, "SENSOR_OR_DEVICE_ID_MISMATCH"
        elif not all([t.measurement, t.unit, t.calibration_id]) or not math.isfinite(float(t.value)):
            decision, reason = Decision.HALT, "TELEMETRY_FIELDS_INVALID"
        elif t.observed_at > self.now or self.now - t.observed_at > self.max_age:
            decision, reason = Decision.HALT, "TELEMETRY_STALE_OR_FUTURE"
        else:
            try:
                self.public_key.verify(base64.b64decode(t.signature_b64, validate=True), t.payload())
                verified = True
                decision, reason = Decision.PASS, "SIGNED_FRESH_TELEMETRY_VERIFIED"
            except (ValueError, TypeError, InvalidSignature):
                decision, reason = Decision.HALT, "TELEMETRY_SIGNATURE_INVALID"
        allowed = decision == Decision.PASS and verified
        if allowed:
            self.execution_counter += 1  # test-only simulated protected action
        telemetry_digest = hashlib.sha256(t.payload()).hexdigest() if t is not None else None
        record = {
            "case":case.name,"decision":decision.value,"reason":reason,
            "execution_allowed":allowed,"execution_occurred":allowed,
            "observation_present":case.visual_observation is not None,
            "model_explanation_present":case.model_explanation is not None,
            "telemetry_verified":verified,
            "telemetry_payload_sha256":telemetry_digest,
            "sensor_id":t.sensor_id if t is not None else None,
            "device_id":t.device_id if t is not None else None,
            "measurement":t.measurement if t is not None else None,
            "observed_at":t.observed_at if t is not None else None,
            "calibration_id":t.calibration_id if t is not None else None,
        }
        digest = hashlib.sha256(json.dumps(record, sort_keys=True, separators=(",",":")).encode()).hexdigest()
        return Result(**record, evidence_hash=digest)

def sign_telemetry(private_key, *, sensor_id="MAG-01", device_id="RIG-01", value=0.42, observed_at=1000.0):
    # Build a temporary record to produce the exact canonical payload.
    unsigned = Telemetry(sensor_id, device_id, "magnetic_field", value, "mT", observed_at, "CAL-2026-04", "")
    sig = base64.b64encode(private_key.sign(unsigned.payload())).decode()
    return Telemetry(sensor_id, device_id, "magnetic_field", value, "mT", observed_at, "CAL-2026-04", sig)
