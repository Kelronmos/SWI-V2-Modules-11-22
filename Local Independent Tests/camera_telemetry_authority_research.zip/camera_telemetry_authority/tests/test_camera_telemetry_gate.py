import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization
from camera_telemetry_gate import Case, PhysicalActionGate, sign_telemetry, Telemetry

NOW = 1000.0

def gate_and_key():
    private = Ed25519PrivateKey.generate()
    public = private.public_key().public_bytes(encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw)
    return private, PhysicalActionGate(trusted_public_key=public, expected_sensor_id="MAG-01",
        expected_device_id="RIG-01", now=NOW)

def test_01_fresh_signed_sensor_telemetry_passes():
    private, gate = gate_and_key()
    r = gate.evaluate(Case("fresh_signed_telemetry", telemetry=sign_telemetry(private)))
    assert r.decision == "PASS" and r.execution_allowed and r.execution_occurred
    assert gate.execution_counter == 1 and r.telemetry_verified

def test_02_camera_only_observation_is_not_telemetry():
    _, gate = gate_and_key()
    r = gate.evaluate(Case("camera_only", visual_observation="ring appears suspended"))
    assert r.decision == "UNKNOWN" and not r.execution_allowed and not r.execution_occurred
    assert r.reason == "PHYSICAL_TELEMETRY_MISSING" and gate.execution_counter == 0

def test_03_mathematical_explanation_is_not_telemetry():
    _, gate = gate_and_key()
    r = gate.evaluate(Case("model_only", visual_observation="ring appears suspended", model_explanation="magnetic force may balance gravity"))
    assert r.decision == "UNKNOWN" and not r.execution_allowed
    assert r.reason == "PHYSICAL_TELEMETRY_MISSING" and gate.execution_counter == 0

def test_04_stale_sensor_telemetry_halts():
    private, gate = gate_and_key()
    stale = sign_telemetry(private, observed_at=900.0)
    r = gate.evaluate(Case("stale_telemetry", telemetry=stale))
    assert r.decision == "HALT" and not r.execution_allowed and not r.execution_occurred
    assert r.reason == "TELEMETRY_STALE_OR_FUTURE" and gate.execution_counter == 0

def test_05_wrong_sensor_identity_halts():
    private, gate = gate_and_key()
    wrong = sign_telemetry(private, sensor_id="UNTRUSTED-SENSOR")
    r = gate.evaluate(Case("wrong_sensor", telemetry=wrong))
    assert r.decision == "HALT" and not r.execution_allowed and not r.execution_occurred
    assert r.reason == "SENSOR_OR_DEVICE_ID_MISMATCH" and gate.execution_counter == 0

def test_06_signature_tampering_halts():
    private, gate = gate_and_key()
    good = sign_telemetry(private)
    tampered = Telemetry(good.sensor_id, good.device_id, good.measurement, 999.0,
        good.unit, good.observed_at, good.calibration_id, good.signature_b64)
    r = gate.evaluate(Case("tampered_telemetry", telemetry=tampered))
    assert r.decision == "HALT" and not r.execution_allowed and gate.execution_counter == 0
    assert r.reason == "TELEMETRY_SIGNATURE_INVALID"

def test_07_identical_replay_is_decision_deterministic():
    private, gate = gate_and_key()
    case = Case("replay", visual_observation="object suspended", telemetry=sign_telemetry(private))
    a = gate.evaluate(case)
    # A fresh gate with identical trusted inputs and clock gives the same record/hash.
    from cryptography.hazmat.primitives import serialization
    pub = gate.public_key.public_bytes(encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw)
    _, gate2 = gate_and_key_with_public(pub, gate.sensor_id, gate.device_id)
    b = gate2.evaluate(case)
    assert (a.decision, a.reason, a.evidence_hash) == (b.decision, b.reason, b.evidence_hash)

def gate_and_key_with_public(public, sensor, device):
    from camera_telemetry_gate import PhysicalActionGate
    return None, PhysicalActionGate(trusted_public_key=public, expected_sensor_id=sensor,
        expected_device_id=device, now=NOW)
