# SWI Reporting Independent — Prototype 0.1.0

**Classification:** Independent development prototype. **SWI V2 integration:** NOT ESTABLISHED. **Production authorization:** NOT AUTHORIZED.

This is a downstream reporting demonstration, not SWI V2 and not an authorization engine. Python creates one canonical run record and generates PDF, Markdown, JSON and XLSX outputs. The Node/Vite dashboard reads that record and displays its supplied statuses. It does not calculate or grant authorization. Firefly prompts are optional decorative assets only.

## Status boundaries

`UNKNOWN`, `NOT_ESTABLISHED`, `INVALID`, `PASS`, `FAIL`, `NOT_RUN` and `SKIPPED` are distinct. Missing data is never converted to PASS. The prototype enforces `PROVEN=NO`, `SEALED=NO`, `PRODUCTION_AUTHORIZED=NO`.

Hashes identify bytes; they do not prove that the contents are true. Runtime and hardware observations are informational, not trusted identity or attestation. Synthetic records are not execution evidence.

## Requirements

Python 3.10+; Node.js 20+ and npm. Python dependencies are in `requirements.txt`.

## Python build

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
python -m pip install -r requirements.txt
python -m pytest tests -v
python -m python.swi_reporting.runner --output reports/generated
```

The default run is explicitly labelled `SYNTHETIC_TEST_DATA`. To validate and report an existing canonical JSON record:

```bash
python -m python.swi_reporting.runner --input path/to/run_record.json --output reports/generated
```

Outputs: `run_record.json`, `report.pdf`, `report.md`, `report.xlsx`, `REPORT_MANIFEST.json`.

## Node dashboard

```bash
mkdir -p web/dashboard/public/reports
cp reports/generated/run_record.json web/dashboard/public/reports/run_record.json
cd web/dashboard
npm install
npm test
npm run build
npm run dev
```

PowerShell equivalent for copying: `New-Item -ItemType Directory -Force public/reports` then `Copy-Item ../../reports/generated/run_record.json public/reports/run_record.json`.

## Scope and limitations

No remote repository was fetched or modified. No SWI V2 checkout was inspected. The prototype does not contain or replace the SWI governing spine, does not perform SWI authorization, and is not production-ready. The Node build and Python tests must be run in the recipient's environment before any build/test claim is made.
