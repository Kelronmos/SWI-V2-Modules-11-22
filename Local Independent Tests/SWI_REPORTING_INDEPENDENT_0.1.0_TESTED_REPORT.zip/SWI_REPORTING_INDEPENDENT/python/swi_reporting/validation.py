import json
from pathlib import Path
from jsonschema import Draft202012Validator
SCHEMA = Path(__file__).resolve().parents[2] / 'schemas' / 'run_record.schema.json'

def validate_record(record, schema_path=SCHEMA):
    schema = json.loads(Path(schema_path).read_text(encoding='utf-8'))
    errors = sorted(Draft202012Validator(schema).iter_errors(record), key=lambda e: list(e.path))
    if errors:
        raise ValueError('Run record schema validation failed: ' + '; '.join(f'{list(e.path)}: {e.message}' for e in errors))
    auth = record.get('authorization', {})
    for key in ('proven', 'sealed', 'production_authorized'):
        if auth.get(key) != 'NO':
            raise ValueError(f'Authorization ceiling violated: {key} must remain NO')
