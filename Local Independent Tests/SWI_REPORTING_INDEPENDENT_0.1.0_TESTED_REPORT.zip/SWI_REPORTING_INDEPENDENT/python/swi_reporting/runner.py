import argparse, json
from pathlib import Path
from datetime import datetime, timezone
from .records import make_synthetic_record
from .validation import validate_record
from .integrity import sha256_file
from .generators import markdown, json_report, excel, pdf, html_report

def main():
    p=argparse.ArgumentParser(description='Independent SWI reporting prototype')
    p.add_argument('--input', help='Existing canonical run record JSON')
    p.add_argument('--output', default='reports/generated')
    a=p.parse_args(); out=Path(a.output); out.mkdir(parents=True,exist_ok=True)
    record=json.loads(Path(a.input).read_text(encoding='utf-8')) if a.input else make_synthetic_record()
    validate_record(record)
    generators={'run_record.json':lambda p:json_report.generate(record,p),'report.md':lambda p:markdown.generate(record,p),'report.pdf':lambda p:pdf.generate(record,p),'report.xlsx':lambda p:excel.generate(record,p),'report.html':lambda p:html_report.generate(record,p)}
    for name, fn in generators.items(): fn(out/name)
    manifest={'manifest_version':'1.0.0','created_at':datetime.now(timezone.utc).isoformat(),'run_id':record['run_id'],'source_record':'run_record.json','artifacts':[{'path':n,'sha256':sha256_file(out/n)} for n in generators],'status':'GENERATED_NOT_AUTHORIZED','authorization':{'proven':'NO','sealed':'NO','production_authorized':'NO'},'note':'Hashes identify bytes; they do not prove truth.'}
    (out/'REPORT_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    print(f"Generated independent reports for {record['run_id']} in {out}")
    print('PROVEN=NO SEALED=NO PRODUCTION_AUTHORIZED=NO')
if __name__=='__main__': main()
