from datetime import datetime, timezone
from uuid import uuid4
from .observations import collect_observations

def make_synthetic_record():
    return {
        "schema_version": "1.0.0", "run_id": "SYNTHETIC-" + uuid4().hex[:12].upper(),
        "record_classification": "SYNTHETIC_TEST_DATA", "created_at": datetime.now(timezone.utc).isoformat(),
        "repository": {"name": "SWI_REPORTING_INDEPENDENT", "branch": "independent-prototype", "commit_sha": None, "integration_status": "NOT_ESTABLISHED"},
        "execution": {"status": "NOT_EXECUTED", "command": None, "exit_code": None, "observations": collect_observations()},
        "tests": [
            {"id": "DEMO-001", "name": "Synthetic schema fixture", "status": "PASS", "evidence_ref": "synthetic://DEMO-001"},
            {"id": "DEMO-002", "name": "Live SWI governing integration", "status": "UNKNOWN", "evidence_ref": None}
        ],
        "evidence": [],
        "claims": [{"claim_id": "REPORTING-001", "claim": "Independent reporting prototype generated this record", "status": "NOT_ESTABLISHED", "reason": "Synthetic demonstration record."}],
        "authorization": {"status": "NOT_AUTHORIZED", "authority_source": "NONE", "note": "Reporting cannot grant SWI authorization.", "proven": "NO", "sealed": "NO", "production_authorized": "NO"},
        "limitations": ["Synthetic data; not evidence of SWI V2 execution.", "No live repository checkout was inspected.", "No SWI governing authorization decision was made."]
    }
