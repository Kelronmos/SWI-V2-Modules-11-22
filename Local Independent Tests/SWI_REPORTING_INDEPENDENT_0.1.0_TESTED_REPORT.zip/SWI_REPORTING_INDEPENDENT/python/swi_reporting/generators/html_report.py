import json
from html import escape

def generate(record: dict, path) -> None:
    # Escape less-than signs so untrusted values cannot terminate the JSON script element.
    payload = json.dumps(record, ensure_ascii=False).replace("<", "\\u003c").replace(">", "\\u003e").replace("&", "\\u0026")
    title = escape(str(record.get("run_id", "Run report")))
    document = f'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>SWI report — {title}</title>
<style>body{{font:16px system-ui;max-width:960px;margin:2rem auto;padding:0 1rem;color:#1d2933;background:#f4f6f8}}
section{{background:white;padding:1rem 1.25rem;margin:1rem 0;border:1px solid #d9e0e5;border-radius:8px}}
.badge{{font-weight:700}}table{{border-collapse:collapse;width:100%}}td,th{{padding:.6rem;border-bottom:1px solid #ddd;text-align:left}}
input{{padding:.6rem;max-width:100%;width:24rem}}.ceiling{{font-weight:700}}</style></head>
<body><header><p>INDEPENDENT REPORTING PROTOTYPE · NOT SWI V2 MAIN</p><h1>Run report</h1><p id="run"></p></header>
<section><h2>Run overview</h2><dl id="overview"></dl></section>
<section><h2>Tests</h2><label>Filter tests <input id="filter" type="search" placeholder="Filter by name or status"></label>
<table><thead><tr><th>ID</th><th>Test</th><th>Status</th><th>Evidence</th></tr></thead><tbody id="tests"></tbody></table></section>
<section><h2>Authorization boundary</h2><p id="auth"></p><p class="ceiling">PROVEN=NO · SEALED=NO · PRODUCTION_AUTHORIZED=NO</p></section>
<section><h2>Limitations</h2><ul id="limits"></ul></section>
<script type="application/json" id="record">{payload}</script>
<script>const r=JSON.parse(document.getElementById('record').textContent);
const el=(tag,text)=>{{const n=document.createElement(tag);n.textContent=String(text??'UNKNOWN');return n;}};
document.getElementById('run').textContent=r.run_id+' · '+r.record_classification;
const ov=document.getElementById('overview');for(const [k,v] of [['Repository',r.repository.name],['Branch',r.repository.branch],['Commit',r.repository.commit_sha??'NOT_ESTABLISHED'],['Integration',r.repository.integration_status],['Created',r.created_at]]){{ov.append(el('dt',k),el('dd',v));}}
const tbody=document.getElementById('tests');function render(q=''){{tbody.replaceChildren();for(const t of r.tests??[]){{if(!(`${{t.id}} ${{t.name}} ${{t.status}}`.toLowerCase().includes(q)))continue;const tr=document.createElement('tr');for(const v of [t.id,t.name,t.status,t.evidence_ref??'NOT_ESTABLISHED'])tr.append(el('td',v));tbody.append(tr);}}}}
render();document.getElementById('filter').addEventListener('input',e=>render(e.target.value.toLowerCase()));
document.getElementById('auth').textContent='Supplied status: '+r.authorization.status+'. This report does not grant authorization.';
for(const x of r.limitations??[])document.getElementById('limits').append(el('li',x));</script></body></html>'''
    path.write_text(document, encoding="utf-8")
