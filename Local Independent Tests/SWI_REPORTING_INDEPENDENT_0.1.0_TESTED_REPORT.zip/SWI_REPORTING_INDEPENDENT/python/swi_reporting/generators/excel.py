from openpyxl import Workbook
from openpyxl.styles import Font

def generate(record, path):
    wb = Workbook(); ws = wb.active; ws.title = 'Run Summary'
    rows = [('Field','Value'),('Run ID',record['run_id']),('Classification',record['record_classification']),('Created',record['created_at']),('Repository',record['repository']['name']),('Integration',record['repository']['integration_status']),('Authorization',record['authorization']['status']),('PROVEN','NO'),('SEALED','NO'),('PRODUCTION_AUTHORIZED','NO')]
    for row in rows: ws.append(row)
    for c in ws[1]: c.font = Font(bold=True)
    ts = wb.create_sheet('Tests'); ts.append(['ID','Name','Status','Evidence reference'])
    for t in record['tests']: ts.append([t['id'],t['name'],t['status'],t.get('evidence_ref')])
    for sh in wb.worksheets:
        sh.freeze_panes = 'A2'; sh.column_dimensions['A'].width = 28; sh.column_dimensions['B'].width = 55; sh.column_dimensions['C'].width = 24; sh.column_dimensions['D'].width = 42
    wb.save(path)
