from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors

def generate(record, path):
    styles = getSampleStyleSheet(); doc = SimpleDocTemplate(str(path), pagesize=A4, title=f"SWI Reporting {record['run_id']}")
    story = [Paragraph('SWI Reporting Run', styles['Title']), Paragraph(record['run_id'], styles['Heading2']), Paragraph(f"Classification: {record['record_classification']}", styles['BodyText']), Paragraph(f"Created: {record['created_at']}", styles['BodyText']), Spacer(1,12), Paragraph('Test Results', styles['Heading1'])]
    data = [['ID','Test','Status']] + [[t['id'],t['name'],t['status']] for t in record['tests']]
    table = Table(data, repeatRows=1, colWidths=[75,330,75])
    table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#263746')),('TEXTCOLOR',(0,0),(-1,0),colors.white),('GRID',(0,0),(-1,-1),0.5,colors.grey),('VALIGN',(0,0),(-1,-1),'TOP')]))
    story += [table, Spacer(1,14), Paragraph('Authorization boundary',styles['Heading1']), Paragraph('PROVEN=NO | SEALED=NO | PRODUCTION_AUTHORIZED=NO',styles['BodyText']), Paragraph('This reporting prototype cannot grant SWI authorization.',styles['BodyText']), Paragraph('Limitations',styles['Heading1'])]
    story += [Paragraph('• ' + x, styles['BodyText']) for x in record.get('limitations',[])]
    doc.build(story)
