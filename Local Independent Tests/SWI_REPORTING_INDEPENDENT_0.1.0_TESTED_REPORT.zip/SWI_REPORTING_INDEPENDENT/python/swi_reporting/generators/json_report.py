import json
from pathlib import Path

def generate(record, path):
    Path(path).write_text(json.dumps(record, indent=2, sort_keys=True) + '\n', encoding='utf-8')
