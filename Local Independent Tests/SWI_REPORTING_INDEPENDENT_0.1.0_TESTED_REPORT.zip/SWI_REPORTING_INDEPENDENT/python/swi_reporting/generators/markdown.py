def generate(record, path):
    lines = [f"# SWI Reporting Run — {record['run_id']}", '', f"- Classification: **{record['record_classification']}**", f"- Created: {record['created_at']}", f"- Repository: {record['repository']['name']}", f"- Integration: **{record['repository']['integration_status']}**", '', '## Tests', '', '| ID | Test | Status | Evidence reference |', '|---|---|---|---|']
    for t in record['tests']:
        lines.append(f"| {t['id']} | {t['name']} | {t['status']} | {t.get('evidence_ref') or 'NOT_ESTABLISHED'} |")
    lines += ['', '## Authorization', '', f"- Status: **{record['authorization']['status']}**", '- PROVEN: NO', '- SEALED: NO', '- PRODUCTION_AUTHORIZED: NO', '', '## Limitations', '']
    lines += [f'- {x}' for x in record.get('limitations', [])]
    Path = __import__('pathlib').Path
    Path(path).write_text('\n'.join(lines) + '\n', encoding='utf-8')
