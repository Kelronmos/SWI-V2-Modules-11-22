# Optional Firefly assets

Prompt templates only; no generated artwork is included. Assets are decorative only and never evidence, identity, trust, certification, authorization or proof of execution. Review assets before use and calculate SHA-256 only after the actual file exists.
