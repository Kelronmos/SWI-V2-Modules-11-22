# SWI Reporting Run — SYNTHETIC-170E92A967CC

- Classification: **SYNTHETIC_TEST_DATA**
- Created: 2026-11-01T20:00:48.354946+00:00
- Repository: SWI_REPORTING_INDEPENDENT
- Integration: **NOT_ESTABLISHED**

## Tests

| ID | Test | Status | Evidence reference |
|---|---|---|---|
| DEMO-001 | Synthetic schema fixture | PASS | synthetic://DEMO-001 |
| DEMO-002 | Live SWI governing integration | UNKNOWN | NOT_ESTABLISHED |

## Authorization

- Status: **NOT_AUTHORIZED**
- PROVEN: NO
- SEALED: NO
- PRODUCTION_AUTHORIZED: NO

## Limitations

- Synthetic data; not evidence of SWI V2 execution.
- No live repository checkout was inspected.
- No SWI governing authorization decision was made.
