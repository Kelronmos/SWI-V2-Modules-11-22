import './style.css';
import {loadReport} from './report-loader.js';
import {renderRecord} from './status-view.js';
try { renderRecord(await loadReport()); }
catch(error) { document.querySelector('#classification').textContent=`Unable to load report: ${error.message}`; }
