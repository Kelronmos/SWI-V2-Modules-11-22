export async function loadReport(url='/reports/run_record.json') {
  const response=await fetch(url,{headers:{Accept:'application/json'}});
  if(!response.ok) throw new Error(`Report load failed: HTTP ${response.status}`);
  const record=await response.json();
  if(!record || typeof record!=='object' || !record.run_id || !record.authorization) throw new Error('Invalid or incomplete run record');
  return record;
}
