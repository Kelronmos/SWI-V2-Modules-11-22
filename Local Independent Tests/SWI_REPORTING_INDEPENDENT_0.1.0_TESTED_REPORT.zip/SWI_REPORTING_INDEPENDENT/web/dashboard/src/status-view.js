function el(tag,value){const n=document.createElement(tag);n.textContent=String(value ?? 'UNKNOWN');return n;}
export function renderRecord(record){
 document.querySelector('#classification').textContent=`${record.record_classification} · ${record.run_id}`;
 const overview=document.querySelector('#overview'); overview.replaceChildren();
 for(const [k,v] of [['Repository',record.repository?.name],['Branch',record.repository?.branch],['Commit',record.repository?.commit_sha ?? 'NOT_ESTABLISHED'],['Integration',record.repository?.integration_status],['Created',record.created_at]]) overview.append(el('dt',k),el('dd',v));
 const tests=document.querySelector('#tests'); tests.replaceChildren();
 for(const t of record.tests ?? []){const item=document.createElement('article');item.className='test-item';item.append(el('h3',t.name),el('p',`Status: ${t.status}`),el('p',`Evidence: ${t.evidence_ref ?? 'NOT_ESTABLISHED'}`));tests.append(item);}
 document.querySelector('#authorization').textContent=`Supplied status: ${record.authorization.status}. The dashboard does not calculate or grant authorization.`;
 const limits=document.querySelector('#limitations');limits.replaceChildren();for(const x of record.limitations ?? [])limits.append(el('li',x));
}
