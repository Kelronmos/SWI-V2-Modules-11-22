import test from 'node:test';
import assert from 'node:assert/strict';
test('status vocabulary preserves uncertainty',()=>{const allowed=['PASS','FAIL','UNKNOWN','NOT_RUN','SKIPPED'];assert.ok(allowed.includes('UNKNOWN'));assert.ok(allowed.includes('NOT_RUN'));assert.equal(allowed.includes('GREEN'),false);});
