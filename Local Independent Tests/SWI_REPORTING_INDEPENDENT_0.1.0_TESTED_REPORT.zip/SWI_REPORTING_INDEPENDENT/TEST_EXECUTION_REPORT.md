# SWI Reporting Independent — Local Test Execution Report

**Project:** SWI_REPORTING_INDEPENDENT  
**Version:** 0.1.0 (locally amended test package)  
**Classification:** Independent prototype; not integrated with SWI V2  
**Execution environment:** Linux x86_64 container  
**Python:** 3.13.5  
**Node.js:** v22.16.0  
**npm:** 10.9.2  

## Summary

Python syntax compilation passed. The final Python test suite passed **5/5**. The Python runner generated the canonical JSON run record and PDF, Markdown, XLSX and interactive HTML reports. Artifact hashes in the report manifest were independently recomputed and matched. The XLSX workbook opened with two sheets and the PDF parsed as a one-page document. The Node.js built-in test passed **1/1**.

The Vite production build was **not run** because `npm install --no-audit --no-fund` did not complete within the execution window, so Vite was not available locally. This is not a Vite build failure; it is an uncompleted dependency installation. No `package-lock.json` was generated.

## Test results

| Check | Result | Detail |
|---|---|---|
| Python syntax compilation | PASS | `python -m compileall -q python tests` |
| Python unit tests | PASS | 5 passed, 0 failed |
| Canonical record validation | PASS | Synthetic fixture accepted |
| Authorization ceiling | PASS | Attempt to set production authorization to YES rejected by schema |
| Unknown-state preservation | PASS | Unknown remains UNKNOWN; missing commit remains null |
| Invalid status rejection | PASS | Unrecognized GREEN test status rejected |
| HTML injection regression | PASS | Embedded record escapes `<`, and rendering uses `textContent` |
| Python report generation | PASS | JSON, MD, PDF, XLSX, HTML generated |
| Report manifest hashes | PASS | All 5 artifact SHA-256 values matched recomputation |
| XLSX structural check | PASS | `Run Summary`, `Tests` sheets readable |
| PDF structural check | PASS | 1 page parsed |
| Node.js tests | PASS | 1 passed, 0 failed |
| npm dependency installation | INCOMPLETE | Timed out in this environment |
| Vite production build | NOT RUN | Vite unavailable because dependency install did not complete |
| Browser interaction / live dashboard | NOT RUN | No Vite server/browser validation performed |
| Independent replay from clean checkout | NOT RUN | Not attempted |
| SWI V2 integration | NOT ESTABLISHED | No SWI V2 repository inspected or modified |

## Generated artifacts

The run record is explicitly classified `SYNTHETIC_TEST_DATA`. It does not represent a live SWI V2 run. Generated files:

- `reports/generated/run_record.json`
- `reports/generated/report.md`
- `reports/generated/report.pdf`
- `reports/generated/report.xlsx`
- `reports/generated/report.html`
- `reports/generated/REPORT_MANIFEST.json`

Run ID: `SYNTHETIC-170E92A967CC`

## Corrections made during testing

1. Corrected the authorization-ceiling test expectation to accept the schema validator's explicit rejection message. The schema rejects any value other than `NO` for `proven`, `sealed` and `production_authorized`.
2. Added a standalone interactive HTML report generator, because the initial runner generated only JSON, Markdown, PDF and XLSX. The HTML report embeds the same canonical record, escapes script-sensitive characters and renders record values through `textContent`.
3. Updated the report manifest to include all five generated output formats and verified each digest.

## Limitations and status

- This is an independent prototype only.
- Runtime and hardware values are local observations, not attestation or trusted identity.
- The run data is synthetic.
- Node/Vite dependency installation and production build remain outstanding.
- No live SWI V2 checkout, branch, HEAD or working tree was inspected.
- No SWI governing spine integration or authorization was performed.

```text
PROJECT=SWI_REPORTING_INDEPENDENT
INTEGRATION=NOT_ESTABLISHED
PYTHON_TESTS=PASS_5_OF_5
NODE_TESTS=PASS_1_OF_1
REPORT_GENERATION=PASS
VITE_BUILD=NOT_RUN
REPLAY_EVIDENCE=NOT_GENERATED
PROVEN=NO
SEALED=NO
PRODUCTION_AUTHORIZED=NO
```
