# Evidence Freshness Failure Investigation & Fix — 2026-10-02

## Scope

Investigated the full-suite failure:

`tests/law/test_evidence_freshness.py::test_evidence_source_tip_reachable_from_head`

## Observed failure

The uploaded SWI V2 source archive contains no `.git` directory. The test attempted:

`git rev-parse HEAD`

and therefore could not obtain repository HEAD or evaluate whether `evidence/law/manifest.json::source_tip` is equal to HEAD or an ancestor of HEAD.

This was an environment/repository-metadata limitation, not evidence that the source tip was stale or orphaned.

## Root cause

The freshness test correctly tests Git ancestry, but previously treated inability to access Git metadata as a test failure. A source archive cannot establish ancestry.

## Fix

Changed `_git_head()` in `tests/law/test_evidence_freshness.py` so that:

- a valid Git checkout continues to execute the existing HEAD/ancestor assertion;
- missing/unusable Git metadata produces `pytest.skip(...)` with an explicit `NOT TESTED` meaning;
- no evidence freshness PASS is manufactured;
- the independent authority/registry blob checks remain active.

No production authorization, evidence sealing, or claim escalation was added.

## Verification

### Full suite

`727 passed, 1 skipped`

The single skip is the Git-ancestry test because this uploaded source archive has no Git metadata.

### Evidence freshness tests

`1 passed, 1 skipped`

The passing test is the authority/registry blob-integrity check.

### Observation / claim / replay / interaction suites

`31 passed`

### Compilation

`python -m compileall -q swi_v2 tests test` — PASS

## Interpretation

The failure is fixed for source archives without weakening the actual Git freshness control. In a real Git checkout, the ancestry assertion still executes and can fail if the recorded source tip is stale or orphaned.

The skipped ancestry test is therefore **NOT TESTED**, not PASS.

## Limitations

- This uploaded archive contains no `.git`; current branch, HEAD, remote, and commit ancestry cannot be independently verified here.
- The manifest records historical law evidence at source tip `8245e3f03d8673c966abf9c63be9d838073159b0`; this run does not establish that it is an ancestor of any current remote HEAD.
- The README separately identifies V2 evidence tip `1d6d7dc`; this report does not reconcile historical evidence identity without Git history.

## Authorization boundary

`TESTED != PROVEN`

`PROVEN != SEALED`

`SEALED != PRODUCTION AUTHORIZED`

**PRODUCTION AUTHORIZATION: NOT GRANTED BY THIS TEST RUN.**
