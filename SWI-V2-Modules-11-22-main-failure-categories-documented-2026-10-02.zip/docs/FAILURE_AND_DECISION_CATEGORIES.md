# SWI Failure, Decision, and Terminal-State Categories

**Status:** Documentation baseline for V2 failure and evidence-boundary semantics.

This document defines how SWI distinguishes diagnostic errors, boundary decisions,
execution-blocking states, and unresolved evidence conditions.

## 1. Core rule

A category is not authority.

```text
ERROR / EXCEPTION
    ≠ REJECT
    ≠ HALT
    ≠ UNKNOWN
    ≠ ESCALATE
    ≠ EXECUTION_ALLOWED
```

Likewise:

```text
TESTED ≠ PROVEN
OBSERVED ≠ CLAIMED
PASS ≠ PROVEN
UNKNOWN ≠ PERMITTED
HALT ≠ ERROR
REJECT ≠ HALT
SKIP ≠ VERIFIED
```

A required control that cannot be evaluated must remain visible as an
unresolved condition. It must not be converted into a successful result by
silently skipping the control.

## 2. Categories

| Category | Meaning | Execution consequence | Typical next step |
|---|---|---|---|
| `ERROR` | Diagnostic/programmatic failure represented by an exception or error condition. | Depends on the surrounding boundary; an error does not itself grant execution. | Record, classify, and apply the boundary's fail-closed rule. |
| `INVALID_INPUT` | Input cannot satisfy the expected input contract. | No privileged execution from the invalid input. | Reject or return to validation. |
| `CONTRACT_FAILURE` | A declared module/kernel contract has been violated. | No execution across the violated boundary. | Reject, halt, or escalate according to the contract. |
| `INTEGRITY_FAILURE` | Required integrity/binding verification failed. | Execution blocked. | `HALT` → record → revalidate/retry or escalate where required. |
| `AUTHORITY_FAILURE` | Authority is absent, invalid, undeclared, or exceeds its permitted scope. | Execution blocked. | `HALT` when authority is required but missing/unknown; `REJECT` when scope/authority is invalid. |
| `CONSTRAINT_FAILURE` | A required constraint is not satisfied. | Execution blocked. | Revalidate, reject, or halt according to the boundary. |
| `EXECUTION_FAILURE` | An execution-stage operation failed after the relevant execution boundary was entered. | Execution did not complete successfully. | Record state and apply recovery/escalation rules. |
| `OUTPUT_FAILURE` | Required output/result contract was not satisfied. | Output must not be treated as valid evidence merely because execution occurred. | Record failure and revalidate/recover. |
| `STATE_FAILURE` | An invalid state transition was attempted. | Transition is blocked. | Correct/recover state; a halted workflow remains non-executable. |
| `REJECT` | Boundary decision that refuses the candidate/input/action under the applicable contract. | **No execution.** | Correct input/authority/binding and submit a new valid candidate. |
| `HALT` | Terminal execution-blocking decision for the current workflow/attempt. | **No execution.** | Record; explicit recovery/revalidation is required before another attempt. |
| `UNKNOWN` | Required information, authority, or evidence is insufficient to establish a permitted decision. | **No execution.** | Obtain the missing/valid evidence or authority, then revalidate. |
| `ESCALATE` | Current boundary cannot safely resolve the condition and requires escalation. | **No execution.** | Escalate to the defined authority/review path; escalation does not itself authorize execution. |
| `EXECUTION_ALLOWED` | All applicable execution bindings and authorization requirements have been satisfied for the specific action. | Execution may occur through the authorized path. | Record the execution and resulting evidence. |

## 3. `ERROR` is not automatically `HALT`

An exception such as `ModuleKernelError`, `ContractError`, `AuthorityError`,
`StateTransitionError`, or `AuthorityHalt` is an implementation-level signal.
The surrounding boundary determines the externally recorded decision.

In particular, `AuthorityHalt` represents an authority condition whose required
boundary outcome is `HALT`; a generic exception must not be interpreted as an
authorization decision by its existence alone.

## 4. `REJECT` versus `HALT`

### REJECT

`REJECT` means the presented candidate does not satisfy the relevant boundary
contract. Examples include malformed/invalid evidence, undeclared authority
fields, replayed evidence, or an action outside declared scope.

The rejected candidate does not become executable merely because a caller
catches the rejection.

### HALT

`HALT` means the current workflow/attempt is explicitly stopped at an
execution-blocking boundary. `HaltedWorkflow.may_execute()` is false, and the
execution-integrity path records `execution_allowed=False` and
`execution_occurred=False` for its demonstrated failure path.

A HALT is not an ordinary exception to suppress and continue.

## 5. `UNKNOWN` is a safety state, not a permission state

`UNKNOWN` means SWI cannot establish the conditions needed for a permitted
decision.

Examples:

- missing or invalid human authority;
- new information invalidating a prior decision;
- insufficient evidence-boundary information;
- inability to verify a required evidence condition.

Required rule:

```text
UNKNOWN → NO EXECUTION
```

`UNKNOWN` must not be coerced into `PASS`, `CONTINUE`, `EXECUTION_ALLOWED`, or
`PROVEN`.

## 6. `ESCALATE` is not authorization

Escalation records that the current boundary cannot safely resolve the issue.
It transfers the condition to the defined escalation/review path.

```text
ESCALATE ≠ AUTHORIZATION
ESCALATE ≠ EXECUTION_ALLOWED
```

The execution-integrity implementation uses escalation when its retry limit is
reached while the mismatch remains unresolved.

## 7. Required evidence cannot be `SKIP`ped into closure

`SKIP` is **not** an acceptable success category for a required security,
authority, integrity, evidence-freshness, replay, or execution-boundary check.

If a required check cannot run because a prerequisite is unavailable:

```text
REQUIRED CHECK
      ↓
PREREQUISITE UNAVAILABLE
      ↓
UNKNOWN / NOT VERIFIED
      ↓
FAIL-CLOSED / HALT AS DEFINED BY THE CONTROL
      ↓
NO CLOSURE
```

A test harness may technically skip an optional test, but that does not create
evidence that the skipped condition passed. For a **required closure control**,
absence of verification must remain an explicit limitation/failure condition.

## 8. Evidence and report requirements

Every terminal or unresolved category used by an SWI control should preserve,
where applicable:

- the stage;
- the reason code;
- the relevant evidence/reference identifier;
- the state before/during/after;
- whether execution was allowed;
- whether execution occurred;
- retry/revalidation requirements;
- escalation requirement;
- evidence hash where defined.

A report must not transform a failure category into a stronger claim merely by
recording it.

```text
FAILURE RECORD ≠ PROOF OF CAUSE
FAILURE RECORD ≠ AUTHORIZATION
FAILURE RECORD ≠ PRODUCTION READINESS
```

## 9. New-information boundary

When new information affects the evidence boundary, an earlier decision does
not automatically survive.

```text
NEW INFORMATION
      ↓
EVIDENCE BOUNDARY AFFECTED
      ↓
INVALIDATE PRIOR DECISION
      ↓
UNKNOWN / PAUSED
      ↓
REQUIRE BOUND AUTHORITY + RECHECK
      ↓
PASS → EXECUTION_ALLOWED only if all bindings still match
FAIL → HALT
```

The earlier `PASS` is evidence of the earlier check. It is not a permanent
permit for a changed evidence boundary.

## 10. Compact decision matrix

| Condition | Record category | Execute? | Can it close the control? |
|---|---|---:|---:|
| Valid required bindings and authority | `EXECUTION_ALLOWED` | Yes | Yes, for that specific bounded action |
| Candidate violates input/boundary contract | `REJECT` | No | No |
| Execution integrity mismatch | `HALT` | No | No |
| Required authority/evidence cannot establish permission | `UNKNOWN` | No | No |
| Unresolved condition requires higher review | `ESCALATE` | No | No |
| Implementation exception/error | `ERROR` | Not by itself | No |
| Required verification unavailable | `UNKNOWN` / fail-closed | No | **No** |

## 11. SWI invariants

```text
DATA ≠ EVIDENCE ≠ ADMISSION ≠ AUTHORIZATION ≠ ACTION
OBSERVATION ≠ CLAIM
EVIDENCE ≠ ADMISSION
ADMISSION ≠ AUTHORIZATION
AUTHORIZATION ≠ ACTION
UNKNOWN ≠ PERMITTED
PASS ≠ PROVEN
TESTED ≠ PROVEN
PROVEN ≠ SEALED
SEALED ≠ PRODUCTION_AUTHORIZED
REJECT ≠ EXECUTION
HALT ≠ EXECUTION
ESCALATE ≠ AUTHORIZATION
SKIP ≠ VERIFICATION
```
