# Failure Semantics

SWI uses explicit failure and decision categories rather than treating every
failure as a generic error.

Canonical categories currently represented across the V2 controls include:

```text
INVALID_INPUT · CONTRACT_FAILURE · INTEGRITY_FAILURE · AUTHORITY_FAILURE ·
CONSTRAINT_FAILURE · EXECUTION_FAILURE · OUTPUT_FAILURE · STATE_FAILURE ·
REJECT · HALT · UNKNOWN · ESCALATE · EXECUTION_ALLOWED · ERROR
```

For the authoritative category definitions and decision consequences, see:

- `docs/FAILURE_AND_DECISION_CATEGORIES.md`
- `docs/NEW_INFORMATION_BOUNDARY.md`
- `docs/EVIDENCE_MODEL.md`
- `docs/AUTHORITY_BOUNDARY_MODEL.md`

## Critical distinction

```text
ERROR ≠ HALT
REJECT ≠ HALT
HALT ≠ UNKNOWN
UNKNOWN ≠ PERMITTED
ESCALATE ≠ AUTHORIZATION
SKIP ≠ VERIFIED
```

A required security, integrity, authority, replay, evidence-freshness, or
execution-boundary control must **not** be skipped into closure. If its
required prerequisite is unavailable, the condition remains `UNKNOWN` /
not verified and must fail closed according to the applicable control.

## M11 admission

Raw, missing, malformed, integrity-invalid, or unknown-version foundation
inputs are rejected by the admission boundary; valid fixtures may be admitted
only when the declared contract is satisfied.
