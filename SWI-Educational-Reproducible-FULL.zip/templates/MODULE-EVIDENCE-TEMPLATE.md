# SWI Module Evidence Record

## Claim
What precise claim is being evaluated?

## Module
Module name, version, source commit and dependencies.

## Mathematics
Predicates, assumptions, variables and constraints.

## Attack
Threat model, adversarial inputs, bypass attempts and failure modes.

## Test
Exact commands, environment, test identifiers and inputs.

## Result
Observed output, exit status and evidence references.

## Limitation
What was not tested, proven, sealed or authorized?

## Status
OBSERVED:
TESTED:
PROVEN:
SEALED:
PRODUCTION_AUTHORIZED:

## Reviewer
Name or role, review date and review scope.
