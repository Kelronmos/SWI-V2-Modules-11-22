import pytest
from swi_device.core import (
    authorize, digest, record_admission, record_key_rotation
)

def request(**updates):
    data = {
        "human_authenticated": False,
        "authority_verified": False,
        "consent": True,
        "device_id": "D1",
        "workflow_id": "W1",
        "action_id": "A1",
        "cost": 5,
        "cost_limit": 10,
        "evidence_hash": "abc123"
    }
    data.update(updates)
    return data

def test_missing_human_authentication_pauses():
    result = authorize(request(), "D1", "W1", "A1")
    assert result["decision"] == "PAUSE"
    assert result["EXECUTE"] is False

def test_unverified_authority_pauses():
    result = authorize(request(human_authenticated=True), "D1", "W1", "A1")
    assert result["reason"] == "AUTHORITY_SOURCE_NOT_VERIFIED"

@pytest.mark.parametrize("field,value,reason", [
    ("device_id", "D2", "DEVICE_MISMATCH"),
    ("workflow_id", "W2", "WORKFLOW_MISMATCH"),
    ("action_id", "A2", "ACTION_MISMATCH"),
    ("consent", False, "CONSENT_REQUIRED"),
    ("cost", 20, "COST_LIMIT_EXCEEDED"),
    ("evidence_hash", "", "EVIDENCE_REQUIRED")
])
def test_invalid_conditions_pause(field, value, reason):
    data = request(human_authenticated=True, authority_verified=True)
    data[field] = value
    result = authorize(data, "D1", "W1", "A1")
    assert result["reason"] == reason
    assert result["EXECUTE"] is False

def test_conditions_met_still_does_not_execute():
    result = authorize(
        request(human_authenticated=True, authority_verified=True),
        "D1", "W1", "A1"
    )
    assert result["decision"] == "CONDITIONS_MET"
    assert result["EXECUTE"] is False

def test_digest_stable():
    assert digest({"a": 1, "b": 2}) == digest({"b": 2, "a": 1})

def test_rotation_rejects_same_key():
    with pytest.raises(ValueError):
        record_key_rotation("D1", "same", "same")

def test_admission_rejects_negative_cost():
    with pytest.raises(ValueError):
        record_admission("U1", "D1", True, "claim", "author", -1, "BWP")


def test_android_platform_detection(monkeypatch):
    from swi_device import platforms

    monkeypatch.setattr(
        platforms.platform,
        "system",
        lambda: "Android"
    )
    monkeypatch.delenv("ANDROID_ROOT", raising=False)

    assert platforms.current_platform() == "android"

    report = platforms.capabilities()
    assert report["platform"] == "android"
    assert report["hardware"] == "UNKNOWN"
    assert report["attestation"] == "NOT_VERIFIED"
    assert report["production_authorized"] is False
