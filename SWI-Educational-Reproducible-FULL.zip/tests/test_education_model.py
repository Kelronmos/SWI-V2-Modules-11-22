from swi_device.education_model import Evidence, evaluate_permit


def domains():
    shared = {"identity", "purpose"}
    return {
        "law": set(shared),
        "governance": set(shared),
        "standards": set(shared),
        "human": set(shared),
    }


def test_matching_conditions_and_action_bound_evidence():
    result = evaluate_permit(
        "A-1", {"identity"},
        domains(), [Evidence("A-1", True)]
    )
    assert result.status == "MATCH"


def test_unknown_authority_pauses():
    values = domains()
    values["human"] = None
    result = evaluate_permit(
        "A-1", {"identity"}, values, [Evidence("A-1", True)]
    )
    assert result.status == "PAUSE"


def test_missing_evidence_pauses():
    result = evaluate_permit("A-1", {"identity"}, domains(), [])
    assert result.status == "PAUSE"


def test_evidence_for_another_action_does_not_match():
    result = evaluate_permit(
        "A-1", {"identity"},
        domains(), [Evidence("A-2", True)]
    )
    assert result.status == "PAUSE"


def test_invalid_evidence_does_not_match():
    result = evaluate_permit(
        "A-1", {"identity"},
        domains(), [Evidence("A-1", False)]
    )
    assert result.status == "PAUSE"


def test_uncovered_condition_is_denied():
    result = evaluate_permit(
        "A-1", {"identity", "financial-transfer"},
        domains(), [Evidence("A-1", True)]
    )
    assert result.status == "DENY"


def test_missing_domain_pauses():
    values = domains()
    del values["human"]
    result = evaluate_permit(
        "A-1", {"identity"}, values, [Evidence("A-1", True)]
    )
    assert result.status == "PAUSE"
