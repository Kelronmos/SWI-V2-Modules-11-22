Linux targets: Ubuntu, Debian, Fedora and Arch.
Native adapter integration: TPM2/TSS and PKCS#11.
Tool presence is not TPM attestation or proof of key non-exportability.
