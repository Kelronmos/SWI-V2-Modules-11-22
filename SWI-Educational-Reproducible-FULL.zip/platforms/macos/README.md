macOS adapter target: Security.framework, Keychain and Secure Enclave.
Native implementation and hardware testing are required.
This directory is an integration specification, not a signed macOS app.
