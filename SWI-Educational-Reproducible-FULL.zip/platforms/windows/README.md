Windows adapter target: CNG/NCrypt, TPM and Windows Hello.
Native implementation and attestation verification are required.
This directory is an integration specification, not a signed Windows installer.
