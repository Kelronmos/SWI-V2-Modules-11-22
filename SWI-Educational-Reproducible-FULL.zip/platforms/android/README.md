Android native adapter target.
Implement with Android Keystore, KeyGenParameterSpec, KeyInfo,
StrongBox/TEE capability checks and attestation-chain validation.
Termux alone cannot prove Android hardware-backed key protection.
This directory is an integration specification, not an APK.
