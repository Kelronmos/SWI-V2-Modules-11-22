# Advanced Lesson 1: Adversarial Review

Challenge each workflow with:
- missing evidence
- stale evidence
- evidence for a different action
- malformed signatures
- unknown authority
- replayed requests
- inconsistent policy versions
- partial failures
- direct calls that bypass the intended gate

Record each attack, expected behavior, observed behavior,
test result and unresolved limitation.
