# Beginner Lesson 1: A Structured Workflow

A workflow converts a request into a controlled sequence.

Example:
Request -> Conditions -> Evidence -> Review -> Decision -> Action

Questions:
1. What is the requested action?
2. What conditions must hold?
3. What evidence supports each condition?
4. Who has authority to approve it?
5. What happens when information is unknown?

Exercise:
Explain why a matching record is not automatically permission
to execute an action.
