# Intermediate Lesson 1: Evidence Binding

Evidence should identify:
- the claim it supports
- the action it relates to
- its source and provenance
- its creation time and validity period
- its integrity protection
- the verification procedure
- its known limitations

A hash can help detect changes. A hash does not establish
truth, identity, authority or correctness.
