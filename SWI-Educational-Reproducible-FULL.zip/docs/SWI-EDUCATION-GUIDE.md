# Structured Workflow Intelligence (SWI)
## Educational Guide

Author context: Keletso Ronald Mosidila

### 1. Purpose

SWI is a structured method for evaluating claims, evidence,
conditions, authority and actions. It separates what is known
from what is permitted and what has actually been executed.

### 2. Core distinctions

DATA != EVIDENCE
EVIDENCE != ADMISSION
ADMISSION != AUTHORIZATION
AUTHORIZATION != ACTION

UNKNOWN != FALSE
UNKNOWN != PERMITTED
STABLE != AUTHORIZED
SIGNATURE != TRUTH
HASH != AUTHORITY

TESTED != PROVEN
PROVEN != SEALED
SEALED != PRODUCTION AUTHORIZED

MATCH != PERMIT
PERMIT != EXECUTE

### 3. Workflow

1. Identify the claim.
2. Identify the responsible module.
3. Define the mathematical conditions.
4. Identify attack paths and failure modes.
5. Execute tests.
6. Record results and evidence.
7. State limitations.

### 4. Status vocabulary

OBSERVED: an observation was recorded.
TESTED: a defined test was executed.
PROVEN: stated proof obligations were satisfied.
SEALED: a defined sealing process was completed.
PRODUCTION_AUTHORIZED: explicit production authorization exists.

A successful test does not automatically establish any later status.

### 5. Human authority

A boolean test input is not identity verification.
A signature is not automatically proof of authority.
A device fingerprint is not hardware attestation.
A local test CA is not a public production CA.

Unknown authority must pause the workflow and request
appropriate evidence or human review.

### 6. Educational scope

Examples in this repository are teaching models. They do not
constitute legal advice, regulatory certification, security
certification or production authorization.
