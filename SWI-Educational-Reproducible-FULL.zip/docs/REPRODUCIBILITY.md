# Reproducibility Protocol

## Fresh environment

1. Clone the repository.
2. Install Python and pytest using the platform package manager.
3. Run scripts/verify_reproducible.sh.
4. Preserve the generated evidence record.
5. Compare the recorded commit and test results.

## Evidence record

Each run records:
- UTC timestamp
- Git commit
- Python version
- compile result
- test result
- localization JSON validation
- SHA-256 manifest

## Reproducibility limitations

A replay on one device does not establish equivalent behavior
on another platform. Hardware attestation, TPM, Secure Enclave,
Android Keystore and Windows CNG require platform-native
implementations and independent verification.

A reproducible test run is not a production authorization.
