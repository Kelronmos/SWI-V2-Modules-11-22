# SWI Mathematical Model

## 1. Permit predicate

For an action a, define:

- C(a): conditions required by the action
- L: applicable law conditions
- G: governance conditions
- S: applicable standard conditions
- H: validated human-authority conditions
- E(a): evidence bound to the action

The educational permit predicate is:

Permit(a) iff
C(a) is a subset of L intersection G intersection S intersection H
and valid action-bound evidence exists.

Formally:

Permit(a) <=> C(a) subseteq (L intersect G intersect S intersect H)
             AND ValidEvidence(a) != empty

## 2. Important qualification

Evidence existence alone is insufficient. Evidence must be
relevant, valid, current, attributable and bound to the action.
The model in this repository demonstrates only a small subset
of those requirements.

## 3. Unknown values

UNKNOWN is not converted into FALSE or PERMITTED.
When required authority or evidence is unknown, the educational
decision is PAUSE.

## 4. Scoring

A policy coverage score may describe the proportion of mapped
requirements with evidence:

Coverage = mapped_requirements_with_evidence / total_mapped_requirements

Coverage is not a legal compliance score, certification,
authorization or proof of safety.

## 5. Status separation

PASS is a test outcome.
PROVEN is a proof status.
SEALED is a controlled record status.
PRODUCTION_AUTHORIZED is an authority decision.

These values must never be inferred from one another.
