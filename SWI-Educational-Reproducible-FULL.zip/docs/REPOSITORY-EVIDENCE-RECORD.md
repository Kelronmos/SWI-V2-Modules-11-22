# SWI Repository Evidence Record

## Identity

Project: SWI Multiplatform Device-Bound  
Author: Keletso Ronald Mosidila  
Record type: Prototype verification checkpoint  
Target environment: Android / Termux  
Architecture: ARM64  
Runtime identification: Android

## Verification observations

| Observation | Result |
|---|---|
| Python compilation | PASS |
| Existing prototype tests | 12/12 PASS |
| Android detection regression | PASS |
| Total pytest tests | 13/13 PASS |
| English localization JSON | VALID |
| Simplified Chinese JSON | VALID |
| Traditional Chinese JSON | VALID |
| Japanese localization JSON | VALID |

## Android capability report

Expected capability classification:

- Platform: android
- Runtime: Android / Termux
- Backend: Android Keystore native companion required
- Hardware: UNKNOWN
- Attestation: NOT_VERIFIED
- Production authorization: false

## Evidence limitations

The test results do not establish:

- Android Keystore integration
- StrongBox or TEE key protection
- Verified hardware attestation
- External human identity authentication
- Cryptographic key revocation
- Production CA certification
- Independent security validation
- Production authorization

## SWI classification

TESTED: YES, bounded prototype tests  
PROVEN: NO  
SEALED: NO  
PRODUCTION_AUTHORIZED: NO  
HARDWARE_ATTESTATION: NOT_ESTABLISHED

## Required next work

1. Implement Android native Keystore companion.
2. Generate non-exportable device keys where supported.
3. Request and independently validate attestation certificates.
4. Bind key identity to device registration.
5. Implement actual human authentication and admission.
6. Test key rotation and revocation.
7. Add native adapters for Linux, macOS and Windows.
8. Perform independent adversarial testing.

## Evidence principle

A test result records an observation. It does not automatically
establish proof, authority, certification or permission to execute.
