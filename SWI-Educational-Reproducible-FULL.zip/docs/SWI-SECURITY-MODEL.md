# SWI Multi-platform Security Model

DATA != EVIDENCE != ADMISSION != AUTHORIZATION != ACTION
MATCH != PERMIT != EXECUTE
UNKNOWN != FALSE/PERMITTED
HASH != AUTHORITY != TRUTH
TESTED != PROVEN != SEALED != PRODUCTION AUTHORIZED

Unknown authority means PAUSE.
Device registration is not device trust.
A public key fingerprint is not hardware attestation.
User ownership claims remain user assertions, not legal determinations.
A key-rotation event record is not cryptographic key rotation.
This prototype does not grant production authorization.
