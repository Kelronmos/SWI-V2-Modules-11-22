#!/data/data/com.termux/files/usr/bin/bash
set -eu
cd "$(dirname "$0")/.."
mkdir -p ca/test-root/private ca/test-root/certs
chmod 700 ca/test-root/private
KEY=ca/test-root/private/test-ca.key
CRT=ca/test-root/certs/test-ca.crt
if [ -e "$KEY" ] || [ -e "$CRT" ]; then
  echo "STOP: test CA already exists; refusing to overwrite."
  exit 1
fi
openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:3072 -out "$KEY"
chmod 600 "$KEY"
openssl req -x509 -new -sha256 -key "$KEY" -days 365 -out "$CRT" \
  -subj "/CN=SWI LOCAL TEST CA/O=SWI PROTOTYPE"
openssl x509 -in "$CRT" -noout -subject -issuer -fingerprint -sha256
echo "LOCAL TEST CA ONLY — NOT A PUBLIC TRUST ANCHOR"
