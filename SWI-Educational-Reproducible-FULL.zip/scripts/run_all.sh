#!/data/data/com.termux/files/usr/bin/bash
set -eu
cd "$(dirname "$0")/.."
mkdir -p evidence/test-runs
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
python -m compileall -q swi_device
python -m pytest -q
printf 'UTC=%s\nTESTS=PASS\nPROVEN=NO\nSEALED=NO\nPRODUCTION_AUTHORIZED=NO\nHARDWARE_ATTESTATION=NOT_ESTABLISHED\n' "$STAMP" | tee "evidence/test-runs/summary-$STAMP.txt"
