#!/data/data/com.termux/files/usr/bin/bash
set -u

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT" || exit 1

mkdir -p evidence/reproducibility
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT="evidence/reproducibility/run-${STAMP}.txt"

{
  echo "SWI REPRODUCIBILITY RUN"
  echo "UTC=${STAMP}"
  echo "COMMIT=$(git rev-parse HEAD 2>/dev/null || echo UNKNOWN)"
  echo "PYTHON=$(python --version 2>&1)"

  echo
  echo "=== COMPILE ==="
  if python -m compileall -q swi_device; then
    echo "COMPILE=PASS"
  else
    echo "COMPILE=FAIL"
    exit 1
  fi

  echo
  echo "=== TESTS ==="
  if python -m pytest -q; then
    echo "TESTS=PASS"
  else
    echo "TESTS=FAIL"
    exit 1
  fi

  echo
  echo "=== LOCALIZATION JSON ==="
  if python - <<'PY'
import glob, json, sys
files = glob.glob("localization/*.json")
if not files:
    print("No localization JSON files found")
    sys.exit(1)
for path in files:
    with open(path, encoding="utf-8") as handle:
        json.load(handle)
    print("VALID", path)
PY
  then
    echo "LOCALIZATION=PASS"
  else
    echo "LOCALIZATION=FAIL"
    exit 1
  fi

  echo
  echo "=== SHA256 SOURCE MANIFEST ==="
  find swi_device tests docs education references templates scripts localization \
    -type f ! -name '*.pyc' ! -path '*/__pycache__/*' -print0 |
    sort -z | xargs -0 -r sha256sum

  echo
  echo "PROVEN=NO"
  echo "SEALED=NO"
  echo "PRODUCTION_AUTHORIZED=NO"
  echo "HARDWARE_ATTESTATION=NOT_ESTABLISHED"
} 2>&1 | tee "$OUT"

RESULT=${PIPESTATUS[0]}
echo "EVIDENCE_FILE=$OUT"
exit "$RESULT"
