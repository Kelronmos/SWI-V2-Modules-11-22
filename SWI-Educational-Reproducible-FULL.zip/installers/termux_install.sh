#!/data/data/com.termux/files/usr/bin/bash
set -eu
pkg install -y python python-cryptography openssl-tool
ROOT="$HOME/SWI-Multiplatform-Device-Bound"
cd "$ROOT"
python -m venv --system-site-packages .venv
source .venv/bin/activate
python -m pip install pytest
echo "Termux environment ready."
