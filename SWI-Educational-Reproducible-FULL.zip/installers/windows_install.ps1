$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path))
py -3 -m venv .venv
& .\.venv\Scripts\python.exe -m pip install -r requirements.txt
