"""Small educational SWI permit model; not a production security gate."""

from dataclasses import dataclass
from typing import Iterable


@dataclass(frozen=True)
class Evidence:
    action_id: str
    valid: bool


@dataclass(frozen=True)
class Decision:
    status: str
    reason: str


def evaluate_permit(
    action_id: str,
    required_conditions: Iterable[str],
    domain_conditions: dict[str, set[str] | None],
    evidence: Iterable[Evidence],
) -> Decision:
    """Evaluate a simplified four-domain teaching predicate.

    None means a domain is unknown. Empty set means known to have
    no mapped conditions. Real systems need stronger validation.
    """
    domains = ("law", "governance", "standards", "human")

    if any(domain not in domain_conditions for domain in domains):
        return Decision("PAUSE", "A required domain is missing")

    if any(domain_conditions[d] is None for d in domains):
        return Decision("PAUSE", "A required domain is unknown")

    common = set.intersection(*(domain_conditions[d] for d in domains))
    required = set(required_conditions)

    if not required.issubset(common):
        return Decision("DENY", "Required conditions are not covered")

    bound_evidence = [
        item for item in evidence
        if item.action_id == action_id and item.valid is True
    ]

    if not bound_evidence:
        return Decision("PAUSE", "No valid evidence bound to this action")

    return Decision("MATCH", "Educational conditions and evidence matched")
