import os
import platform
import shutil


def current_platform():
    system = platform.system().lower()

    if system == "windows":
        return "windows"

    if system == "darwin":
        return "macos"

    # Android must be checked separately from desktop Linux.
    if system == "android":
        return "android"

    # Compatibility fallback for Android environments.
    if (
        system == "linux"
        and (
            os.environ.get("ANDROID_ROOT")
            or os.environ.get("TERMUX_VERSION")
        )
    ):
        return "android"

    if system == "linux":
        return "linux"

    return "unknown"


def capabilities():
    target = current_platform()

    if target == "android":
        return {
            "platform": "android",
            "runtime": "Android / Termux",
            "backend": "Android Keystore native companion required",
            "hardware": "UNKNOWN",
            "attestation": "NOT_VERIFIED",
            "production_authorized": False,
        }

    if target == "linux":
        return {
            "platform": "linux",
            "backend": "TPM2 / PKCS#11",
            "tpm2_tools": bool(shutil.which("tpm2_getcap")),
            "pkcs11_tools": bool(shutil.which("pkcs11-tool")),
            "hardware": "UNKNOWN",
            "attestation": "NOT_VERIFIED",
        }

    if target == "macos":
        return {
            "platform": "macos",
            "backend": "Keychain / Secure Enclave",
            "hardware": "UNKNOWN",
            "attestation": "NOT_VERIFIED",
        }

    if target == "windows":
        return {
            "platform": "windows",
            "backend": "Windows CNG / TPM",
            "hardware": "UNKNOWN",
            "attestation": "NOT_VERIFIED",
        }

    return {
        "platform": "unknown",
        "hardware": "NOT_AVAILABLE",
        "attestation": "NOT_VERIFIED",
    }
