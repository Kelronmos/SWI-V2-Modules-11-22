import argparse
import json
from .platforms import capabilities

def main():
    parser = argparse.ArgumentParser(prog="swi-device")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("capabilities")
    args = parser.parse_args()
    if args.command == "capabilities":
        print(json.dumps(capabilities(), indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
