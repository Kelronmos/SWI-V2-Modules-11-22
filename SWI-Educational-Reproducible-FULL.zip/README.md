# SWI Multiplatform Device-Bound

**Project:** Structured Workflow Intelligence (SWI)  
**Author:** Keletso Ronald Mosidila  
**Target prototype:** Android / Termux  
**Project type:** Separate multiplatform device-bound security prototype

## Purpose

Develop a testable, cross-platform foundation for device-bound identity,
key management, user admission, evidence recording and authorization
boundaries.

## Supported platform targets

- Android
- Linux: Ubuntu, Debian, Fedora and Arch
- macOS
- Windows

## Localization

- English: en
- Simplified Chinese: zh_CN
- Traditional Chinese: zh_TW
- Japanese: ja

## Current implementation

- Shared Python prototype core
- Platform capability detection
- Device registration records
- User admission records
- Bounded authorization evaluation
- Key-rotation event recording
- Test CA generation script
- Termux installation script
- Cross-platform source packaging
- Localization JSON files

## Android prototype status

Android platform detection is implemented and has a regression test.

The Android native Keystore companion is not yet implemented.
Hardware-backed key protection and hardware attestation have not
been independently established.

## Verification record

At the recorded verification checkpoint:

- Python compilation: PASS
- Pytest: 13 passed
- Localization JSON: 4 files validated
- Android platform detection: PASS

These results describe the tested prototype only.

## SWI evidence boundaries

DATA != EVIDENCE != ADMISSION != AUTHORIZATION != ACTION

UNKNOWN != FALSE/PERMITTED

STABLE != AUTHORIZED

SIGNATURE != TRUTH/AUTHORITY

TESTED != PROVEN != SEALED != PRODUCTION AUTHORIZED

MATCH != PERMIT != EXECUTE

## Current status

TESTED: Bounded prototype tests  
PROVEN: NO  
SEALED: NO  
HARDWARE_ATTESTATION: NOT_ESTABLISHED  
PRODUCTION_AUTHORIZED: NO

A passing test suite does not establish production security,
legal compliance, certification or hardware-backed protection.

## Security notes

- Test CA is not a public production CA.
- Private keys must never be committed.
- User authentication must be independently implemented and verified.
- Device ownership claims are not legal ownership verification.
- Platform capability detection is not hardware attestation.
- Key-rotation event recording is not proof of cryptographic revocation.

## Project structure

- `swi_device/` — shared prototype core
- `platforms/` — platform-specific documentation
- `tests/` — automated tests
- `scripts/` — build and verification scripts
- `installers/` — installation scripts
- `localization/` — language resources
- `docs/` — security model and technical documentation
- `evidence/` — test and repository records

## Development

Run:

```bash
python -m compileall -q swi_device
python -m pytest -q
python -m swi_device.cli capabilities
```

## License

No license has been declared yet. All rights and licensing terms
remain to be determined by the project owner.
