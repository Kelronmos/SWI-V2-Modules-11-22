# SWI Repository Reference Map

This repository is an educational integration and reproducibility
workspace. Historical source repositories remain separate.

## V1

Repository:
https://github.com/Kelronmos/Structured-Workflow-Intelligence

Historical baseline reference:
3ea83e4d

The reference is not a claim that the remote repository still
has this exact HEAD.

## V1 Modules 1-10

Repository:
https://github.com/Kelronmos/SWI-V1-Module-1-10

## V2 Modules 11-22

Repository:
https://github.com/Kelronmos/SWI-V2-Modules-11-22

Historical audit snapshot (2026-11-02):
bb401276ee3a32a822a518b18054d51c6490a20b

This is a historical reference, not a statement of current
remote HEAD or current verification status.

## Integration rule

Do not silently copy, rewrite or promote historical modules.
For each imported component, record its exact source commit,
review, tests, dependencies, limitations and integration changes.

No module is considered PROVEN, SEALED or PRODUCTION_AUTHORIZED
merely because it appears in this repository.
